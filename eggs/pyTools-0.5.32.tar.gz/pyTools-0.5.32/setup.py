#!/usr/bin/env python
"""
This is the setup file for use with distutils used to install the 
Python Tools package.

$Id: setup.py,v 1.10 2005/09/06 06:28:14 seoman Exp $
"""

from setuptools import setup, find_packages
import pyTools.__init__ as pkg

setup(
    name        = pkg.__package__,
    version     = pkg.__version__,
    description = pkg.__description__,
    author      = pkg.__author__,
    author_email= pkg.__author_email__,
    url         = pkg.__url__,
    packages    = find_packages(),
    license     = 'LGPL',
#    data_files  = [
#        ('share/doc/pyTools', [
#            'README.txt',
#            'NEWS.txt',
#            'INSTALL.txt',
#            'TODO.txt',
#            'ChangeLog',
#        ]),
#    ],
)

