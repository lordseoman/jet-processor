Python Tools
-=-=-=-=-=-=

pyTools is a conglomorate of a number of different packages, it started life
quite small housing methods, functions and classes which i found myself using
in a number of projects. However, it quickly grew larger as I started actively
abstracting functionality in whatever code i produced for the projects i'm
involved with. 

For example; while using ConfigParser i found myself wishing that i could
type case the values. After implementing this I found it so useful i use it
as a matter of course now, thus ExConfigParser was born and put in here. It
progressed from there and has expanded in a number of other ways too now.

The DataStorage was something i've used in a number of projects, and has
evolved over its production. It provides backend independant methods for 
accessing, modifying and updating data in a Container. As at the previous
release backends that were supported are MySQL, SQL-Relay, MS-SQL. We now 
support in addition to those; Postgres-SQL and BSD DB. There are a number of
improvements also, including Transactional support, a complete Query object
structure for building logical queries and SQL Objects for ease of use.
