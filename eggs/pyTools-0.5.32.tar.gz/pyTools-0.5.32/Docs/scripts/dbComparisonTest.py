#!/usr/bin/env python
"""
This is an independant comparison test that was created to test the storage
and speed of various Database backends. It was originally designed to determine
the differences between gdbm, BSD DB and dbm file based storage options. Its
also used to see how types of data (ie. random or ordered) is effected by the
type of DBM used, BSD allows for Hashed, BTree types for example.

It has been redesigned again to include SQLite and MySQL in the comparison.

$Id: dbComparisonTest.py,v 1.4 2005/06/03 10:22:27 seoman Exp $
"""
__revision__ = "$ Revision: $"[11:-2]


from pyTools.dbPool import StorageHandler
from pyTools.dbPool.Query import *

import string,random
from mx import DateTime


class Tester:
    """
    Instanciate the Tester class for each handler you wish to test, this class
    doesn't open the connection straight away but it does ensure the database
    is not currently in existance. We use the one Cursor for each of the tests
    """
    table = 'comparisonTest'
    rows  = ('userid','name','url','date','comment')
    __s   = string.letters + string.digits + ' '
    records = 5000
    
    def __init__(self, identifier, script):
        """ Constructor """
        self.handler = StorageHandler().run(identifier)
        if len(self.handler._Container__connectors) != 1:
            raise ValueError("identifier must have a single Connector.")
        self.script = script % {'table':self.table,}
        self.__connection = None

    def sample(self, num):
        s = ''
        for x in xrange(num):
            s += self.__s[random.randint(0,len(self.__s)-1)]
        return s
    
    def generateSample(self, records, start, period=60, random_dates=False):
        """
        Returns a generator that produces a recordset starting at 'start' with
        a maximum date field 'period' days from 'start'. The records are gener-
        ated using random samples for the field values except for the date 
        field which is only random if random_dates is set.        
        """
        period_in_secs = period*24*3600
        count = x = 0
        while count < records:
            d = {
                'userid' : random.randint(1,9999),
                'name'   : self.sample(21),
                'url'    : self.sample(117),
                'comment': self.sample(231),
            }
            if random_dates:
                x = random.randint(0,period_in_secs)
            else:
                x += random.randint(0,(period_in_secs-x)/(records-count))
            d['date'] = start + DateTime.RelativeDateTime(seconds=x)
            yield d
            count += 1
        return
    
    def run(self):
        """
        Run the tests to Create, Populate a db (both with random and progress-
        ive data), search, and destroy data. This runs each test taking timing
        for each.
        """
        today = DateTime.today()
        start = today + DateTime.RelativeDateTime(days=7,minutes=260)
        end   = start + DateTime.RelativeDateTime(days=15,minutes=423)
        
        print "Creating database took",
        now = DateTime.now()
        self.create()
        print "%5.02fs" % ((DateTime.now()-now).second)
        
        print "Populating with random data",
        now = DateTime.now()
        num = self.populate(self.generateSample(self.records,today,60,True))
        print "took %5.02fs on %d records" % ((DateTime.now()-now).second,num)
        
        print "Database size = %s" % self.__connection.size()
        
        print "Doing a select all",
        now = DateTime.now()
        s = len(self.__connection.cursor.execute(Select(self.table)))
        print "took %5.02fs on %d records" % ((DateTime.now()-now).second,s)
        
        print "Search over random data",
        now = DateTime.now()
        res = self.search(start,end)
        print "took %5.02fs returning %d"%((DateTime.now()-now).second,len(res))
        
        print "Cleaning table took",
        now = DateTime.now()
        self.clean()
        print "%5.02fs" % ((DateTime.now()-now).second)
        
        print "Populating with sequencial data",
        now = DateTime.now()
        num = self.populate(self.generateSample(self.records,today,60,False))
        print "took %5.02fs on %d records" % ((DateTime.now()-now).second,num)
        
        print "Database size = %s" % self.__connection.size()
        
        print "Search over sequencial data",
        now = DateTime.now()
        res = self.search(start,end)
        print "took %5.02fs returning %d"%((DateTime.now()-now).second,len(res))
        
        print "Cleaning table took",
        now = DateTime.now()
        self.clean()
        print "%5.02fs" % ((DateTime.now()-now).second)
        
        print "Transactional Population with sequencial data",
        now = DateTime.now()
        num = self.populate(self.generateSample(self.records,today,60),True)
        print "took %5.02fs on %d records" % ((DateTime.now()-now).second,num)
        
        print "Database size = %s" % self.__connection.size()
        
        print "Search over sequencial data",
        now = DateTime.now()
        res = self.search(start,end)
        print "took %5.02fs returning %d"%((DateTime.now()-now).second,len(res))
        
        print "Cleaning table took",
        now = DateTime.now()
        self.clean()
        print "%5.02fs" % ((DateTime.now()-now).second)
        
    def create(self):
        """ 
        Open a new database Connection and runs the initialisation script to 
        setup the database. This method sets the 'connection' attribute on the
        tester for later use.
        """
        self.__connection = self.handler.connection
        try:
            self.__connection.dropTable(self.table)
        except self.__connection.Errors,e:
            pass
        self.__connection.cursor.runquery(self.script)

    def populate(self, data, transact=False):
        """ 
        Populate the current database using 'data' as the records to put into
        the database. 'data' could be a list or a generator which randomly 
        creates records to be stored.
        """
        if self.__connection is None:
            raise ValueError("No connection active.")
        cursor = self.__connection.cursor
        if transact is True:
            cursor.begin()
        qry = Insert(self.table)
        qry.setRows(self.rows)
        count = 0
        for record in data:
            qry.clear()
            qry += [ record.get(f) for f in self.rows ]
            ar = cursor.execute(qry)
            if ar != 1:
                print "affected rows not 1:",ar
                break
            count += 1
        if transact is True:
            cursor.commit()
        return count

    def search(self, start, end):
        """ Returns a generator to walk through all results from a lookup """
        if self.__connection is None:
            raise ValueError("No connection active.")
        qry = Select(self.table)
        qry.wheres.add(date=BETWEEN(start,end))
        qry.orderby = ('date',)
        return self.__connection.cursor.execute(qry)

    def clean(self):
        """ Empty the current database """
        if self.__connection is None:
            raise ValueError("No connection active.")
        self.__connection.cursor.execute(Delete(self.table))
        self.__connection.optimiseTable(self.table)


if __name__ == '__main__':
    import getopt,sys
    from pprint import pprint

    args = sys.argv[1:]
    try:
        optlist,args = getopt.getopt(args,'Vh:',
            ['help','version',
             'host=','port=','socket=','type=','user=','pass=','db=','script=' 
            ]
        )
    except getopt.error,detail:
        print "Unhandled option: %s" % detail
        print __doc__
        sys.exit(1)

    ctype = username = password = host = db = socket = ''
    port = 0
    for x in optlist:
        if x[0] in ('-V','--version'):
            sys.stderr.write("%s - Version: %s\n" % (__program__, __version__))
            sys.exit(0)
        elif x[0] in ('-h','--help'):
            print __doc__
            sys.exit()
        elif x[0] in ('--host',):
            host = x[1]
        elif x[0] in ('--port',):
            port = int(x[1])
        elif x[0] in ('--user',):
            username = x[1]
        elif x[0] in ('--pass',):
            password = x[1]
        elif x[0] in ('--db',):
            db = x[1]
        elif x[0] in ('--type',):
            ctype = x[1]
        elif x[0] in ('--socket',):
            socket = x[1]
        elif x[0] in ('--script',):
            script = open(x[1],'r').read()
        else:
            print "%s\nUnhandled option %s\n" % (__doc__,x[0])
            sys.exit(1)
        
    pool = StorageHandler()
    identifier = pool.add(ctype,host,port,socket,username,password,db,"def")
    tester = Tester(identifier,script)
    tester.run()

