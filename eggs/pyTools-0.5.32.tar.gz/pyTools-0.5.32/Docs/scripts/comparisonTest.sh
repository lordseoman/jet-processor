#!/bin/bash

echo 
echo "MySQL using ISAM tables:"
python dbComparisonTest.py --type=mysql \
    --host=127.0.0.1 --user=testsuite --pass=hg873hS --db=comptest \
    --script=dbComp.mysql-isam
    
echo
echo "MySQL using INNODB tables:"
python dbComparisonTest.py --type=mysql \
    --host=127.0.0.1 --user=testsuite --pass=hg873hS --db=comptest \
    --script=dbComp.mysql-innodb
    
rm -f /tmp/dbCompDB.sql
echo
echo "SQLite:"
python dbComparisonTest.py --type=sqlite --db=/tmp/dbCompDB.sql --script=dbComp.sqlite

