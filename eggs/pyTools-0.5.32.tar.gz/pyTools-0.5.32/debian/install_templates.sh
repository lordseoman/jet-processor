#! /bin/sh

set -e

VERSIONS="$*"
#PACKAGES="pytools pytools-dbpool pytools-objects pytools-xml"
PACKAGES="pytools pytools-dbpool pytools-objects"

for ver in $VERSIONS; do
    for pkg in $PACKAGES; do
        debpkg=python$ver-$(echo -n $pkg | tr '[:upper:]' '[:lower:]')

        sed -e "s/@DEBPKG@/$debpkg/g" <debian/prerm.template >debian/$debpkg.prerm
        sed -e "s/@DEBPKG@/$debpkg/g" -e "s/@VERSION@/$ver/g" <debian/postinst.template >debian/$debpkg.postinst
        sed -e "s/@VERSION@/$ver/g" <debian/$pkg.install >debian/$debpkg.install
        cp debian/$pkg.docs debian/$debpkg.docs
    done
done
