"""
These TestCases are classes used by tests in this package.

$Id: TestCases.py,v 1.7 2005/10/15 14:14:18 seoman Exp $
"""
__revision__ = "$Revision: 1.7 $"[11:-2]


from Testing import TestCase
from dbPool import StorageHandler
from dbPool.Query import *
from mx import DateTime

class DbPoolTestCase(TestCase):
    """ All DbPool tests require a connection setup first """

    hostname = username = password = None
    tables = []
    
    def setUpTestCase(cls):
        """ Setting up tests """
        cls.handler = StorageHandler()
        if cls.identifier not in cls.handler.handlers:
            cls.handler.addContainer(
                cls.containerType,
                cls.hostname,
                username=cls.username,
                password=cls.password,
                database=cls.database,
                identifier=cls.identifier,
            )
        if cls.identifier not in cls.handler.handlers:
            raise AttributeError("Failed to setup Handler.")
    setUpTestCase = classmethod(setUpTestCase)   

    def tearDownTestCase(cls, result):
        """ Tear down testcase """
        pass
    tearDownTestCase = classmethod(tearDownTestCase)

    def setUp(self):
        """ 
        For each test ensure the tables are all cleared, we do this instead
        of clearing them in the tearDown so that you can inspect the table
        afterwards if you want.
        """
        self.container  = self.handler(self.identifier)
        self.connector  = self.container.connector
        self.connection = self.container.connection
        self.cursor     = self.connection.cursor
        # setup the tables
        for tablename,schema in self.tables:
            try:
                self.cursor.runquery('DROP TABLE %s' % tablename)
            except self.cursor.Errors,e:
                # remove the last error message because its okay
                self.cursor.messages = self.cursor.messages[:-1]
            self.cursor.runquery(schema % tablename)

    def tearDown(self):
        if self.cursor.messages:
            print self.cursor.messages


class DataStoreBase(TestCase):
    """ Test case used as a base for DataStore tests """
    dependencies = (
        'TC_StorageHandler',
        'TC_Query',
    )
    __StopOnError__ = True
    _objects = ()
    hostname = username = password = None
    
    def setUp(self):
        """ Setup the pointers """
        self.container  = self.handler(self.identifier)
        self.connector  = self.container.connector
        self.connection = self.container.connection
        self.cursor     = self.connection.cursor

    def tearDown(self):
        if self.cursor.messages:
            print self.cursor.messages
            
    def setUpTestCase(cls):
        """ 
        Setting up tests, we use the one table instance for the entire test
        suite. so setup the table here too.
        """
        cls.handler = StorageHandler()
        if cls.identifier not in cls.handler.handlers:
            cls.handler.addContainer(
                cls.containerType,
                cls.hostname,
                username=cls.username,
                password=cls.password,
                database=cls.database,
                identifier=cls.identifier,
            )
        if cls.identifier not in cls.handler.handlers:
            raise AttributeError("Failed to setup Handler.")
       # setup the tables
        cursor = cls.handler(cls.identifier).getCursor()
        for tablename,schema in cls.tables:
            try:
                cursor.runquery('DROP TABLE %s' % tablename)
            except cursor.Errors,e:
                pass
            cursor.runquery(schema % tablename)
        # setup the classes
        for ob in cls._objects:
            ob.__id__ = cls.identifier
            setattr(cls,ob.__name__,ob())
        return
    setUpTestCase = classmethod(setUpTestCase)   

 
class ObjectTestCase(TestCase):
    pass


class pyTestCase(TestCase):

    def getDate(self,date=None):
        date = date or DateTime.now()
        return date - DateTime.RelativeDateTime(seconds=date.second % 1)

