"""
This is an extension to the python logging module to allow for Buffered SMTP
Handling. You can patch the Memory Handler onto the SMTP Handler however you
then get an email for each line of logging. This is better as it allows the
proper use of the logging.cfg file to define the details as well as doing 
proper buffering. 

We extend the BufferingHandler as it handles everything except the flush, which
is where we send the emails from.

The one exception here is that we expect the args in the globals().

  _logging_mailhost
  _logging_subject
  _logging_fromaddr
  _logging_toaddrs
  _logging_capacity
  

$Id: BufferingSMTPHandler.py,v 1.2 2004/02/15 22:10:32 seoman Exp $
"""
__revision__ = "$Revision: 1.2 $"[11:-2]

import logging, logging.handlers, types
from pyTools.utils import sendMail

class BufferingSMTPHandler(logging.handlers.BufferingHandler):
    """
    This is a buffered SMTP Handler for python logging, this is similar to
    a MemoryHandler with a target of the SMTPHandler. This is down instead of
    leveraging of the MemoryHandler since the SMTPHandler expects to get records
    and thus formats them itself. This is a problem for buffered output.
    """
    def __init__(self, mailhost=None, capacity=None):
        """
        Initialise the handler.

        Initialize the instance with the from and to addresses and subject
        line of the email. To specify a non-standard SMTP port, use the
        (host, port) tuple format for the mailhost argument.
        """
        # Initialise as a BufferingHandler.. as we only over-write the flush
        if not capacity:
            capacity = globals().get('_logging_capacity', 1000)
        logging.handlers.BufferingHandler.__init__(self, capacity)
        # Break up the mailhost
        if not mailhost:
            mailhost = globals().get('_logging_mailhost','localhost')
        if type(mailhost) == types.TupleType:
            self.mailhost, self.mailport = mailhost
        else:
            self.mailhost, self.mailport = mailhost, None
            
        self.fromaddr = globals().get('_logging_fromaddr','logger@domain')
        self.toaddrs = globals().get('_logging_toaddrs',['root',])
        self.subject = globals().get('_logging_subject','logging default email')
        
    def flush(self):
        """
        Sends records via email.
        """
        if len(self.buffer) > 0:
            fromaddr = globals().get('_logging_fromaddr', self.fromaddr)
            toaddrs = globals().get('_logging_toaddrs', self.toaddrs)
            subject = globals().get('_logging_subject', self.subject)
            mailhost = globals().get('_logging_mailhost', self.mailhost)
            
            msg = ''
            for record in self.buffer:
                msg += self.format(record) + "\r\n"
            errMsg = sendMail(msg, toaddrs, fromaddr, subject, mailhost,
                              user=None, passwd=None, ssl=0)
            if errMsg:
                self.handleError()
            self.buffer = []
        return
        
logging.BufferingSMTPHandler = BufferingSMTPHandler
