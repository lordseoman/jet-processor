"""
The Accessor Registry Module.

Firstly, a warning; if you might not need to use this class then don't, if there
is any way of doing what you need without using this registry then do it that
way. This is fraught with danger.

This is to provide a global way of registering an environment (that is a set
of methods along with some arguments) so that other functions or classes can 
access those environments without having to know anything except the identifier.

This was created to service a special need, and would be most useful when using
C library extensions. For example:
    
>>> from pyTools import Accessor
>>> accessor = Accessor.Accessor()
>>> 
>>> def func(name):
...     def spare(arg1,arg2,arg3=None):
...         if not arg3:
...             return "%s/%s" % (arg1,arg2)
...         else:
...             return "%s/%s/%s" % (arg1,arg2,arg3)
...     ident = accessor.add(spare,arg1='me')
...     self.anotherFunc(ident)
...     accessor.free(ident)
...     return
...     
>>> def anotherFunc(handler):
...     print accessor[handler]['spare'](arg2='who')
...     return
...
>>> func('who')
"me/who"
>>> 

This was implemented for use with libxslt2-python along with extensionClass
to allow me to call a different function dependant on the calling method with
having a slightly different xslt transform for each type of call. The big 
problem I ran into here was loading images from an archive during transform
as the transform nor the extensionClass had no link to the archive in any way.

$Id: Accessor.py,v 1.3 2004/05/03 07:31:22 seoman Exp $
"""
__revision__ = "$Revision: 1.3 $"[11:-2]


from pprint import pprint
import random,time,inspect,threading

class CallWrapper(dict):
    """ This is a wrapper around a method in the Accessor Class """
    def __init__(self, method, methodName=None, **kwargs):
        """ Setup a callwrapper """
        dict.__init__(self)
        if not hasattr(method, '__call__'):
            raise AccessorError("Method is not callable.")
        self.method = method
        self.__name__ = methodName or method.__name__
        # inspect the attributes of the load method
        self.args,vargs,vkwargs,defs = inspect.getargspec(method)
        defs = defs or []
        self.args = self.args or []
        if inspect.ismethod(method) or 'self' in self.args:
            self.reqArgs = self.args[1:len(self.args)-len(defs)]
        else:
            self.reqArgs = self.args[:len(self.args)-len(defs)]
        self.optArgs = []
        y = len(self.reqArgs)
        for x in range(len(self.args)-len(defs),len(self.args)):
            self.optArgs.append(self.args[x])
        # Check for useless args not used by the method
        useless = filter(lambda x: x not in self.args, kwargs.keys())
        if useless:
            raise AccessorError("Args not useable by method call: %s"%useless)
        # Save the keyword args for use when calling.
        for k,v in kwargs.items():
            self.__setitem__(k, v)
        return
        
    def __repr__(self):
        """ Represent ourselves as a wrapper """
        return "<CallWrapper around %s at %s>" % (self.name,id(self))
        
    def __call__(self, *args, **kwargs):
        """
        This is the call method for the wrapper that is used to pass on the args
        as set during registration of this method.
        """
        vArgs = args[:]
        eArgs = {}

        numArgs = len(args)
        if numArgs < len(self.reqArgs):
            # We need to fill in some of the required args
            for name in self.reqArgs[len(args):]:
                if name in kwargs:
                    vArgs += (kwargs[name],)
                elif name in self.keys():
                    vArgs += (self.__getitem__(name),)
                else:
                    raise AttributeError("Missing required arg: %s"%name)
        elif numArgs > len(self.reqArgs):
            vArgs = args[:len(self.args)]
            # Make the extra args into kwargs
            for x in range(len(self.reqArgs),numArgs):
                eArgs[self.args[x]] = args[x]
        # Now process the kwargs
        for name in self.optArgs:
            if name in eArgs:
                continue
            elif name in kwargs:
                eArgs[name] = kwargs[name]
            elif self.has_key(name):
                eArgs[name] = self.__getitem__(name)
        # And call the wrapped method
        return self.method(*vArgs, **eArgs)

class AccessorError(Exception):
    pass

class Accessor(dict):
    """
    Accessor class stores environment and method calls almost like a global
    environment registry. The main difference is that you can have different
    methods with the same name and arguments. 
    
    This is a SingleTon class, so feel free to instanciate it where ever it is
    needed.
    """
    def __new__(_class):
        """ Create a singleton of this class """
        it = _class.__dict__.get("__it__")
        if it is None:
            _class.__it__ = it = dict.__new__(_class)
            it.init()
        return it
        
    def init(self):
        """ Called at first instanciation """
        self.lock = threading.RLock()

    def __repr__(self):
        """ Represent ourselves nicely """
        return "<Accessor with %d envs at %s>" % (len(self.keys()),id(self))

    def dump(self):
        """ Print what is in the registry """
        pprint(self.items())
        return

    def getNewId(self):
        """ Gets a randomly generated Id for the new environment """
        newId = str(random.randint(1,999999))
        while self.has_key(newId):
            newId = str(random.randint(1,999999))
        return newId

    def new(self):
        """ Register a new environment, returns a envId """
        self.lock.acquire()
        newId = self.getNewId()
        self.__setitem__(newId, {})
        self.lock.release()
        return newId

    def add(self, method, methodName=None, identifier=None, **kwargs):
        """ Add a new method to an environment """
        self.lock.acquire()
        if not identifier:
            identifier = self.new()
        env = self.__getitem__(identifier)
        wrapper = CallWrapper(method, methodName, **kwargs)
        env[wrapper.__name__] = wrapper
        self.lock.release()
        return identifier

    def free(self, identifier):
        """ Close off an environment after its use has finished """
        self.lock.acquire()
        if self.has_key(identifier):
            self.__delitem__(identifier)
        self.lock.release()
        return
        
    def get(self, identifier, name, *args):
        """ Returns a (method,kwargs) tuple for a requested method """
        if self.has_key(identifier):
            env = self.__getitem__(identifier)
            return env.get(name, *args)
        elif args:
            return args[0]
        else:
            raise AccessorError,"No such identifier."
