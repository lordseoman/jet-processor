"""
Acquisition is a module used as a base mixin for providing traversal and 
downward containment functionality to objects. This is pretty much similar
to providing tree like structure to a set of disparate objects.

If the objects only reside in the hierarchal structure then you might prefer 
to use the xml Node python structures. However, if your objects are disparate
then this may be better. This is almost a proof of concept for me on how to 
provide the traversal (downward) and acquisition (upward) methodolgies provided
by Zope.

Now consider the following diagram:
    
  +-> A (id = 'top')
      |
      +-> B
      |   |
      |   +-> C
      |
      +-> D
          |
          +-> E
          
a.b == b.__of__(a)

Now a.b will return the 'b' instance wrapped in an acquisition wrapper so that
'a.b.aq_parent' is 'a'. Unlike Zope we'll make the id an internal attribute. 
This is actually a component structure of the Container.py module's 
implementation. Thus 'a.getId()' returns 'top'.

How does it all work? Because a.b is actually an Acquisition Wrapper, 'a.b.x'
will call __getattr__ on the wrapper. The wrapper then calls the __acquire__
method on the object passing in not only the name of the attribute to collect
but also a pointer to the wrapped object. Why? Because sometimes your 
__getattr__ might want to access attributes not on this object, or to acquire
an object further up the acquisition chain. In this way you can override the
default behaviour of the __acquire__ method to provide whatever custom result
you might need.

the b.__of__(a) structure is the same as that of Zope, it means that 'b' has a 
acquisition parent of 'a'. In this way consider:

   a.b.c == c.__of__(b.__of__(a))

This is just an extra child in the one above, so implicit acquisition will 
search 'c' then 'b' then 'a'.

   a.b.c.d == (d).__of__(a.b.c)
           == (d).__of__(c.__of__(b.__of__(a)))
           == (d.__of__(a)).__of__(c.__of__(b.__of__(a)))

This is much more complex, since 'c' will acquire 'd' from 'a', 'd' is collected
containment wrapped in 'a'. That object is then wrapped in 'c', making 'd' an
object __of__ 'a.b.c'. The search order is then 'd', 'c', 'b', and 'a'. But it
doesn't stop there as 'd' is containment wrapped in 'a', the __getattr__ will
strip off a level of wrapping and ask 'a' again. 

So, our search order (or aro) is:

   [d -> c -> b -> a], [a]

Finally, lets put 'e' directly on 'c'. We cannot rely on acquisition to find 'e'
so we'll have to assign it.

   a.b.c.e = a.d.e
        
Now the resolution order will take the first 'e' then its assignment just as in
the last example.

   a.b.c.e == (e).__of__(c.__of__(b.__of__(a)))
   
'e' however is wrapped by containment in d.__of__(a), so:
    
   a.b.c.e == (e.__of__(d.__of__(a)).__of__(c.__of__(b.__of__(a)))

Making the resolution order:

   [e -> c -> b -> a], [d -> a]

This does mean that if only 'd' had the attribute 'colour', then 'a.b.c.e.colour'
would acquire the attribute, which can be very dangerous and unexpected.

We do all this by providing a two mixin classes and a wrapper. The mixin class
is designed to be used with an object from the Objects package, such as the base
container OrderedArray or a Folder object. These objects are designed to provide
downward traversal behaviour

>>> from pyTools.Objects import Container
>>> from pyTools.Acquisition import Implicit
>>> 
>>> class A(Container.Array, Implicit):
...     def __init__(self, x):
...         self.x = 1
...     
>>> a = A(1)
>>> a.setObject('b', A(2))
>>> a.b.x
2
>>> a.a = "red"
>>> a.b.a
red
>>> y = A(3)
>>> a.b.setObject('c', y)
>>> a.b.c.x
3
>>> a.b.c.b.x
2
>>>

$Id: Acquisition.py,v 1.1 2004/05/03 06:43:00 seoman Exp $
"""
__revision__  = "$Revision: 1.1 $"[11:-2]

EXPLICIT = 1
IMPLICIT = 2

class Wrapper(object):
    """ Acquisition Wrapper """
    def __init__(self, object, parent):
        self.__dict__['__parent'] = parent
        self.__dict__['__self'] = object
        return
    
    def __repr__(self):
        return repr(self.__aq_base())
    
    def __aq_self(self):
        """ Returns the object with one layer of wrapper removed """
        return self.__self
    aq_self = property(__aq_self)
    
    def __aq_parent(self):
        """ Returns the acquisition parent of this object """
        return self.__parent
    aq_parent = property(__aq_parent)
    
    def __aq_base(self):
        """ Return the raw object without wrappings """
        if hasattr(self.__self, 'aq_base'):
            return self.__self.aq_base
        else:
            return self.__self
    aq_base = property(__aq_base)

    def __aq_chain(self):
        """ Returns a list of parents in acquisition order """
        aro = [self,]
        if hasattr(self.__parent, 'aq_parent'):
            aro += self.__parent.aq_chain
        return aro
    aq_chain = property(__aq_chain)

    def __aq_inner(self):
        """ Return the inner most aquisition wrapper, the containment one """
        this = self
        while hasattr(this, 'aq_base'):
            this = this.aq_self
        return this
    aq_inner = property(__aq_inner)
    
    def __getattr__(self, name):
        """ If we are here then we are after an attribute on the object """
        obj = self.__aq_base()
        try:
            value = obj.__acquire__(self, name)
        except AttributeError, detail:
            if obj.__Acquisition_Wrapper__ == IMPLICIT:
                # Try to get 'name' off the parent
                try:
                    value = getattr(self.__parent, name)
                except AttributeError, detail:
                    # finally, ask ourselves with one wrapping removed
                    value = getattr(self.__self, name)
        return value
    
    def __setattr__(self, name, value):
        """ We never allow an attribute to be set on the wrapper """
        return setattr(self.__aq_base(), name, value)
    
class BaseMixin:
    """
    This is the mixin or Base class that should be used in order to make objects
    acquisition aware. It should be noted that objects don't need to inherit
    from ObjectBase, you can override the __acquire__ method
    """
    def __of__(self, obj):
        """ Wrap 'obj' in an Acquisition Wrapper """
        return Wrapper(self, obj)

    def __acquire__(self, wrapper, name):
        """ 
        This is an ease of use method to allow the wrapper to be available to
        this object. By default we attempt to getattr() the attribute requested
        and then attempt to wrap it in the the parent wrapper if that is 
        available to the returned object/attribute.
        
        You should override this method if you require access to the wrapper
        calling this from within the acquisition process.
        """
        value = getattr(self, name)
        if hasattr(value, '__of__'):
            value = value.__of__(wrapper)
        return value
        
    def __getattr__(self, name):
        """ 
        This is only called when an attribute/method is not found on this
        object, we return a parent wrapped object. We do get here when using
        an acquisition wrapper.
        """
        if name in self.__dict__:
            value = self.__dict__[name]
        elif name in self.__class__.__dict__:
            value = self.__class__.__dict__[name]
        elif name in self.objectIds():
            value = self.getObject(name)
        else:
            raise AttributeError,"no such attribute %s" % name
        if hasattr(value, '__of__'):
            value = value.__of__(self)
        return value
        
    def __setattr__(self, name, value):
        """
        We want to ensure that a user cannot create an object attribute that
        has the same _id/name as a child object. We could do some funky stuff
        around setting objects as children if the 'value' object has a '__of__'
        method. Which would allow updating a child too.
        """
        if name in self.objectIds():
            raise AttributeError,"%s already exists as a child." % name
        self.__dict__[name] = value
        return
        
        
class Implicit(BaseMixin):
    """ 
    Implicit acquisition means that __getattr__ will walk up the parents of this
    object looking for what you are after, after looking on the object and then
    for any children objects thusly named.
    """
    __Acquisition_Wrapper__ = IMPLICIT
    

class Explicit(BaseMixin):
    """
    Explicit acquisition will not walk up the parent tree looking for the named
    object/attribute. Instead it will only look on the object and for a child
    object.
    """
    __Acquisition_Wrapper__ = EXPLICIT
    

        