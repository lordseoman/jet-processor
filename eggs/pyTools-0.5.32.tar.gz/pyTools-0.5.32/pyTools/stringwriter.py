"""
This is the StringWriter module.

$Id: stringwriter.py,v 1.1 2004/05/13 06:28:51 seoman Exp $
"""
__revision__  = "$Revision: 1.1 $"[11:-2]


from cStringIO import StringIO
import codecs

class StringWriter:
    encoding = 'UTF-8'
    __writer = None
    
    def getWriter(self, encoding=None):
        """ Convenience method for obtaining a writer """
        if not self.__writer:
            self.__writer = StringIO()
            encoding = encoding or self.encoding
            if encoding is not None:
                self.__writer = codecs.lookup(encoding)[3](self.__writer)
            self.__writer.encoding = encoding
            self.__writer.doneNS = False
        return self.__writer

    def finaliseWriter(self):
        """ Method closes off writing and returns the final output """
        writer = self.__writer
        self.__writer = None
        if not writer:
            return ''
        output = writer.getvalue()
        try:
            writer.close()
        except:
            del(writer)
        return output

