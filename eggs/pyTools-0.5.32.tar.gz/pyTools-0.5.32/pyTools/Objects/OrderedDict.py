"""
Ordered Dictionary that behaves like a normal dictionary but the order in
which you set elements determines the order in which they appear in when viewed
or iterated over. keys(), values() and items() will return a list where the
order is preserved from addition time.

$Id: OrderedDict.py,v 1.3 2007/05/01 07:21:31 seoman Exp $
"""
__revision__ = "$Revision: 1.3 $"[11:-2]


class DictMixin:
    """ Base mixin class for below dictionary classes """
    
    def __repr__(self):
        """ Returns a string representing this dict """
        return "<%s containing %d elements at %s>" % (
            self.__class__.__name__,len(self),id(self)
        )

    def __getitem__(self, name):
        """ Return an item's value from the dict """
        return self.__MasterClass__.__getitem__(self, name)

    def __setitem__(self, name, value):
        """ Set 'name' on us to have 'value', appending if needed """
        self.__MasterClass__.__setitem__(self, name, value)

    def __delitem__(self, name):
        """ Remove 'name' and its value from this dict """
        self.__MasterClass__.__delitem__(self, name)

    def __contains__(self, name):
        """ Returns True if name is in this dict list of keys """
        return self.has_key(name)

    def has_key(self, name):
        """ D.has_key(name) -> True/False if name is field in dict """
        return name in self.keys()
    
    def update(self, o):
        """
        Update the items in this dictionary with either a list/tuple of (k,v) 
        elements or a dictionary itself. In the first instance order is carried
        across, however if a dict is used we can't guarantee order unless its
        an instance of OrderedDict itself.
        """
        if hasattr(o,'iteritems'):
            it = o.iteritems()
        else:
            it = iter(o)
        n = 0
        for i in it:
            if len(i) != 2:
                raise ValueError("element #%d has length %d; 2 is required"%(
                    n,
                    len(i),
                ))
            self[i[0]] = i[1]
            n += 1
        return

    def clear(self):
        """ D.clear() -> None. Remove all items from D """
        for k in self.keys():
            del self[key]
        return

    def items(self):
        """ Returns a list of (k,v) ordered pairs for this dict """
        return [ (k,self[k]) for k in self.keys() ]

    def values(self):
        """ Returns a list of the values of the dict in order """
        return [ self[k] for k in self.keys() ]

    def get(self, name, default=None):
        """ Returns the value for 'name' or default """
        try:
            return self[name]
        except KeyError:
            return default
    
    def pop(self, name, *a):
        """
        D.pop(name,d) -> value or d.

        Remove and return the item at 'name' or 'd' if 'd' is provided, if not
        a KeyError is raised.
        """
        try:
            value = self[name]
        except KeyError:
            if a:
                return a[0]
            raise
        del self[name]
        return value

    def popitem(self):
        """ D.popitem() -> (k,v). Remove and return an item from D """
        try:
            k,v = self.iteritems().next()
        except StopIteration:
            raise KeyError('dict is empty.')
        del self[k]
        return k,v

    def iterkeys(self):
        """ Returns an iterable object over the keys of this dict """
        for k in self.keys():
            yield k
        return
    __iter__ = iterkeys

    def iteritems(self):
        """ Returns an iterable object over (k,v) items of this dict """
        for k in self.keys():
            yield k,self[k]
        return

    def itervalues(self):
        """ Returns an iterable object over the values of this dict """
        for k in self.keys():
            yield self[k]
        return
        

class OrderedDict(DictMixin,dict):
    """
    Dictionary that maintains the order that elements were set in the dictionary
    so that all collection routines return with respect to that order.
    """
    __MasterClass__ = dict
    __fields = None

    def __init__(self, a=None, **kwargs):
        """
        Build an Ordered Dictionary from a single arg or a set of keyword args,
        you can have keyword args that are in the single argument which must
        be iterable (ie. a dict or tuple/list of 2 value pairs). In which case
        the keyword args override the ones in the arg.
        """
        self.__fields = []
        if a:
            self.update(a)
        self.update(kwargs)

    def copy(self):
        """ Return a shallow copy of this dictionary """
        d = self.__class__()
        for k in self.keys():
            d[k] = self[k]
        return d
    __copy__ = copy

    def clear(self):
        """ D.clear() -> None. Remove all items from D """
        while len(self.__fields):
            f = self.__fields.pop()
            del self[f]
        return

    def __setitem__(self, name, value):
        """ Set 'name' on us to have 'value', appending if needed """
        if name not in self.__fields:
            self.__fields.append(name)
        self.__MasterClass__.__setitem__(self, name, value)

    def __delitem__(self, name):
        """ Remove 'name' and its value from this dict """
        self.__MasterClass__.__delitem__(self, name)
        self.__fields.remove(name)

    def keys(self):
        """ Returns a list of the keys of the dict in order """
        return self.__fields[:]

    def popitem(self, index=None):
        """
        Remove and return a single item pair as (k,v) at index or from the
        bottom of the order if index is None.
        """
        index = index is None and len(self.__fields)-1 or index
        key = self.__fields[index]
        return key,self.pop(key)
        
    def sort(self, cmp=None, key=None, reverse=False):
        """
        Sort the order of this Dictionary like lists can be sorted.
        
        :Keywords:
            - `cmp` is the comparison method used to sort the index
            - `key` is a key to sort on usable
        """
        self.__fields.sort(cmp, key, reverse)

class BaseInsensitive(dict):
    """ Make Dictionaries insensitive """
    
    def __getitem__(self, name):
        """ Return an item's value from the dict """
        return dict.__getitem__(self, name.lower())
    
    def __setitem__(self, name, value):
        """ Set 'name' on us to have 'value', appending if needed """
        dict.__setitem__(self, name.lower(), value)

    def __delitem__(self, name):
        """ Remove 'name' and its value from this dict """
        dict.__delitem__(self, name.lower())

    def has_key(self, name):
        """ D.has_key(name) -> True/False if name is field in dict """
        return dict.has_key(self,name.lower())


class CaseInsensitiveOrderedDict(OrderedDict,BaseInsensitive):
    """
    This is an Case-Insensitive version of the OrderedDictionary class
    """
    __MasterClass__ = BaseInsensitive


