"""
This module contains the classes used to manage a basic tree.

$Id: Tree.py,v 1.18 2007/05/01 07:21:32 seoman Exp $
"""
__revision__  = "$Revision: 1.18 $"[11:-2]

from pyTools.stringwriter import StringWriter
from pyTools import HardError, SoftError, ErrorMetaClass
import types,copy

TREE_ROOT  = "Root of a Tree"
TREE_BRANCH= "Tree Branch"
TREE_LEAF  = "Tree Leaf"
EMPTY_NODE = "Empty Tree Node"

TREE_NODES = (TREE_BRANCH, TREE_LEAF, EMPTY_NODE)


class TreeError(SoftError):
    """ There was an error in the tree """
    
    node_repr = "<No data block>"
    
    def __init__(self, msg, details, node):
        """ Construct our custom exception to catch Unicode errors """
        self.msg = msg
        self.omsg = details
        self.node = node
        if node.data is not None:
            self.node_repr = node.data.__str__() + ' ' + repr(node.data)
        
    def __str__(self):
        """
        Return the error details on the child repr.
        """
        return "%s on %s" % (self.msg, self.node_repr)

    
class InsertionError(SoftError):
    """
    An error occurred trying to insert child at location.
    """
    
    node_repr = "<No node data block>"
    child_repr = "<No child data block>"
    
    def __init__(self, msg, node, child, location):
        """ Constructor """
        self.msg = msg
        self.node = node
        if node.data is not None:
            self.node_repr = node.data.__str__() + ' ' + repr(node.data)
        else:
            self.node_repr = repr(node)
        self.child = child
        if child.data is not None:
            self.child_repr = child.data.__str__() + ' ' + repr(child.data)
        else:
            self.child_repr = repr(child)
        self.location = location
        
    def __str__(self):
        """ 
        Return the error msg, location and child_repr.
        """
        return "%s on %s @ %s %s" % (
            self.msg, self.child_repr, self.node_repr, self.location
        )
        

class Leaf(StringWriter, object):
    """ Tree leaf, that is a childless tree node """
    meta_type = TREE_LEAF
    
    __metaclass__ = ErrorMetaClass
    
    Errors = (TreeError,)
    
    def __init__(self, _id, title='', data=None):
        """ Constructor """
        self.id = _id
        self.title = title
        self.data = data
        self.topNode = self.nextSibling = self.prevSibling = self.parent = None
    
    def __del__(self):
        """ Make sure the topNode is cleaned prior to deletion """
        self.data = None
        return 
        
    def __repr__(self):
        """ Return our python representation """
        s = "<%s %s '%s' with" % (self.meta_type,self.id, self.title)
        if self.data is None:
            s += "out data "
        else:
            s += " data %s " % repr(self.data)
        return "%s at %s>" % (s,id(self))

    def __str__(self):
        """ Write the tree out in a nice way, for debug """
        self.dump()
        return self.finaliseWriter()

    def _get_location(self):
        """ 
        Computes and returns the location of the current node in the tree. The
        location is a list of indexes, or positions of the branch in its parents
        list of children. If i have no parent then we'll try and walk up our
        previous siblings.
        """
        if self.parent is None:
            count = 0
            this = self.prevSibling
            while this is not None:
                count += 1
                this = this.prevSibling
            location = [ count, ]
        else:
            location = self.parent._get_location() or []
            location.append(self.parent.index(self))
        return location
    location = property(_get_location)
        
    def _numberProperties(self):
        """ Default properties for the number formatting """
        return {
            'propagate' : True,
            'spacer'    : '.',
            'format'    : '%d',
            'multiplier': 1,
            'start'     : 0,
        }
        
    def _get_number(self):
        """ 
        Return a number representation of the nodes location 
        """
        if self.meta_type == EMPTY_NODE:
            props = self.parent.last._numberProperties()
        else:
            props = self._numberProperties()
        number = ""
        if self.parent is None:
            start = int(props['start'])
            prev = self.prevSibling
            while prev is not None:
                start += 1
                prev = prev.prevSibling
            start *= int(props['multiplier'])
        else:
            start = self.parent.index(self)
            if props['propagate']:
                number = self.parent._get_number() + props['spacer']
        return number + (props['format'] % start)
    number = property(_get_number)

    def _get_isEmpty(self):
        """ This node is empty iff it is a EMPTY_NODE and has no children """
        return False
    isEmpty = property(_get_isEmpty)

    def dump(self, writer=None, indt='', tab='  ', endl='\n'):
        """ Do a printout of the current tree """
        if writer is None:
            writer = self.getWriter()
        location = self._get_number()
        if location:
            location += " - "
        writer.write("%s%s" % (indt, location))
        if self.data is not None:
            # if its a unicode type then use it as is, otherwise we need to be
            # clever since unicode does instance checks in
            if type(self.data) is unicode:
                data = self.data
            # check for o.__unicode__ instead of using unicode(o) since the
            # latter checks the object type which breaks if the object has an
            # acquisition wrapper. objects should really have a __unicode__
            # method by default if you ask me but they don't so do a check first
            elif hasattr(self.data, '__unicode__'):
                data = self.data.__unicode__()
            # otherwise get the str version and try and unicode it
            else:
                data = self.data.__str__()
            # if we don't have a unicode string by now, try and convert it
            if type(data) is not unicode:
                try:
                    data = unicode(data, 'iso-8859-1')
                except UnicodeError, e:
                    raise TreeError("Error encoding data to unicode.", e, self)
        else:
            data = u"%s: %s" % (self.id, self.title)
        try:
            writer.write(data)
        except UnicodeError, details:
            raise TreeError(
                "Unicode writing tree element %s at %s"%(self.id,self.location),
                self
            )
        writer.write(endl)
        return

    def unlink(self):
        """ Remove me from the tree """
        if self.parent is not None:
            self.parent.remove(self)
        if self.nextSibling is not None:
            self.nextSibling.prevSibling = self.prevSibling
        if self.prevSibling is not None:
            self.prevSibling.nextSibling = self.nextSibling
        self.topNode=self.prevSibling=self.nextSibling=self.parent=None
        return self

    def free(self): 
        self.unlink()

    def createEmptyNode(self, _id):
        return self.topNode.createEmptyNode(_id)

    def createBranch(self, _id, title, data=None):
        return self.topNode.createBranch(_id,title,data)
        
    def createLeaf(self, _id, title, data=None):
        return self.topNode.createLeaf(_id,title,data)


class Branch(Leaf, list):
    """ 
    A node has children which are identified only by position, they are nameless
    and have pointers to the next sibling in the line.
    """
    meta_type = TREE_BRANCH
    
    Errors = Leaf.Errors + (InsertionError,)
    
    
    def __init__(self, _id, title, data):
        list.__init__(self)
        Leaf.__init__(self, _id, title, data)
    
    def __eq__(self, other):
        """ Override the list __eq__ """
        if self is other:
            return True
        return False

    def __ne__(self, other):
        """ Override the list __eq__ """
        return not self.__eq__(other)
    
    def __getitem__(self, index):
        """ Return the item at index where index uses the start offset """
        node = self.createEmptyNode(self.getChildType(None))
        index -= int(node._numberProperties()['start'])
        return list.__getitem__(self,index)

    def __setitem__(self, index, value):
        raise NotImplementedError("use replace/insert/append instead.")

    def __delitem__(self, index):
        raise NotImplementedError("use unlinkChild and free instead.")
    
    def hasChild(self, _id, deep=False):
        """
        Is there a child with this `id` in the tree from this point down.
        
        :Parameters:
            - `_id` is the identifier provided when nodes in the tree are made
            
        :Keywords:
            - `deep` is False by default and mean we'll look down the tree from
              this point looking for a child with the provided `id`
              
        :Returns:
            - True if it finds a child with this `id`, False otherwise
        """
        child = self._get_first()
        while child is not None:
            if not child._get_isEmpty():
                if child.id == _id or (deep and child.hasChild(_id, True)):
                    break
            child = child.nextSibling
        else:
            return False
        return True
    
    def index(self, value):
        """ return the index based on the start offset """
        return list.index(self, value) + int(value._numberProperties()['start'])
    
    def dump(self, writer=None, indt='', tab='  ', endl='\n'):
        """ Do a printout of the current tree """
        if writer is None:
            writer = self.getWriter()
        Leaf.dump(self,writer,indt,tab,endl)
        child = self._get_first()
        while child is not None:
            if not child._get_isEmpty():
                child.dump(writer,indt+tab,tab,endl)
            child = child.nextSibling
        return

    def _get_isEmpty(self):
        """ This node is empty iff it is a EMPTY_NODE and has no children """
        return False
    isEmpty = property(_get_isEmpty)

    def _get_first(self):
        """ Returns the first child """
        if list.__len__(self):
            return list.__getitem__(self, 0)
        return None
    first = property(_get_first)
        
    def _get_last(self):
        """ Returns the last child """
        if list.__len__(self):
            return list.__getitem__(self, -1)
        return None
    last = property(_get_last)
    
    def _get_children(self):
        """ Returns the inner list of children """
        return [ o for o in self ]
    children = property(_get_children)
    
    def getChildType(self, subchild):
        """
        Branch.getChildType(subchild) -> String
        
        Return a string for the Id of child given subchild is a child or sub-
        child of child.
        """
        return "empty"
    
    def _appendChild(self, child):
        """ Internal method to append a child to our children """
        if child.parent is not None:
            child = child.parent.unlinkChild(child)
        child.parent = self
        child.prevSibling = self._get_last()
        if child.prevSibling is not None:
            child.prevSibling.nextSibling = child
        self.append(child)
        return child
       
    def _insertChild(self, location, child):
        """ 
        This is an internal method used by the tree, you should not be calling
        this method directly. Instead call T.insertChild() with the same args
        and result.
        """
        # get the index for this subchild from location
        if type(location) == list:
            index = location.pop(0)
        elif type(location) in (int,long):
            index = location
            location = []
        else:
            raise ValueError("first arg should be a list or int.")
        # determine the index based on the start offset
        node = self.createEmptyNode(self.getChildType(child))
        offset = int(node._numberProperties()['start'])
        if index < offset:
            raise ValueError("location below starting position: %d" % index)
        # create empty children to make sure we have enough
        while len(self) <= (index - offset):
            empty = self.createEmptyNode(self.getChildType(child))
            self.appendChild(empty)
        # get the child at index and replace or call insertChild on
        insNode = self[index]
        if location:
            insNode.insertChild(location, child)
        elif insNode.meta_type == EMPTY_NODE:
            oldChild = self.replaceChild(insNode, child)
            if child.meta_type == TREE_BRANCH:
                self.moveChildren(oldChild, child)
            oldChild.free()
        else:
            l = insNode.location
            raise InsertionError("Node exists at index %d"%index,insNode,child,l)
        return
        
    def appendChild(self, child):
        """
        T.appendChild(child) -> newChild

        Adds child to the end of this nodes current list of children updating
        all links and returning the new child.
        """
        if not isinstance(child, (Branch, Leaf, EmptyNode)):
            raise TypeError(
                "expected Branch, Leaf or Empty; got %s" % 
                child.__class__.__name__
            )
        child = self._appendChild(child)
        child.topNode = self.topNode
        return child
        
    def insertChild(self, location, child):
        """
        T.insertChild(location,child) --> None

        Insert a child node (must be a tree node) into this Tree using location
        as a depth wise position indicator. Location should be list of indexes
        which identify the position of the child relative to this Branch node.
        The indexes should take into account the starting number of the levels
        in the tree. So if the second level starts at 2 and a location of [1,2]
        was used then an error would be raised. A location of [1,3] would add
        a single EMPTY_NODE before adding the child.

        EMPTY_NODE's are added to make up any locations that are not occupied
        to preserve the order of children. These will be replaced if a real
        child is added at those locations.

        Unlike most insert operations, if the location is occupied by anything
        other than an EMPTY_NODE the insertion will fail. This is because tree
        can be assembled piece meal.
        """
        if not isinstance(child, (Branch, Leaf, EmptyNode)):
            raise TypeError(
                "expected Branch, Leaf or Empty; got %s" % 
                child.__class__.__name__
            )
        child.topNode = self.topNode
        self._insertChild(location, child)

    def moveChildren(self, oldChild, newChild):
        """ 
        Move the children of one node to another.
         
        :Parameters:
            - `oldChild` is a BRANCH (usually an empty node) that has been 
              removed from the tree
            - `newChild` is a replacement for `oldChild` that wants to inherit
              its children
        
        Remember that the _real_ children of this node may be split between the
        two nodes. We need to combine them in an intelligent manner.
        """
        if oldChild.meta_type == TREE_LEAF:
            return
        if newChild.meta_type != TREE_BRANCH:
            return
        # we going in reverse direction cause we're editing the oldChild in 
        # place which will screw up the index
        child = oldChild.last
        while child is not None:
            next = child.prevSibling
            if child.isEmpty:
                child.free()
            else:
                newChild.insertChild([oldChild.index(child),], child)
            child = next

    def replaceChild(self, oldChild, newChild):
        """ Replace one child with another, effectively an unlink and insert """
        if newChild is oldChild:
            return
        if newChild.parent is not None:
            newChild.parent.unlinkChild(newChild)
        if oldChild not in self:
            raise AttributeError("Child doesn't exist in this branch.")
        index = list.index(self, oldChild)
        list.__setitem__(self, index, newChild)
        newChild.topNode = oldChild.topNode
        newChild.parent = oldChild.parent
        oldChild.parent = oldChild.topNode = None
        newChild.prevSibling = oldChild.prevSibling
        newChild.nextSibling = oldChild.nextSibling
        oldChild.prevSibling = oldChild.nextSibling = None
        if newChild.prevSibling is not None:
            newChild.prevSibling.nextSibling = newChild
        if newChild.nextSibling is not None:
            newChild.nextSibling.prevSibling = newChild
        return oldChild

    def unlinkChild(self, child):
        """ Remove an object from the tree, object is a child of mine """
        if child not in self:
            raise TreeError("Object is not a child of mine.")
        return child.unlink()

    def free(self):
        """ Cleans up the whole tree """
        child = self.first
        while child is not None:
            child.free()
            child = self.first
        self.unlink()
       

class EmptyNode(Branch):
    """ This is a space node, that is an empty childless leaf """
    meta_type = EMPTY_NODE
    
    def __init__(self, _id):
        """ Constructor """
        Branch.__init__(self,_id,'Empty Node')
    
    def _get_isEmpty(self):
        """ This node is empty iff it is a EMPTY_NODE and has no children """
        for child in self.children:
            if child.isEmpty is False:
                return False
        return True
    isEmpty = property(_get_isEmpty)


class Tree(Branch):
    """ This is the root of the tree """
    meta_type = TREE_ROOT
     
    Empty  = EmptyNode
    Leaf   = Leaf
    Branch = Branch
    
    def __init__(self, _id, title=''):
        """ Constructor """
        Branch.__init__(self, id, title, None)
        self.topNode = self
        
    def __repr__(self):
        """ Return our python representation """
        return "<%s %s '%s' at %s>"%(self.meta_type,self.id,self.title,id(self))

    def free(self):
        while len(self):
            self.first.free()

    def numberToLocation(self, number):
        """ Simple conversion from a number to location """
        return map(int, number.replace('-','.').split('.'))
        
    def _get_location(self):
        """ Override, top node has no location """
        return ""
    
    def locateChild(self, location):
        """
        Get a TreeNode based on its location in the Tree.
        
        :Parameters:
            - `location` is the index location as returned from child.location
        
        The location should be the full location as returned by child.location
        and nota relative location.
        """
        this = self
        while location:
            index = location.pop(0)
            if len(this) >= index:
                raise TreeError('invalid location', '', this)
            this = this[index]
        return this

    def _get_number(self, propagate=True, format="%d", spacer=".", start=1):
        """ Override, no number for the top node """
        return ""

    def appendChild(self, child):
        if not isinstance(child, (Branch,Leaf,EmptyNode)):
            raise TypeError("Cannot appendChild of invalid type.")
        child = self._appendChild(child)
        child.topNode = self
        return child
        
    def insertChild(self, location, child):
        if not isinstance(child, (Branch,Leaf,EmptyNode)):
            raise TypeError("Cannot appendChild of invalid type.")
        child.topNode = self
        self._insertChild(copy.copy(location), child)

    def createBranch(self, _id, title, data=None):
        """ Returns a branch, ease method to allow replacement """
        obj = self.Branch(_id, title, data)
        obj.topNode = self
        return obj
        
    def createLeaf(self, _id, title, data=None):
        """ Returns a leaf, ease method to replace different leaf nodes """
        obj = self.Leaf(_id, title, data)
        obj.topNode = self
        return obj
        
    def createEmptyNode(self, _id):
        """ Returns a leaf, ease method to replace different leaf nodes """
        obj = self.Empty(_id)
        obj.topNode = self
        return obj
        