"""
This is a person or contact object, this can be seen as a user object also.
Its basic use is as a mixin with some storage object like the DataStore or a
SimpleObject.

These user objects do not have authentication support, for that you need to 
couple user objects with an authentication source of some type.

$Id: Person.py,v 1.2 2005/02/02 05:49:00 seoman Exp $
"""
__revision__ = "$Revision: 1.2 $"[11:-2]


from pyTools.PropertyManager import PropertyAware


class BasicUser(PropertyAware):
    """ 
    Basic user object with standard set of methods:
    
      o getUserName - returns the username
      o getFullName - returns the <firstname> <lastname> 
      o getEmail    - returns a full address <fullname> <email>
      
    Standard properties for users are:
        
      o username,
      o password,
      o firstname,
      o lastname,
      o email.
      
    Any others should be added or modified using PropertyAware.
    """
    meta_type = "Basic User Object"
    
    _properties = (
        {'id':'username','type':'string'},
        {'id':'password','type':'string','mode':'hw'},
        {'id':'firstname','type':'string','mode':'w'},
        {'id':'lastname','type':'string','mode':'w'},
        {'id':'email','type':'string','mode':'w'},
    )
    
    def getUserName(self):
        """ Returns the username """
        return self.getProperty('username')

    def getFullName(self):
        """ Returns the first last combined fullname """
        return "%s %s" % (
            self.getProperty('firstname'),
            self.getProperty('lastname')
        )
    fullname = property(getFullName)

    def getEmail(self, expanded=True):
        """ Returns an expanded email address """
        if not expanded:
            return self.getProperty('email')
        else:
            return "%s <%s>" % (self.fullname,self.getProperty('email'))


class LDAPUser(BasicUser):
    """ 
    LDAP User is a user object built from an LDAP Source, contains some extra
    methods from the basic user object:

      o getDN - returns the distinguished name

    """
    meta_type = "LDAP User Object"
    
    _properties = BasicUser._properties + (
        {'id':'dn','type':'string','mode':'h'},
        {'id':'uid','type':'string','mode':'h'},
    )
    
    def _postCreate(self):
        """ """
        pass

    def getFullName(self):
        """ Returns the fullname of the user """
        return self.get('cn')
    fullname = property(getFullName)

    def getEmail(self, expanded=True):
        """ Returns an expanded email address """
        if not expanded:
            return self.get('mail')[0]
        else:
            return "%s <%s>" % (self.getFullName(),self.get('mail')[0])


class SQLUser(BasicUser):
    meta_type = "SQL User Object"

