"""
Test suite for DataStore Object classes, we'll do a fairly complicated test
that sets up and edits the users/roles example used in the docstring for the
module.

$Id: test_DataStore.py,v 1.7 2006/04/26 07:07:57 seoman Exp $
"""
__revision__ = "$Revision: 1.7 $"[11:-2]

from pyTools.Testing import testRunner
from pyTools.TestCases import DataStoreBase

from pyTools.dbPool.Query import *
from pyTools.Objects import ObjectExists, NoSuchObject
from pyTools.Objects import DataStore

from mx import DateTime

class Role(DataStore.DS_Object, object):
    __TableName__ = "roles"
    __TableType__ = "normal"
    __IndexId__   = "roleid"
    
    _properties = (
        {'id':'roleid',    'type':int,'mode':'p',},
        {'id':'name',      'type':str,'mode':'w',},
    )


class Roles(DataStore.DS_Table,object):
    __RecordClass__ = Role


class Person(DataStore.DS_Object,object):
    __TableName__ = "users"
    __TableType__ = "normal"
    __IndexId__   = "userid"

    _properties = (
        {'id':'userid',    'type':int,'mode':'p',},
        {'id':'username',  'type':str,'mode':'wir',},
        {'id':'password',  'type':str,'mode':'w',},
        {'id':'firstname', 'type':str,'mode':'w',},
        {'id':'lastname',  'type':str,'mode':'w',},
        {'id':'start_time','type':DateTime.DateTimeType,'mode':'wr',},
        {'id':'sex',       'type':str,'mode':'w',},
    )


class People(DataStore.DS_Table,object):
    __RecordClass__ = Person


class TC_DataStore:
    """ Tests the DS_Table Mixin class """

    _objects = (Roles,People)

    def test_DSConnection_01(self):
        """ Testing table has DS connection """
        self.assert_(hasattr(self,'People'),"People not set.")
        self.assert_(hasattr(self,'Roles'),"Roles not set.")
        results = self.cursor.execute(Select('users'))
        self.assert_(
            not results,
            "There is data already in the users table: %s" % results
        )
        results = self.cursor.execute(Select('roles'))
        self.assert_(
            not results,
            "There is data already in the roles table: %s" % results
        )
        results = self.cursor.execute(Select('user_roles'))
        self.assert_(
            not results,
            "There is data already in the user_roles table: %s" % results
        )
        results = self.People.getChildIds()
        self.assertEqual(len(results),0,"People getChildIds() failed: %s"%results)
        results = self.Roles.getChildIds()
        self.assertEqual(len(results),0,"Roles getChildIds() failed: %s"%results)

    def test_Creating_02(self):
        """ Testing creation of objects """
        now = DateTime.now()
        now = now - DateTime.RelativeDateTime(seconds=now.second%1)
        child = self.People.addChild(
            username='seoman',
            password='chronos',
            start_time=now,
            firstname='Simon',
            lastname='Hookway',
            sex='m',
        )
        # Clear the cache
        self.People.RecordCache.clear()
        self.assert_(child,"Child is false: %s"%child)
        self.assertEqual(
            child.userid,1,
            "Child should have a userId of 1: %s" % child.userid
        )
        self.assertEqual(child.username,"seoman","'username' incorrect: %s"%child.username)
        self.assertEqual(child.password,"chronos","'password' incorrect: %s"%child.password)
        self.assertEqual(child.firstname,"Simon","'firstname' incorrect: %s"%child.firstname)
        self.assertEqual(child.lastname,"Hookway","'lastname' incorrect: %s"%child.lastname)
        self.assertEqual(child.sex,"m","'sex' incorrect: %s"%child.sex)
        self.assertEqual(child.start_time,now,"'start_time' incorrect: %s"%child.start_time)
        result = self.cursor.execute(Select('users'))
        self.assertEqual(len(result),1,"Select gave result incorrect length: %d"%len(result))
        self.assertEqual(
            result.getValue(0,"username"),"seoman",
            "Select gave incorrect 'username': %s" % result.getValue(0,"username")
        )
        self.assertEqual(
            result.getValue(0,"password"),"chronos",
            "Select gave incorrect 'password': %s" % result.getValue(0,"password")
        )
        self.assertEqual(
            result.getValue(0,"firstname"),"Simon",
            "Select gave incorrect 'firstname': %s" % result.getValue(0,"firstname")
        )
        self.assertEqual(
            result.getValue(0,"lastname"),"Hookway",
            "Select gave incorrect 'lastname': %s" % result.getValue(0,"lastname")
        )
        self.assertEqual(
            result.getValue(0,"sex"),"m",
            "Select gave incorrect 'sex': %s" % result.getValue(0,"sex")
        )
        self.assertEqual(
            result.getValue(0,"start_time"),now,
            "Select gave incorrect 'start_time': %s" % result.getValue(0,"start_time")
        )
        childIds = self.People.getChildIds()
        self.assertEqual(childIds,[1,],"getChildIds #2 incorrect: %s"%childIds)
        child = self.People.addChild(
            username='fredp',
            password='gonetomorrow',
            start_time=now+DateTime.RelativeDateTime(minutes=34),
            firstname='Freddie',
            lastname='Baker',
            sex='m',
        )
        childIds = self.People.getChildIds()
        self.assertEqual(childIds,[1,2],"getChildIds #3 incorrect: %s"%childIds)
        self.assertEqual(
            child.userid,2,
            "Child should have a userId of 2: %s" % child.userid
        )
         
    def test_Getting_03(self):
        """ Testing collection of objects """
        results = self.cursor.execute(Select('users'))
        # make sure the cache is empty
        self.People.RecordCache.clear()
        child = self.People.getChild(1)
        self.assert_(child,"Getting child failed: %s" % child)
        for name in child.propertyNames():
            self.assertEqual(
                child[name],results.getValue(0,name),
                "'%s' is not the same for the fetched child: %s" % (name,results.getValue(0,name))
            )
        self.failUnlessRaises(
            self.People.NoSuchObject,
            self.People.getChild,
            3
        )
        
    def test_Cache_04(self):
        """ Testing caching """
        self.People.RecordCache.clear()
        self.assertEqual(len(self.People.RecordCache),0,"Cache should be empty.")
        child1 = self.People.getChild(1)
        self.assertEqual(len(self.People.RecordCache),1,"Cache should be 1.")
        child2 = self.People.getChild(2)
        self.assertEqual(len(self.People.RecordCache),2,"Cache should be 2.")
        child3 = self.People.getChild(1)
        self.assertEqual(len(self.People.RecordCache),2,"Cache should be 2.")
        self.assertEqual(child1,child3,"the first and third children are different.")
        self.assertEqual(
            id(child1),id(child3),
            "child1 and child3 are not the same object."
        )
        
    def test_updating_05(self):
        """ Testing updating objects """
        child = self.People.getChild(2)
        self.assert_(child._p_changed is False,"_p_changed is not false.")
        child['password'] = 'newpass'
        self.assert_(child._p_changed is True,"_p_changed is not true.")
        child.__update__()
        self.assert_(child._p_changed is False,"_p_changed is not false after update.")
        self.People.RecordCache.clear()
        child = self.People.getChild(2)
        self.assertEqual(
            child['password'],'newpass',
            "Password on child did not change: %s" % child['password']
        )
    
    def test_Deleting_06(self):
        """ Testing deletion of objects """
        


_mysql_table_users = """
CREATE TABLE %s (
    userid int(11) NOT NULL auto_increment,
    username varchar(128) NOT NULL DEFAULT '',
    password varchar(64) NOT NULL DEFAULT '',
    start_time datetime DEFAULT NULL,
    firstname varchar(64) DEFAULT NULL,
    lastname varchar(64) DEFAULT NULL,
    sex enum('m','f') DEFAULT 'm',
    __PropModes__ text,
    primary key (userid),
    key username (username)
) type=INNODB;"""

_mysql_table_roles = """
CREATE TABLE %s (
    roleid int(11) NOT NULL auto_increment,
    name varchar(32) NOT NULL DEFAULT '',
    description text NOT NULL DEFAULT '',
    security_code varchar(8) NOT NULL DEFAULT '1234',
    __PropModes__ text,
    primary key (roleid),
    key name (name)
) type=INNODB;"""

_mysql_table_userroles = """
CREATE TABLE %s (
    id int(11) NOT NULL auto_increment,
    roleid int(11),
    userid int(11),
    __PropModes__ text,
    primary key (id)
) type=INNODB;"""


class TC_DataStore_MySQL(TC_DataStore,DataStoreBase):
    """ Test DataStore with MySQL """

    dependencies = DataStoreBase.dependencies + ('TC_MySQL',)

    identifier = 'mysql'
    containerType = "mysql"
    username = "testsuite"
    password = "hg873hS"
    hostname = "172.16.4.150"
    database = 'testSuite'

    tables = [
        ('users',_mysql_table_users),
        ('roles',_mysql_table_roles),
        ('user_roles',_mysql_table_userroles),
    ]
    
    def test_Connector_00(self):
        """ Test we are using the right Connector """
        self.assertEqual(
            self.connector.type,"MySQL Connector",
            "Using incorrect Connector type for test: %s" % self.connector.type
        )


_sqlite_table_users = """
CREATE TABLE %s (
    userid integer primary key,
    username text,
    password text,
    start_time date,
    firstname text,
    lastname text,
    sex text DEFAULT 'm',
    __PropModes__ text
)"""

_sqlite_table_roles = """
CREATE TABLE %s (
    roleid integer primary key,
    name text NOT NULL,
    description text,
    security_code text DEFAULT '1234',
    __PropModes__ text
)"""

_sqlite_table_userroles = """
CREATE TABLE %s (
    id integer primary key,
    roleid integer,
    userid integer,
    __PropModes__ text
)"""


class TC_DataStore_SQLite(TC_DataStore,DataStoreBase):
    """ Test DataStore with SQLite """
    
    dependencies = DataStoreBase.dependencies + ('TC_MySQL',)

    identifier = 'sqlite_DS'
    containerType = 'sqlite'
    hostname = username = password = None
    database = "/tmp/dbDataStore.sqlite"
    
    tables = [
        ('users',_sqlite_table_users),
        ('roles',_sqlite_table_roles),
        ('user_roles',_sqlite_table_userroles),
    ]

    def test_Connector_00(self):
        """ Test we are using the right Connector """
        self.assertEqual(
            self.connector.type,"SQLite Connector",
            "Using incorrect Connector type for test: %s" % self.connector.type
        )


if __name__ == "__main__":
    testRunner(dependenciesOn=False)
