"""
Test suite for Tree Object class

$Id: test_tree.py,v 1.7 2006/05/08 01:03:15 seoman Exp $
"""
__revision__ = "$Revision: 1.7 $"[11:-2]

from pyTools.TestCases import ObjectTestCase
from pyTools.Testing import testRunner

from pyTools.Objects import Tree


def _numberProperties(self):
    d = Tree.Leaf._numberProperties(self)
    if self.id == 'A':
        d['start'] = 1
    elif self.id == 'B':
        d['start'] = 0
    else:
        d['start'] = 2
    return d

def getChildType(self,subchild):
    if self.id == 'A':
        return 'B'
    elif self.id == 'B':
        return 'C'
    elif self.id == 'C':
        return 'B'
    else:
        return 'A'

class EmptyNode(Tree.EmptyNode):
    _numberProperties = _numberProperties
    getChildType = getChildType

class Leaf(Tree.Leaf):
    _numberProperties = _numberProperties
    getChildType = getChildType
        
class Branch(Tree.Branch):
    _numberProperties = _numberProperties
    getChildType = getChildType
    
class MyTree(Tree.Tree):
    Leaf   = Leaf
    Branch = Branch
    Empty  = EmptyNode
    _numberProperties = _numberProperties
    getChildType = getChildType
    
    
class TestTree(ObjectTestCase):
    """ Testing the Tree """

    def test_basic_01(self):
        """ Make a basic tree """
        tree = Tree.Tree('top','The Tree Top')
        # Add a node
        tree.appendChild(tree.createEmptyNode('E'))
        self.assertEqual(tree.first,tree.last,"First is not the last Child.")
        self.assert_(tree.first is not None,"Tree has no Children")
        self.assert_(tree.first.isEmpty,"Empty node is not empty.")
        # Add another
        tree.appendChild(tree.createBranch('ff','second child'))
        self.failIf(tree.last == tree.first,"Only one child.")
        self.assertEqual(tree.first.nextSibling,tree.last,"last is not second")
        self.assertEqual(tree.last.prevSibling,tree.first,"prev is not first")
        # Add a subchild
        tree.last.appendChild(Tree.Branch('N55','First Sub Child'))
        child = tree.last.first
        self.assertEqual(child.id,'N55',"First Sub has wrong id.")
        self.assertEqual(child.title,'First Sub Child',"First Sub title is wrong.")
        # Insert a child
        tree.insertChild([2,1],Tree.Leaf('N3334','Data',{'s':1,}))
        self.assertNotEqual(tree.last,tree.first,"Only one child.")
        self.assertNotEqual(tree.first.nextSibling,tree.last,"Only two children")
        child = tree[1]
        self.assertEqual(child.nextSibling,tree.last,"next is not last.")
        self.assertEqual(tree.first.nextSibling,child,"next is not child.")
        self.assertEqual(child.prevSibling,tree.first,"prev is not first.")
        self.assertEqual(tree.last.prevSibling,child,"prev is not child.")
        self.assert_(not tree.last.isEmpty,"New child is showing empty.")
        child = tree.last
        self.assertEqual(child.meta_type,Tree.EMPTY_NODE,"1st not empty.")
        self.assertEqual(len(child),2,"Children of last is wrong.")
        self.assertEqual(child.last.id,"N3334","2nd Node added incorrect.")
        self.assertEqual(child.first.nextSibling,child.last,"2nd isn't last.")
        # and free the tree
        tree.free()

    def test_child_02(self):
        """ Testing location <--> number """
        tree = MyTree('top',"The roots")
        ct = tree.getChildType(None)
        self.assertEqual(ct,'A',"below root should be A not %s"%ct)
        child = tree.createEmptyNode(ct)
        self.assertEqual(
            child.id,'A',"child below root is not accepting type: %s" % child.id
        )
        start = int(child._numberProperties()['start'])
        self.assertEqual(start,1,"Starting number for A is not 1 but %d"%start)
        ct = child.getChildType(None)
        self.assertEqual(ct,'B',"below A should be B not %s"%ct)
        child = tree.createEmptyNode(ct)
        self.assertEqual(
            child.id,'B',"child below A is not accepting type: %s" % child.id
        )
        start = int(child._numberProperties()['start'])
        self.assertEqual(start,0,"Starting number for B is not 0 but %d"%start)
        # and free the tree
        tree.free()
    
    def test_index_03(self):
        """ Testing index with starting offset """
        tree = MyTree('top','canopy')
        child = tree.createBranch('A', "wadda")
        self.assertEqual(
            child._numberProperties()['start'], 1,
            "A type is not 1: %d" % child._numberProperties()['start']
        )
        tree.insertChild([3,], child)
        self.assertEqual(
            child.location, [3,],
            "child location is not [3,]; got %s" % child.location,
        )
        self.assertEqual(
            len(tree), 3,
            "should be 3 children of tree; got %d" % len(tree)
        )
        self.assertEqual(
            tree.index(child), 3,
            "child should have an index of 3, not %d" % tree.index(child)
        )
        # and free the tree
        tree.free()
    
    def test_insert_03(self):
        """ Testing variable locationing """
        tree = MyTree('top','canopy')
        tree.insertChild([3,0],tree.createLeaf('B','First Node'))
        self.assertEqual(
            len(tree),3,
            "tree should have 3 children: %d"%len(tree))
        for c in tree:
            self.assertEqual(
                c.meta_type,Tree.EMPTY_NODE,
                "TopLevel in the tree should be EmptyNode's: %s" % c.meta_type
            )
        self.assertEqual(
            tree.last.first.meta_type,Tree.TREE_LEAF,
            "new node is not a leaf: %s" % tree.last.first.meta_type
        )
        tree.insertChild([2,1,4],tree.createLeaf('C','Second Node'))
        self.assertEqual(
            len(tree[2][1]),3,
            "Second child is not the correct length: %d" % len(tree[2][1])
        )
        tree.insertChild([2,1,3,0],tree.createLeaf('B','Third Node'))
        tree.insertChild([1,1],tree.createLeaf('B','Forth Node'))
        tree.insertChild([2,1,3],tree.createBranch('C','Fifth Node'))
        tree.insertChild([2,1],tree.createBranch('B','Sixth Node'))
        tree.insertChild([2,0],tree.createLeaf('B','Seven Node'))
        tree.insertChild([2,1,3,1],tree.createLeaf('B','Eight Node'))
        self.assertEqual(
            len(tree[2][1][3]),2,
            "Fifth child is not the correct length: %d" % len(tree[2][1][3])
        )
        self.assertEqual(
            len(tree[1]),2,
            "Forth child is not the correct length: %d" % len(tree[1])
        )
        self.assertEqual(
            len(tree[3]),1,
            "Forth child is not the correct length: %d" % len(tree[3])
        )
        # and free the tree
        tree.free()
        
    def test_moveChild_04(self):
        """ Testing split child inserts """
        tree = Tree.Tree('top','canopy')
        # create a node with children at 4 and 5
        node1 = tree.createBranch("B", "node1")
        node1.insertChild([5,], tree.createLeaf("5", "from node1-5"))
        node1.insertChild([3,], tree.createLeaf("3", "from node1-3"))
        # now add 2 and 3 to the tree
        tree.insertChild([1,2], tree.createLeaf('2', 'from tree-2'))
        tree.insertChild([1,4], tree.createLeaf('4', 'from tree-4'))
        # now add node1 with its children to replace the EMPTY_BRANCH
        tree.insertChild([1,], node1)
        self.assertEqual(
            len(tree[1]), 6, 
            "There's too many children in replace: %d/6" % len(tree[1])
        )
        self.assertEqual(
            tree[1][1].meta_type, Tree.EMPTY_NODE,
            "First one should be an empty node: %s" % tree[1][1]
        )
        self.assertEqual(
            tree[1][2].title, "from tree-2",
            "Second node is not right: %s" % tree[1][2]
        )
        self.assertEqual(
            tree[1][3].title, "from node1-3",
            "Third node is not right: %s" % tree[1][3]
        )
        self.assertEqual(
            tree[1][4].title, "from tree-4",
            "Forth node is not right: %s" % tree[1][4]
        )
        self.assertEqual(
            tree[1][5].title, "from node1-5",
            "Fifth node is not right: %s" % tree[1][5]
        )
        # and free the tree
        tree.free()


if __name__ == "__main__":
    testRunner(dependenciesOn=False)

