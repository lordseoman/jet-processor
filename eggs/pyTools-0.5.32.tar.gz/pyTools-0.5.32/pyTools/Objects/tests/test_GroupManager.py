"""
Test suite for DataStore Object classes, we'll do a fairly complicated test
that sets up and edits the users/roles example used in the docstring for the
module.

$Id: test_GroupManager.py,v 1.1 2005/10/24 05:37:05 seoman Exp $
"""
__revision__ = "$Revision: 1.1 $"[11:-2]

from pyTools.Testing import testRunner
from pyTools.TestCases import DataStoreBase

from pyTools.dbPool.Query import *
from pyTools.Objects import GroupManager

from mx import DateTime
from pprint import pprint


_sqlite_table_1 = """
CREATE TABLE %s (
    group_id integer primary key,
    parent_id integer default 0,
    order_no integer default 0,
    name text,
    state_info text,
    __PropModes__ text
)"""


class User(GroupManager.GroupAware, object):
    
    def __init__(self, name, email):
        self.name = name
        self.email = email
        
    def getName(self):
        return self.name
    
    def allowedInGroup(self, object, group):
        return True
        
    def memberAdded(self, object, group):
        return
        
    def memberRemoved(self, object, group):
        return
        
    def addedToGroup(self, group):
        return
        
    def removedFromGroup(self, group):
        return


class GroupMember(GroupManager.GroupMember):
    __TableName__ = 'groups'
    
    
class Groups(GroupManager.GroupHandler):
    __RecordClass__ = GroupMember


class TC_GroupManager(DataStoreBase):
    """ Test DataStore with SQLite """
    
    dependencies = DataStoreBase.dependencies + ('TC_SQLite',)

    identifier = 'sqlite_DS'
    containerType = 'sqlite'
    hostname = username = password = None
    database = "/tmp/dbDataStore.sqlite"
    
    tables = [
        ('groups', _sqlite_table_1),
    ]
    
    _objects = ( Groups, )

    def test_Connector_00(self):
        """ Make sure we are using the right Connector """
        self.assertEqual(
            self.connector.type,"SQLite Connector",
            "Using incorrect Connector type for test: %s" % self.connector.type
        )
        
    def test_named_01(self):
        """ Testing basic Named Groups """
        cIds = self.Groups.getChildIds()
        self.assertEqual(cIds, [], "Groups should be empty: %s" % cIds)
        root = self.Groups.addChild(name="Root")
        self.assert_(root, "Adding root failed to return: %s" % root)
        self.assertEqual(
            root['parent_id'], 0, 
            "'parent_id' should be 0: %s" % root['parent_id']
        )
        self.assertEqual(
            root['state_info'], "", 
            "'state_info' should be an empty string: %s" % root['state_info']
        )
        self.assertEqual(
            root['name'], "Root", "'name' should be 'Root': %s" % root['name']
        )
        self.assertEqual(root.ob_ref,None,"Named Group should have None ob_ref")
        self.Groups.RecordCache.clear()
        cIds = self.Groups.getChildIds()
        self.assertEqual(len(cIds), 1, "Should only be 1 child now: %s" % cIds)
        root2 = self.Groups.getChild(1)
        self.assertEqual(root, root2, "Collected is not the same as made.")
        self.assertRaises(AttributeError, getattr, root2 , 'aq_self')
        staff = root2.addChild(name="Staff Members")
        self.assert_(staff, "Adding staff failed to return: %s" % staff)
        self.assertEqual(
            staff['parent_id'], root2.id,
            "staff's parent is not correct: %s" % staff['parent_id']
        )
        cIds = self.Groups.getChildIds()
        self.assertEqual(len(cIds), 1, "Should still only be 1 child: %s"%cIds)
        
    def test_objects_02(self):
        """ Testing Object Groups """
        root = self.Groups.getChild(1)
        staff = root.getChild(2)
        u1 = staff.addChild(
            obj=User('simon','simon@obsidian.com.au'),
            name="Simon Hookway"
        )
        self.assert_(u1, "Adding user #1 failed: %s" % u1)
        self.assertEqual(
            u1['parent_id'], staff.id, 
            "User #1 parent_id is incorrect: %s" % u1['parent_id']
        )
        self.assertEqual(
            u1['name'], "Simon Hookway", 
            "User #1 name is incorrect: %s" % u1['name']
        )
        self.assert_(u1.ob_ref, "Failed to collect the object reference.")
        u1a = staff.getChild(u1.id)
        self.assert_(u1a, "Collection of User #1 failed: %s" % u1a)
        self.assertEqual(
            u1a.ob_ref.name, 'simon', 
            "Name on object is wrong: %s" % u1a.ob_ref.name
        )
        self.assertEqual(
            u1a.ob_ref.email, 'simon@obsidian.com.au', 
            "Email on object is wrong: %s" % u1a.ob_ref.email
        )
        
    def test_ObInOb_03(self):
        """ Testing subobject Groups """
        root = self.Groups.getChild(1)
        staff = root.getChild(2)
        u1 = staff.getChildren()[0]
        u2 = u1.addChild(name="subord", obj=User('Dou','d@me.c'))
        
    def test_parents_04(self):
        """ Testing intelligent parenting """
        u3 = self.Groups.getGroup(3)
        self.assert_(u3, "Failed to get the third Group.")
        u2 = u3.parent
        self.assertEqual(u2.id, 2, "Third child should have 2nd as parent.")
        u1 = u2.parent
        self.assertEqual(u1.id, 1, "Second child should have 1st as parent.")

    def test_removal_05(self):
        """ Testing removal of Groups """
        cIds = self.Groups.getChildIds()
        self.assertEqual(len(cIds),1,"Should only be 1 root Group.")
        grp = self.Groups.getGroup(2)
        grp.parent.delChild(grp)
        cIds = self.Groups.getChildIds()
        self.assertEqual(cIds, [1,3], "Removal should have made another root.")


if __name__ == "__main__":
    testRunner(dependenciesOn=False)
