"""
Case Insensitive Dictionary behaves like a normal dictionary but its accessors
will return results based on a case insensitive search. For this reason the
keys 'fRed' and 'FREd' are the same. While this class stores and returns the
keys as they were entered they are esentially the same element in the dict.

Public classes:

    CaseInsensitiveDict:

        Has standard dictionary methods.

$Id: CaseInsensitiveDict.py,v 1.2 2005/03/02 22:42:55 seoman Exp $
"""
__revision__ = "$Revision: 1.2 $"[11:-2]


from OrderedDict import DictMixin


class CaseInsensitiveDict(DictMixin,dict):
    """
    This is a Case Insensitivity Dictionary that also stores the case of the
    field/key as it was entered but makes the accessors case insensitive when
    setting, getting or deleting elements.
    """

    def __init__(self, a=None, **kwargs):
        """
        Build an Ordered Dictionary from a single arg or a set of keyword args,
        you can have keyword args that are in the single argument which must
        be iterable (ie. a dict or tuple/list of 2 value pairs). In which case
        the keyword args override the ones in the arg.
        """
        self.__MasterClass__ = self.__class__
        if a:
            self.update(a)
        self.update(kwargs)

    def __getitem__(self, name):
        """ Return an item's value from the dict """
        return dict.__getitem__(self, name.lower())[1]
    
    def __setitem__(self, name, value):
        """ Set 'name' on us to have 'value', appending if needed """
        dict.__setitem__(self, name.lower(), (name,value))

    def __delitem__(self, name):
        """ Remove 'name' and its value from this dict """
        dict.__delitem__(self, name.lower())

    def keys(self):
        """
        D.keys() -> [ key1, key2, ..].

        Returns list of keys in this dict in an arbitary order but in the
        case that they were added with.
        """
        return [ v[0] for v in dict.itervalues(self) ]    

    def has_key(self, name):
        """ D.has_key(name) -> True/False if name is field in dict """
        return dict.has_key(self,name.lower())

