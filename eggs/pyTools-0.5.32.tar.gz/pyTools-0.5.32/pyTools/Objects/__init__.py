"""
Some Python Base Objects

$Id: __init__.py,v 1.3 2006/04/26 07:07:57 seoman Exp $
"""
__revision__  = "$Revision: 1.3 $"[11:-2]


from pyTools import HardError, SoftError


class NoSuchObject(AttributeError,HardError):
    """ Object cannot be found """
    
class ObjectExists(AttributeError,HardError):
    """ Object already exists """
    

__all__ = [
    'HardError',
    'SoftError',
    'NoSuchObject',
    'ObjectExists',
]