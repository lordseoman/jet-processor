"""
Provided mixin for database ease of use support to all pyManager objects.

This is NOT an extension of the DataStore object, that is a basic dict object
that has set and pickle capabilities. This module contains entirely different
objects. These are DataStorage Objects very similar to SQL Objects. They come
in 2 types:
    
    o DS_Table  - represents a table or object within a database,
    
    o DS_Object - represents a single record within a table in the database.
    
The objects hinge off of PropertyDictAware to allow them to integrate into any
application along with other standard objects. They are designed to carry more
than just data, but be complete objects themselves. It is therefore possible to
have an object where the properties contain both data contained in the backend 
and other properties used by the object. However, every field in the table must
exist as a property, those that are readonly should be set as mode 'p' and
those not displayable should be 'h'. Usually you would set the index field to
be mode 'ph'. You should also make any properties used by the object that is
not in the table have a mode 'p', as mode 'p' properties are not included in
__updateable.

The DS_Table Object is really a nodeMap type object that allows easy access to
the children (ie. records) of the object. So you can for instance step through
all records in the table selecting ones that, say have 'fred' somewhere in the
_name_ column/field.
    
    [ rec for rec in table.__traverse__() if rec.name.find('fred') > -1 ]
    
This is naturally going to be slower that preparing a SelectQuery, however in
some case this may be more usefull.

The real power of DS_Table comes from the ForeignKey wrapper that allows you to
create one <--> many relationships in very simple ways. So, lets say you have
a table of People and a table of Roles. You could link the People to the Roles
using a ForeignKey.

    class Roles(DS_Table):
        __TableName__ = 'roles'

    class People(DS_Table):
        __TableName__ = 'users'
        roles = ForeignKey('userid',Roles)
        
This links the roles table to the users table by the 'userid' column. So:
    
    >>> p = People()
    >>> user = p.get(username='simon')
    >>> user.roles
    ['editor','author'].roles
    <ForeignTable 'Roles' linked on 'userid' with 2 items>
    >>> 

If we make this a little more usefull, lets say you have to following roles
table:
    
    +--------+-----------+-------------------+---------------+
    | roleid | name      | Department        | security_code |
    +--------+-----------+-------------------+---------------+
    | 1      | security  | Security          | 3452          |
    | 2      | secretary | Office Management | 1034          |
    | 3      | cleaning  | Cleaning          | 9783          |
    | 4      | sales     | Marketing         | 4572          |
    | 5      | it        | IT Support        | 0527          |
    +--------+-----------+-------------------+---------------+
    
Now with the following users table:
    
    +--------+-----------+--------------+------------+-----+
    | userid | username  | firstname    | lastname   | Sex |
    +--------+-----------+--------------+------------+-----+
    | 1      | fred      | Fred         |            | m   |
    | 2      | simon     | Simon        | Hookway    | m   | 
    | 3      | melanie   | Melanie      | Blakeworth | f   |
    | 4      | elle      | Simone       | ellefe     | f   |
    | 5      | john      | John         | Lovetoy    | m   |
    | 6      | bernie    | Bernadette   | Stonewall  | f   |
    | 7      | larry     | Larry        | Nivery     | m   |
    | 8      | melissa   | Melissa      | Quoteman   | f   |
    +--------+-----------+--------------+------------+-----+
    
We could link the using a user_roles table as such:
    
    +----+--------+--------+
    | id | userid | roleid |
    +----+--------+--------+
    | 1  | 1      | 1      |
    | 2  | 2      | 2      |
    | 3  | 2      | 4      |
    | 4  | 3      | 2      |
    | 5  | 4      | 5      |
    | 6  | 5      | 1      |
    | 7  | 5      | 5      |
    | 8  | 6      | 2      |
    | 9  | 7      | 3      |
    | 10 | 8      | 4      |
    +----+--------+--------+

    

$Id: DataStore.py,v 1.23 2006/04/26 07:07:57 seoman Exp $
"""
__revision__ = "$Revision: 1.23 $"[11:-2]

# System imports
import types
from mx import DateTime

# Local imports
from pyTools import ErrorMetaClass, HardError, SoftError
from pyTools.Objects import NoSuchObject
from pyTools.dbPool import StorageHandler,DbPoolError
from pyTools.dbPool.Query import *
from pyTools.PropertyManager import PropertyDictAware


db_pool = StorageHandler()


class DataStoreError(HardError):
    pass


class LazyCache(dict):
    """ 
    This is Lazy Cache that cleans itself and handles expiry of records based
    on timeouts.
    """
    def __init__(self, max_size=2000, timeout=720):
        self.Timeout = timeout
        self.MaxCacheSize = max_size
    
    def __getitem__(self, key):
        """ Override to provide d[x] with timeout """
        if key in self:
            child,ts = dict.__getitem__(self,key)
            expiryTime = DateTime.DateTimeDelta(0,0,self.Timeout)
            if (DateTime.now() - ts) < expiryTime:
                return child
            self.__delitem__(key)
        raise NoSuchObject("no such child in cache: %s'" % key)

    def __setitem__(self, key, child):
        """ Override to support maximum sizing of Cache """
        if len(self) >= self.MaxCacheSize:
            self.clean()
        dict.__setitem__(self, key, (child,DateTime.now()))

    def add(self, child):
        """ Add a new child to the cache """
        self[child.id] = child

    def get(self, key):
        """ Find a record with 'key' in the cache or None """
        try:
            return self[key]
        except NoSuchObject:
            return None

    def remove(self, child):
        """ Remove a child from the cache """
        if child.id in self:
            del self[child.id]

    def clean(self):
        """ Clean the cache removing any expired items """
        expiryTime = DateTime.DateTimeDelta(0,0,self.Timeout)
        now = DateTime.now()
        for key,(child,ts) in self.items():
            if (now - ts) >= expiryTime:
                self.__delitem__(key)
        return

    
class DS_Base:
    """
    This is a Base mixin, not intended to be used stand alone. It provides very
    basic DataStorage/Backend connectivity through the db and cursor properties
    on this class.

     o db returns the currently relevent container handler as identified by
       the __id__ attribute.

     o cursor returns a clean Cursor object from the appropriate container.

    All DS Objects inherit from this Base class.
    """
    __metaclass__ = ErrorMetaClass
    
    # Identifier used for backend access
    __id__ = None

    Errors = (DataStoreError, DbPoolError, NoSuchObject)
    
    def __db(self):
        """ Returns a database Connector from the appropriate Container """
        if self.__id__ is None:
            raise DataStoreError("__id__ not configured properly in DS.")
        return db_pool.run(self.__id__, parent=self)
    db = property(__db,doc="Returns the Container for this object.")
        
    def __cursor(self):
        """ Returns a new Cursor from the appropriate Container """
        return self.db.getCursor()
    cursor = property(__cursor,doc="Get a Cursor associated with this object.")

    __isSetup = False
    def _ds_beforeReturn(self, resultset=None):
        """ 
        This should never be called directly, it is called by the ResultSet
        before returning a result object using an instance of one of these
        objects.
        """
        if self.__isSetup is False:
            if resultset is not None:
                self.__id__ = resultset.__id__
            self.__isSetup = True
        return


class DS_Object(DS_Base,PropertyDictAware):
    """
    This is a global piece of data that is returned from a select or similar
    query, but instead of returning a dict or tuple (or list thereof) we
    return this object which allows for get/set of attributes (or fields).
    Use of this class requires that the table used has a unique index field
    as this is used for the set() call.

    We inheret from PropertyAware as we expect the fields in the table/data
    container for this object to be saved as properties on this object.
    
    Public methods:
        
        o db      - returns a backend container for this object.
        
        o cursor  - returns a new Cursor from the correct backend Container.
        
        o get/set - method to retrieve/edit properties.
        
    There are some special methods; __create__, __update__, and __restore__.
    These are, in order, used to create the object in the backend when the
    object doesn't yet exist in the backend. Updates the changes you've made
    using set() or setProperty() into the backend for an existing object. And,
    finally, restore to re-fetch the data from the backend into this object 
    (which is usefull if you have made changes you want to blow away).
    """
    # Should each __set__ be committed.
    __AutoCommit__ = False

    # These must be set on the class and not in the __init__
    __TableName__ = None
    __TableType__ = 'normal'
    __IndexId__   = 'id'
    
    # Errors raised by this object
    Errors = PropertyDictAware.Errors + DS_Base.Errors
 
    # parental hook
    __parent = None
    parent = property(lambda s:s.__parent)
    
    def __top(self):
        """ Returns the top level object """
        this = self
        while hasattr(this, 'parent') and this.parent is not None:
            this = this.parent
        return this
    top = property(__top, doc="The handler at the top of the heirarchy")
    
    def getParents(self):
        """ Returns a list of parents """
        parents = []
        this = self
        while hasattr(this, 'parent'):
            parents.insert(0,this)
            this = this.parent
        parents.insert(0,this)
        return parents
    
    # has this object been changed
    _p_changed = False
    
    # property used to reference this object as a string
    __NameId__ = None

    def getName(self):
        """ 
        O.getName() -> String
        
        Returns a String identifying this object (which may not be unique) for
        use as displaying this object.
        """
        if self.__NameId__ is not None:
            try:
                return self[self.__NameId__]
            except self.NoSuchProperty:
                return getattr(self,self.__NameId__,"unset")
        return "Unknown at %s" % id(self)
    
    def __repr__(self):
        """ Object representation as a string """
        return "<%s '%s' from %s at %s>" % (
            self.__class__.__name__,self.id,self.__TableName__,id(self),
        )
    #
    # Handler methods which get called automatically during object manipulation
    #
    __isSetup = False
    def _afterCollect(self, parent):
        """ 
        This should never be called directly, it is called by the DS parent
        object after collecting the result and before returning the child from
        a getChild call.
        """
        self._pm_afterAdd(parent)
        if self.__isSetup is False:
            self.__parent  = parent
            self.__isSetup = True
        return
    
    def _beforeAdd(self, parent):
        """ Called in addChild prior to setting any properties """
        if self.__isSetup is False:
            self.__parent = parent
    
    def _afterAdd(self, parent):
        """ Called after the __create__ method """
        self._pm_afterAdd(parent)
        if self.__isSetup is False:
            self.__parent  = parent
            self.__isSetup = True
        return

    def _beforeUpdate(self, parent):
        """
        Called just prior to a call to __create__ when __isSetup is False and
        prior to __update__. The former is called from within the parent.add()
        method while the later is called from within the __update__ method.
        """
        self._pm_beforeUpdate()
        if self.__id__ is None:
            self.__id__ = parent.__id__
        if self.__id__ != parent.__id__:
            raise DataStoreError("Can't update child, its not mine.")
        return

    def _afterUpdate(self, parent):
        """
        Called after this object is updated so that the parent can be informed
        that the child has changed. This is called from within the __update__
        method.
        """
        if parent:
            parent.RecordCache.add(self)
        self._p_changed = False
        return

    def _beforeDelete(self, parent):
        """
        Called within __delete__ prior to actally deleting this object;
        """
        return

    def _afterDelete(self, parent):
        """
        Called within __delete__ after actally deleting this object; this by
        default removes the child from the parents cache.
        """
        if parent:
            parent.RecordCache.remove(self)
        self.__isSetup = None
        self.__parent = None
        return
    #
    # Backend sync methods
    #
    def __setPropertyModes(self, value):
        """
        Ob.__setPropertyModes(value) -> None
        
        Sets the current property modes using value, this is called during an
        object retrieval from the backend to ensure saved properties have the
        correct mode.
        """
        modes = dict([ p.split('~') for p in value.split(':') ])
        _properties = ()
        for prop in self._properties:
            field = prop.get('field') or prop['id']
            if field in modes:
                prop = prop.copy()
                prop['mode'] = modes[field]
            _properties += (prop,)
        self._properties = _properties
        
    def _getFieldMap(self):
        """ Returns a mapping of field --> id """
        return dict( [('__PropModes__', '__PropModes__'),] +
            [ (p.get('field',p['id']),p['id']) for p in self.propertyMap() ] 
        )
    
    def __updateableProperties(self):
        """ Return a list of tuples being (f,v) pairs """
        data = []
        propModes = []
        for p in self.propertyMap():
            field = p.get('field') or p['id']
            if 'p' in p.get('mode','') or field == self.idfield:
                continue
            # properties stored in the backend by field key.
            data.append((field,self[p['id']]))
            propModes.append("%s~%s" % (field, p.get('mode', '')))
        data.append(("__PropModes__", ":".join(propModes)))
        return data

    def __getIndex(self):
        """ Return the property value for the Index """
        return long(self[self.__IndexId__] or 0)

    def __setIndex(self, value):
        """ Set the index property """
        if self.__isSetup is False:
            self._setProperty(self.__IndexId__, long(value))
        return

    id = property(__getIndex, __setIndex,
        doc="This is the index for this property."
    )

    def __getField(self):
        """ Return the fieldname of the index property """
        for p in self.propertyMap():
            if p['id'] == self.__IndexId__:
                return p.get('field',p['id'])
        raise DataStoreError("Object __IndexField__ is incorrectly defined.")
        
    idfield = property(__getField,doc="The fieldname of the Index property.")
    #
    # object manipulation methods
    #
    def __create__(self):
        """ 
        Ob.__create__() -> idx. 
        
        Create this object in the backend, the object cannot be already setup
        or a DataStoreError is raised. This should not normally be called by
        the user, it is called as part of DS_Table and DS_Container when adding
        a child object.
        """
        if self.__isSetup is not False:
            raise DataStoreError("Object cannot be created after setup.")
        if not self.__TableName__:
            raise DataStoreError("Object has no __TableName__, please setup.")
        
        propItems = self.__updateableProperties()
        
        # now add the record info
        query = Insert(self.__TableName__)
        query.table_type = self.__TableType__
        query.setRows([ f for f,v in propItems ])
        query += [ v for f,v in propItems ]
        cursor = self.cursor
        try:
            ar = cursor.execute(query)
        except cursor.Errors,e:
            print query.sql()
            raise
        if ar != 1:
            print "Cursor should only have affected 1 row: %d"%ar
        self.id = cursor.insert_id
        return
        
    def __update__(self):
        """ Update the backend datastore with the detail in this object """
        if self.__isSetup is not True:
            raise DataStoreError("Cannot update before the Object is setup.")
        if self._p_changed is False:
            return
        # Run a before update
        self._beforeUpdate(self.parent)
        # build and execute the update query
        query=Update(self.__TableName__,**dict(self.__updateableProperties()))
        query.table_type = self.__TableType__
        query.wheres.add(**{ self.idfield: self.id, })
        ar = self.cursor.execute(query)
        if ar != 1:
            print "cursor returned an AffectedRows of",ar
        # Call the after update hook
        self._afterUpdate(self.parent)
        return
        
    def __restore__(self):
        """ Return this object to it what is in the backend """
        if self.__isSetup is not True:
            raise DataStoreError("Cannot restore before the Object is setup.")
        
        fieldMap = self._getFieldMap()
        query = Select(self.__TableName__,*fieldMap.keys())
        query.table_type = self.__TableType__
        query.wheres.add(**{ self.idfield: self.id, })
        results = self.cursor.execute(query)
        
        # Make sure we only have 1 result
        if not results:
            raise DataStoreError("restore returned no results.")
        elif len(results) > 1:
            raise DataStoreError("restore returned %d results." % len(results))
            
        # Now update us with the data from the backend
        self.__isSetup = False
        results.iterator = dict
        for n,v in results[0].items():
            self._setProperty(fieldMap[n],v)
        self.__isSetup = True
        return

    def __delete__(self):
        """
        Ob.__delete__() -> None
        
        Delete this child from the system, calls _beforeDelete prior to running
        a Delete Query and _afterDelete if the delete suceeds.
        """
        if self.__isSetup is not True:
            raise DataStoreError("Cannot delete on an Object not setup.")
        # Run the _beforeDelete first
        self._beforeDelete(self.parent)
        # Run the delete query
        query = Delete(self.__TableName__)
        query.table_type = self.__TableType__
        query.wheres.add(**{ self.idfield: self.id, })
        ar = self.cursor.execute(query)
        # Make sure we only have 1 result
        if ar != 1:
            raise DataStoreError("delete returned a %d result." % ar)
        # Run the afterDelete
        self._afterDelete(self.parent)
        return
    #
    # Make pickling this object sensitive to the backend
    #
    def __reduce__(self):
        return self.__class__,(),self.__getstate__()
    
    def __getstate__(self):
        """ 
        Return the index_info for this data object.

        The index_info object is a list of containing the information needed to
        restore this object either by a __restore__ call or using __setstate__
        and passing it the object returned by this method.

        index_info = [ 
            StorageHandler-Identifier,
            TableName,
            TableType,
            (IndexFieldName, IndexValue),
        ]
        
        Note that __setstate__ merely sets the object parameters then calls the
        restore() method.
        """
        return [
            self.__id__,
            self.__TableName__,
            self.__TableType__,
            (self.__IndexId__, self.id),
        ]
        
    def __setstate__(self, index_info):
        """ Restore a DataStore object by using the index_info object """
        self.__isSetup = False
        self.__id__        = index_info[0]
        self.__TableName__ = index_info[1]
        self.__TableType__ = index_info[2]
        self.__IndexId__   = index_info[3][0]
        self.id = index_info[3][1]
        self.__isSetup = True
        self.__restore__()
        return 
    #
    # Public access methods
    #
    def set(self, **kwargs):
        """
        P.set(**kwargs) -> None.

        Set the args in kwargs on this object honouring the input_filters and
        validators for the properties. As we expect all properties to be sent
        to this method we also do an __update__ ourselves.
        """
        auto_commit = self.__AutoCommit__
        self.__AutoCommit__ = False
        errors = self.updateProperties(**kwargs)
        self.__update__()
        self.__AutoCommit__ = auto_commit
    
    def get(self, name, default=None):
        """
        Returns the items from the dictionary as a list, however, _name_ can be
        a list of fields to return in which case the fields are returned in the
        order they were requested, as a tuple. If one or more fields are not 
        available then the default is returned, so the number of returned items
        will always equal the number of requested items.
        """
        if type(name) in (types.ListType, types.TupleType):
            return [ (x,y) for x,y in self.propertyValues() if x in name ]
        elif self.hasProperty(name):
            return self.getProperty(name)
        else:
            return default
    #
    # Override the internal accessor methods
    #
    def _pm_setPropValue(self, _id, value):
        """ 
        Sets the value of the property in the dict, if the object is setup (ie.
        if __isSetup is True) then we may need to update this property in the
        backend. We only update each property individually in the backend iff
        __AutoCommit__ is enabled. Otherwise you need to call __update__ on this
        object.
        """
        if self.__isSetup is True:
            if self.__AutoCommit__ is True:
                query = Update(self.__TableName__)
                query.table_type = self.__TableType__
                query.setRows((_id,))
                query += (value,)
                query.wheres.add(**{ self.idfield: self.id, })
                self.cursor.execute(query)
            else:
                self._p_changed = True
        return PropertyDictAware._pm_setPropValue(self, _id, value)

    def _pm_delPropValue(self, _id):
        """ Remove the property from the dict """
        raise NotImplementedError("Cannot delete DataStore fields.")
    
    def __setitem__(self, key, value):
        """ set/add a property """
        if self.__isSetup is False:
            if key == '__PropModes__':
                self.__setPropertyModes(value)
            else:
                self._setProperty(key, value)
        else:
            self.setProperty(key,value)

    def __delitem__(self, key):
        """ Only allow dictionary type delete if we are not setup """
        if self.__isSetup is False:
            return self._delProperty(key)
        raise AttributeError("You can't delete this attribute: %s" % key)
    #
    # Not sure this is a good idea yet
    #
    def __getattr__(self, name):
        """
        Allow x.y to return properties/data.
        
        We are only here if the attribute doesn't exist, so its safe to pass 
        this request straight to getProperty() and allow it to raise an
        AttributeError if there is no such property. 
        """
        if self.hasProperty(name):
            return self.getProperty(name)
        raise AttributeError("%s, no such attribute." % name)


class DS_Table(DS_Base):
    """
    This Object represents a table, this is similar to an SQL Table Object and
    helps to hide some of the basic requests. It is a Container type object like
    DS_Container, however we are not PropertyAware and contain no actual data.
    
    Public methods:
        
      o get(name=value)
        request records from this table where field 'name' is 'value'. You can
        use the wrappers LIKE, NOT, IN, BETWEEN, LESS, and GREATER. This will
        return a recordset (if there is more than 1), a single record (if only
        1 result is returned), or None.
        
      o add(**kwargs)
        add a record to this table, the index field should not be in properties
        and we add.
        
    Inherit from this object and use the get/add/del methods to manipulate the
    records in this table.
    """
    # Default the Record class to use for records of this table
    __RecordClass__ = DS_Object
    
    def childFieldMap(cls):
        """ Return (FM,IM) tuple for child """
        fm,im = {},{}
        child_cls = cls.__RecordClass__ or cls
        for p in child_cls._properties:
            fm[p.get('field',p['id'])] = p['id']
            im[p['id']] = p.get('field',p['id'])
        return fm,im
    childFieldMap = classmethod(childFieldMap)
    
    # Messages are SoftErrors invoked during normal operation
    __messages = []
    messages = property(lambda s:s.__messages)
    
    # These are stored on the child object now
    def __child_class(self):
        return self.__RecordClass__ or self.__class__
    table_name = property(lambda s:s.__child_class().__TableName__)
    table_type = property(lambda s:s.__child_class().__TableType__)
    indexid = property(lambda s:s.__child_class().__IndexId__)
    
    __child_index = None
    def __indexfield(self):
        if self.__child_index is None:
            for p in self.__child_class()._properties:
                if p['id'] == self.__child_class().__IndexId__:
                    self.__child_index = p.get('field',p['id'])
                    break
            else:
                raise DataStoreError("Index is incorrectly defined.")
        return self.__child_index
    indexfield = property(__indexfield)
    
    def __repr__(self):
        """ Object representation as a string """
        return "<%s.DS_Table to '%s' using %s at %s>" % (
            self.__class__.__name__,self.table_name,self.__id__,id(self)
        )
    
    # 30 min cache expiry
    __CacheExpiry__ = 60*30
    # Maximum of 1000 entries in the cache
    __MaxCacheSize__= 1000
    # Cache of retrieved records from this table
    __RecordCache = None
    def __get_cache(self):
        if self.__RecordCache is None:
            self.__RecordCache = LazyCache(
                self.__MaxCacheSize__,self.__CacheExpiry__
            )
        return self.__RecordCache
    RecordCache = property(__get_cache,doc="Lazy cache of children.")
    #
    # Container style accessors
    #
    def getChildIds(self, **kwargs):
        """
        T.getChildIds() -> ResultSet of Indexes

        Returns a list of Index Fields for this table.
        """
        qry = Select(self.table_name,self.indexfield)
        qry.orderby = (self.indexfield,)
        if kwargs:
            fMap = self.childFieldMap()[1]
            qry.wheres.add(**dict([ (fMap[f],v) for f,v in kwargs.items() ]))
        return [ x[0] for x in self.cursor.execute(qry) ]
    
    def getChildren(self, **kwargs):
        """
        T.getChildren(field=value,..) -> [ child, ... ]
        
        Sends a request to the StorageHandler for all children that satisfy the
        kwargs requirements. At its most basic if you do:
            
            getChildren(username='simon') 
            
        and would be returned all records where the username field == 'simon'.
        You can also use the LIKE, NOT, BETWEEN, LESS, GREATER and IN as such:
            
            getChildren(username=NOT('simon'),status=IN('active','suspended'))
            
        to get all records where the username is not 'simon' and the status is
        either 'active' or 'suspended'.

        Always returns a list, which will be empty if no children meet the
        requirements of there are no children in the table.
        """
        # if the request contains the index field and its an == type then there
        # can only be ONE record for this, and we can look in the cache.
        if self.indexid in kwargs and \
            not isinstance(kwargs[self.indexid], WheresQueries):
            child = self.RecordCache.get(kwargs[self.indexid])
            if child is not None:
                for k,v in kwargs.items():
                    if v != child.get(k):
                        raise NoSuchObject("Object with index but diff args.")
                child._afterCollect(self)
                return [child,]
            
        # Request the records from the backend
        fieldMap = self.childFieldMap()[1]
        query = Select(self.table_name)
        query.wheres.add(**dict([ (fieldMap[f],v) for f,v in kwargs.items() ]))
        resultSet = self.cursor.execute(query)
        resultSet.iterator = self.__child_class()
        
        # Add the children to the __RecordCache
        results = []
        for record in resultSet:
            self.RecordCache.add(record)
            record._afterCollect(self)
            results.append(record)
        return results
    
    def getChild(self, index):
        """
        T.getChild(index) -> Child or Raises NoSuchObject
        
        Returns a single child given the unique key field or raises an except-
        ion if no child exists with that key.
        """
        try:
            return self.RecordCache[index]
        except NoSuchObject:
            pass
        if index not in self.getChildIds():
            raise NoSuchObject("no such child: %s" % index)
        child = self._getChild(index)
        self.RecordCache.add(child)
        child._afterCollect(self)
        return child
        
    def _getChild(self, index):
        """ Internal getChild """
        query = Select(self.table_name)
        query.wheres.add(**{ self.indexfield: index, })
        results = self.cursor.execute(query)
        if not results:
            raise NoSuchObject("child %s does not exist." % index)
        elif len(results) > 1:
            raise DataStoreError("getChild returned %d results."%len(results))
        results.iterator = self.__child_class()
        return results[0]
    
    def newChild(self, **args):
        """
        T.newChild(k=v,..) -> child.
        
        Returns a new child but doesn't store it in the backend. We call the
        _beforeAdd then set any properties on the child catching any SoftErrors
        in the messages Queue. Before returning we also call _beforeUpdate().
        """
        if self.__RecordClass__ is None:
            child = self.__class__()
        else:
            child = self.__RecordClass__()
        child._beforeAdd(self)
        # set all the properties catching SoftError's
        for k,v in args.items():
            try:
                child.setProperty(k,v)
            except SoftError,e:
                self.__messages.append(e)
        child._beforeUpdate(self)
        return child
    
    def addChild(self, **args):
        """ 
        T.addChild(k=v,..) -> child.
        
        Adds a child object of type __RecordClass__ to this table with those
        attributes as defined by the keyword args. Any SoftErrors raised as
        part of the add are stored in the 'messages' attribute on this object.
        If there is an index in the args then it is removed and the object is
        added whether it exists in the table or not.
        """
        child = self.newChild(**args)
        # sync the child into the backend
        child.__create__()
        # cache the child
        self.RecordCache.add(child)
        # call the after add methods, after caching, when objects are fetched
        # from the cache the _afterCollect is called instead of the after add
        child._afterAdd(self)
        return child
        
    def delChild(self, child):
        """
        T.delChild(child) -> None
        
        Delete the child from this table, this is just a call to __delete__ on
        the child. We do make sure child is our child.
        """
        if child.__id__ != self.__id__ or child.parent != self:
            raise DataStoreError("child is not ours.")
        child.__delete__()

    def setChild(self, child):
        """ 
        T.setChild(child) -> child
        
        Setting a child to this object, we expect the child to already exist, so
        in effect all we are doing is telling the child to create itself in the
        backend and then calling the _afterAdd() on the child.
        """
        child.__id__ = self.__id__
        child._beforeUpdate(self)
        idx = child.__create__()
        self.RecordCache.add(child)
        # call the after add methods, after caching, when objects are fetched
        # from the cache the _afterCollect is called instead of the after add
        child._afterAdd(self)
        return child


class DS_Container(DS_Object,DS_Table):
    """
    This is both a Container of children like DS_Table and an object in its
    own right like DS_Object. So it has a properties list  DS_Object, and its 
    Container method get(), set(), add() and del() are getChild(), setChild(),
    addChild() and delChild().
    
    Public methods:
        
        o getChild  - returns a child object given either the keyField or Id.
        
        o findChild - look for a child with 
        
        o setChild  - set 'child' as an object by calling __create__ on child.
        
        o addChild  - create a new child of _args_, returns a list of errors.
        
    The index for an object is expected to be uneditable (it should be set in
    PropertyAware as mode = 'hp'). We collect this from the data storage 
    backend after the child is added.
    
    NOTE: This means that to have properties that are not database items you 
    must set them as having a 'p' mode (that's 'p' for protected).
    """
    
    def __repr__(self):
        """ Object representation as a string """
        return "<DataContainer '%s' from %s with children in '%s'>" % (
            self.id, self.__TableName__, self.table_name
        )
    
    
DataStore = DS_Container

_d = DataStore()
DataStoreType = type(_d)
del(_d)
