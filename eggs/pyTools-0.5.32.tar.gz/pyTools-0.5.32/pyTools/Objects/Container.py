"""
This module contains a few base classes that get used to create the various
objects in this package.

$Id: Container.py,v 1.5 2006/04/26 07:07:57 seoman Exp $
"""
__revision__  = "$Revision: 1.5 $"[11:-2]

from __init__ import *


class Array(dict):
    """ 
    An Array has children that are identified by Ids 
    """
    
    Errors = (
        NoSuchObject,
    )
    
    def getObject(self, _id):
        """
        Array.getObject(_id) -> Object
        
        Return the Object whose Id is _id or raise a NoSuchObject exception.
        """
        if _id not in self:
            raise NoSuchObject("No such member: %s" % _id)
        return self[_id]
        
    def setObject(self, _id, obj):
        """ 
        Array.setObject(_id,object) -> None
        
        Add an object to this Array, raising an Exception if there an object 
        with this _id already exists.
        """
        if _id in self:
            raise ObjectExists("Object already exists: %s" % _id)
        self[_id] = obj
        
    def delObject(self, _id):
        """ 
        Array.delObject(_id) -> Object
        
        Remove a child object from this Array, returning the object or raises
        an execption.
        """
        ob = self.getObject(_id)
        del self[_id]
        return ob

    def objectIds(self):
        """ 
        Array.objectIds() -> [ Id, ... ]
        
        Returns a list of Ids this Array contains.
        """
        return self.keys()
        
    def objectValues(self):
        """ 
        Array.objectValues() -> [ object, ... ]
        
        Returns a list of the objects this Array contains.
        """
        return self.values()


class OrderedArray(Array):
    """ An Array has children that are identified by Ids, this one has order """
    def __init__(self):
        Array.__init__(self)
        self.__childrenOrder = []
        
    def getObjectByIndex(self, index):
        """" Internal method to return the raw object unwrapped """
        if index < 0 or index >= len(self.__childrenOrder):
            raise ValueError,"Index is out of range."
        return self.getObject(self.__childrenOrder[index])
        
    def setObject(self, _id, obj, index=None):
        """ Add an object to this object as a child """
        Array.setObject(self, _id, obj)
        if index is not None and index < len(self.__childrenOrder):
            self.__childrenOrder.insert(index, _id)
        else:
            self.__childrenOrder.append(_id)
        return
        
    def delObject(self, _id):
        """ Remove a child object from us """
        obj = Array.delObject(self, _id)
        self.__childrenOrder.remove(_id)
        return obj

    def objectIds(self):
        """ Returns a list of object Ids """
        return self.__childrenOrder
        
    def objectValues(self):
        """ Returns a list of tuples of (id, object) """
        objects = []
        for _id in self.__childrenOrder:
            objects.append( (_id, self.getObject(_id)) )
        return objects

    def moveObjectUp(self, _id):
        """ Moves an object up one position """
        if _id not in self.__children:
            raise AttributeError,"Child doesn't exist in object."
        index = self.__children.index(_id)
        if index:
            x = self.__childrenOrder.pop(index)
            self.__childrenOrder.insert(index - 1, x)
        return
        
    def moveObjectDown(self, _id):
        """ Moves an object down one position """
        if _id not in self.__children:
            raise AttributeError,"Child doesn't exist in object."
        index = self.__children.index(_id)
        if index < (len(self.__children)-1):
            x = self.__childrenOrder.pop(index)
            self.__childrenOrder.insert(index + 1, x)
        return
        
    def moveObjectTo(self, _id, position):
        """ Moves an object to a specified position """
        if _id not in self.__children:
            raise AttributeError,"Child doesn't exist in object."
        if position < 0 or position > (len(self.__children)-1):
            raise ValueError,"Position is out of range."
        index = self.__children.index(_id)
        if index != position:
            x = self.__childrenOrder.pop(index)
            self.__childrenOrder.insert(position, x)
        return
