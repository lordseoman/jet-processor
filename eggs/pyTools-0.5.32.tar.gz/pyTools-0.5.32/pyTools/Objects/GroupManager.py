"""
This modules implements a Grouping System using the DataStore object as a base
class to handle object storage and manipulation.

Use the GroupHandler (which is basically a DS_Table) to access the Group store
using the child accessor methods to retrieve any Root Level Groups.

  >>> from pyTools.Objects import GroupManager
  >>> handler = GroupManager.GroupHandler()
  >>> handler.getChildIds()
  [ 1, 5 ]
  >>>
  
The accessor methods on the Handler always returns a GroupMember object where
the GroupMember has no parent (ie. is a Root Level Group). Groups can be either
a simple name or reference an object, which can be accessed via the ob_ref
attribute. 
  
  >>> grp = handler.addChild(obj=['fred','nancy',])
  >>> handler.getChildIds()
  [ 1 ]
  >>> grp = handler.getChild(1)
  >>> grp.ob_ref
  [ 'fred', 'nancy' ]
  >>>

Group Member objects lean on the ability of python objects to be pickled, and
store the objects pickle in 'state_info' to accomplish this. When a saved Member
is accessed in the future the object is re-instanciated using this state and an
Unpickler. 

As additional support you can impliment the persistent_id / persistent_load of
the pickle structure by putting 'persistent_id' as a staticmethod on the object
and 'persistent_load' on the handler.

$Id: GroupManager.py,v 1.9 2006/04/26 07:07:57 seoman Exp $
"""
__revision__ = "$Revision: 1.9 $"[11:-2]

from pyTools import HardError, SoftError
from pyTools.Objects.DataStore import DS_Container, DataStoreError, DS_Table
from pyTools.dbPool.Query import *

import cPickle, re
from cStringIO import StringIO
        

def get_state(obj):
    """
    get_state(obj) -> String
    
    Returns a state info string useable for re-creating the object with minimum
    fuss. If the object has a 'persistent_id' method then this is used and you
    should ensure the handler used to re-instanciate the object has a method
    called 'persistent_load' which knows how to handle the state returned by the
    persistent_id method.
    
    By default the Pickler uses the standard __getstate__ and __setstate__ calls
    which can be overridden on the object also.
    """
    strio = StringIO()
    pickler = cPickle.Pickler(strio, 2)
    if hasattr(obj, 'persistent_id'):
        pickler.persistent_id = obj.persistent_id
    pickler.dump(obj)
    return strio.getvalue()

def set_state(handler, state):
    """
    set_state(handler, state) -> Object
    
    Takes a state info returned by get_state() and re-instanciates the object
    using 'persistent_load' if the state used persistent_id to get the state or
    __setstate__ otherwise.
    """
    strio = StringIO(state)
    unpickler = cPickle.Unpickler(strio)
    if hasattr(handler,'persistent_load'):
        unpickler.persistent_load = handler.persistent_load
    return unpickler.load()


class NotAllowedInGroup(HardError):
    """ Tried to add something to a Group that is not Allowed """

    
class TraverseError(HardError):
    """ Error doing group traversal """
    

class GroupMember(DS_Container):
    """
    A GroupMember is a simple object that has a pointer to another object or is
    just a label/name. When adding objects to a GroupMember you create another
    GroupMember around the object and put that under the parent GroupMember. 
    This allows you to create Associations between objects in a heirarchal way.
    """
    # set this to None so our children are Group objects too
    __RecordClass__ = None
    
    # this is the underlying object we link to
    __o = None
    
    # errors raised by this object
    Errors = (NotAllowedInGroup,) + DS_Container.Errors

    _properties = (
        {'id':'id','field':'group_id','type':int,'mode':'p'},
        {'id':'parent_id','type':int,'mode':'rh','default':0},
        {'id':'order_no','type':int,'mode':'rw','default':0},
        {'id':'name','type':str,'mode':'wr','validator':'name'},
        {'id':'state_info','type':object,'mode':'wh','input_filter':'state_info'},
    )
    #
    # Parental hooks, being sneaky collect it the from backend if parent_id is
    # not equal to self.parent.id
    #
    __parent = None
    def __get_parent(self):
        if self['parent_id'] != self.__parent.id:
            self.__parent = self.__parent.top.getGroup(self['parent_id'])
        return self.__parent
    parent = property(__get_parent, doc="My parent Group or the Handler.")
    #
    # DataStore hooks
    #
    __isSetup = False
    def _afterCollect(self, parent):
        if self.__isSetup is False:
            self.__isSetup = True
            self.__parent = parent
        DS_Container._afterCollect(self, parent)
        
    def _beforeAdd(self, parent):
        self._setProperty('parent_id', parent.id)
        self.__parent = parent
        DS_Container._beforeAdd(self, parent)
        
    def _afterAdd(self, parent):
        if self.__isSetup is False:
            self.__isSetup = True
            self.__parent = parent
        DS_Container._afterAdd(self, parent)
        
    def _afterDelete(self, parent):
        self.__isSetup = None
        self.__parent = None
        DS_Container._afterDelete(self, parent)
    #
    # Reference to the object
    # 
    def __ob_ref(self):
        """ Return the object we are pointing to """
        if self.__isSetup is not True:
            raise ProgrammingError("cannot use ob_ref until object is setup.")
        if self.__o is None:
            if not self['state_info']:
                return None
            self.__o = set_state(self.top, self['state_info'])
        return self.__o
    
    ob_ref = property(__ob_ref, doc="the object itself")
    #
    # Input/Output filters
    #
    def _if_state_info(self, obj):
        self.__o = None
        if obj is None:
            return ""
        if type(obj) is str:
            return obj
        self.__o = obj
        return get_state(obj)
    
    def _of_state_info(self, data):
        return None
    #
    # Validate the name of groups
    #
    __reName = re.compile(r'^[a-zA-Z]{1}[\w \-]{3,32}$', re.IGNORECASE)
    def _cf_name(self, value):
        return value and self.__reName.match(value)
    #
    # Children hooks for adding and getting groups
    #
    def addChild(self, obj=None, name=None):
        """
        G.addChild(object,name) -> Member
        
        Add a new Member to this Group, pass in the object that is to be added
        and returns a Member object representing the underlying object. You can
        access the underlying object using Member.ob_ref
        """
        if obj is None and name is None:
            raise DataStoreError("obj and name can't both be None.")
        # is the obj allowed in this group, as our object
        if self.ob_ref:
            if self.ob_ref.allowedInGroup(obj, self) is False:
                raise NotAllowedInGroup(
                    "%s is not allowed in Group %s" % (obj.getName(), self)
                )
        # create the child and store it
        child = self.newChild(state_info=obj, name=name or obj.getName())
        child.__create__()
        self.RecordCache.add(child)
        child._afterAdd(self)
        # now let our object and the child's object know its been done
        if obj is not None:
            obj.addedToGroup(self)
        if self.ob_ref:
            self.ob_ref.memberAdded(obj, self)
        # and return the child
        return child
    
    def delChild(self, child):
        """
        G.delChild(child) -> None
        
        Remove the child from this group, calling the removedFromGroup() method
        on the child object reference and memberRemved() on the Group object.
        """
        obj = child.ob_ref
        if obj is not None:
            obj.removedFromGroup(self)
        if self.ob_ref is not None:
            self.ob_ref.memberRemoved(obj, self)
        # find all children who have this group as a parent and set them to 0
        for member in child.getChildren():
            member._setProperty('parent_id', 0)
            member.__update__()
        DS_Container.delChild(self, child)
    
    def getChildren(self, **kwargs):
        """        self.assert_(root, "Adding root failed to return: %s" % root)

        G.getChildren([key=value, ...]) -> [ Member, ... ]
        
        Sends a request to the StorageHandler for all children that satisfy the
        keyword argument requirements. At its most basic if you do:
            
            getChildren(name='simon') 
            
        you would be returned all records where the username property is simon.
        You can also use the LIKE, NOT, BETWEEN, LESS, GREATER, etc as values
        from the dbPool.Query module.
        """
        kwargs['parent_id'] = self.id
        return DS_Container.getChildren(self, **kwargs)

    def getChildIds(self, **kwargs):
        """
        G.getChildIds() -> [ MemberId, ... ]
        
        Returns a list of Members by Id for the active members of this Group.
        """
        kwargs['parent_id'] = self.id
        return DS_Container.getChildIds(self, **kwargs)
    
    def getMembers(self):
        """
        G.getMembers() -> [ Object, ]
        
        Returns a list of the member objects in this Group.
        """
        return [ x.ob_ref for x in self.getChildren() ]


class GroupHandler(DS_Table):
    """
    This class is an accessor for the Grouping System, its child manipulation
    methods provide access to the all Groups in the system.
    """
    __RecordClass__ = GroupMember
    
    Errors = (TraverseError,) + DS_Table.Errors
    
    id = 0
    
    top = property(lambda s: s, doc="Handler at the top of the chain.")

    def addChild(self, name="", obj=None):
        """
        Handler.addChild([ name=<> | obj=<> ]) -> Member
        
        Create a new Group, pass either a name for the Group or an Object to
        represent the Group. You can pass name and obj and the name will not be
        taken from the object. When passing an object you access the underlying
        object using the Group.ob_ref syntax.
        """
        if obj is None and name is None:
            raise DataStoreError("obj and name can't both be None.")
        child = self.newChild(state_info=obj, name=name or obj.getName())
        child.__create__()
        self.RecordCache.add(child)
        child._afterAdd(self)
        return child
    
    def getChildren(self, **kwargs):
        """
        Handler.getChildren([key=value, ...]) -> [ Member, ... ]
        
        Sends a request to the StorageHandler for all children that satisfy the
        keyword argument requirements. At its most basic if you do:
            
            getChildren(name='simon') 
            
        you would be returned all records where the username property is simon.
        You can also use the LIKE, NOT, BETWEEN, LESS, GREATER, etc as values
        from the dbPool.Query module.
        """
        kwargs['parent_id'] = 0
        return DS_Table.getChildren(self, **kwargs)

    def traverse(self, group_path):
        """
        Handler.traverse(path) -> Group
        
        Return the Group identified by the path given as the group heirarch; 
        such as "MyLocation.SystemUsers.fred"
        """
        parent, group = self, None
        for name in group_path.split('.'):
            groups = parent.getChildren(name=name)
            if not groups:
                raise self.NoSuchObject("%s has no child %s" % (parent.id,name))
            if len(groups) > 1:
                raise TraverseError("more than 1 group with this name: %s"%name)
            group = groups[0]
        return group
    
    def getChildIds(self, **kwargs):
        """
        Handler.getChildIds() -> [ MemberId, ... ]
        
        Returns a list of Members by Id for the active members of this Group.
        """
        kwargs['parent_id'] = 0
        return DS_Table.getChildIds(self, **kwargs)
    
    def getGroupsOfObject(self, obj):
        """
        Handler.getGroupsOfObj(object) -> [ GroupMember, ... ]
        
        Return a list of GroupMember's where the object presented is a member of
        that Group but not the Group reference.
        """
        members = DS_Table.getChildren(self, state_info=get_state(obj))
        return [ member.parent for member in members if member.parent != self ]
    
    def getGroup(self, idx):
        """
        Handler.getGroup(group_id) -> GroupMember
        
        Returns a GroupMember with the parent set to this handler irrispective
        of whether the Group is a root group. Note that the group will reparent
        itself when group.parent is requested anyway.
        """
        if idx == self.id:
            return self
        child = DS_Table._getChild(self, idx)
        child._afterCollect(self)
        return child


class GroupAware:
    """
    This mixin provides an object of awareness for Group Management. 
    """

    def allowedInGroup(self, object, group):
        """
        Group.allowedInGroup(object, group) -> True/False

        Is the object provided allowed in the Group where this object is the
        reference.
        """
        return True

    def addedToGroup(self, group):
        """
        Member.addedToGroup(group) -> None
        
        This object has been added to the Group provided, this method allows
        the object to do whatever it needs as a result of this action.
        """
        return

    def removedFromGroup(self, group):
        """
        Member.removedFromGroup(group) -> None
        
        This object has been removed from a Group. This method is called from
        delChild after the fact so the object can make any changes it needs to.
        Note that the object still exists in the backend as normal.
        """
        return

    def memberAdded(self, object, group):
        """
        Group.memberAdded(object, group) -> None

        An object has been added to this object under the Group provided, since
        this object may have several Groups. 
        """
        return

    def memberRemoved(self, object, group):
        """
        Group.memberRemoved(object, group) -> None
        
        The object in the args has been removed from a Group belonging to this
        object as provided.
        """
        return
