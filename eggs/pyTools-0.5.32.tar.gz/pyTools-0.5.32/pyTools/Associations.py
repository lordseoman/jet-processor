"""
This is the object associations module.

Here we want to make an association between 2 objects without being too
concerned with what the objects actually are. We can lean on the pickle ability
of objects to store the objects we are associating.

My main implementation here is to create a set of elements/associations that
you add objects too. If you are using this to store the actual objects then 
pickling should provide enough information to do that. Alternatively, if your
objects are stored in an SQL database then make sure that the __getstate__ and
__setstate__ methods are set correctly to retrieve the objects from the correct
backend.

You can infact nest association objects, for example the GROUP_ASSOCIATION can
have another GROUP_ASSOCIATION object as a sibling. This could represent a 
folder containing objects, where one of those objects is actually a folder 
itself.

In the following example lets make a folder type object heirarchy, while we
could actually create a folder type object and add the children in the same way
a DOM works. This means we can create objects and move them around without 
actually altering any of the objects themselves.

from pyTools import Associations

>>> class Contact:
...     def __init__(self, name, email):
...         self.name = name
...         self.email = email
...         
>>> grps = Associations.Root('Groups')
>>> objA = Associations.Symmetric('Staff')
>>> staff = grps.setObject(objA.name, objA)
>>> barry = Contact('barry','barry@obsidian.com.au')
>>> staff.setObject(barry.name, barry)
>>> fred = Contact('fred','de3456@msn.com')
>>> staff.setObject(fred.name, fred)
>>> harry = Contact('harry','harryb@yahoo.com.au')
>>> staff.setObject(harry.name, harry)
>>> staff.objectIds()
['barry','fred','harry']
>>> staff.moveObjectUp(harry.name)
>>> staff.objectIds()
['barry','harry','fred']
>>>

I'll note that associations are not folders, if you want folders then implement
folders from the Objects package. Associations are not designed to actually
hold the object, but references to the object. Let's make the above example a
little more usefull. We'll need a contacts class that add/del/edits contact
object from a datasource. Then we'll group the contacts and provide a method
for saving and accessing the groups.

$Id: Associations.py,v 1.7 2006/04/26 07:07:57 seoman Exp $
"""
__revision__ = "$Revision: 1.7 $"[11:-2]


import cPickle,inspect,types
from Objects import Container


EMPTY_ASSOCIATION      = 1
SYMMETRIC_ASSOCIATION  = 2
ASYMMETRIC_ASSOCIATION = 3
ROOT_NODE              = 4
        

class Base(Container.OrderedArray):
    """ Basic association class """
    __repr_str__ = "<'%s' association of type %s between %d objects>"
    
    def __init__(self, nodeType=EMPTY_ASSOCIATION):
        """ Constructor """
        Container.OrderedArray.__init__(self)
        self.__nodeType = nodeType
    
    def __repr__(self):
        """ Pretty representation of this association """
        return self.__repr_str__ % (id(self),self.meta_type,len(self))
        
    def __check(self, obj):
        """ Check that we can associate this object """
        if inspect.isclass(obj):
            raise AttributeError,"Cannot associate classes"
        if inspect.isfunction(obj):
            raise AttributeError,"Cannot associate functions."
        return
        
    def setObject(self, _id, obj, index=None):
        """ Add an object to the association """
        self.__check(obj)
        Container.OrderedArray.setObject(self, _id, obj, index)
        if isinstance(obj, Symmetric) or isinstance(obj, Asymmetric):
            obj.topNode = self
        return obj

    def delObject(self, _id):
        """ Remove an object to the association, returning the object """
        obj = Container.OrderedArray.delObject(self, _id)
        if isinstance(obj, Symmetric) or isinstance(obj, Asymmetric):
            obj.topNode = None
        return obj
        
    def __get_type(self):
        """ Returns the association type """
        return self.__nodeType
    type = property(__get_type)
        
    def __get_meta_type(self):
        """ Returns the association type """
        return self.__class__.__name__
    meta_type = property(__get_meta_type)
    

class Symmetric(Base):
    """
    This is a group type association, where all object of the group have the
    same association with every other member of the group. In this type of
    association no object is the primary since all objects in the group have 
    the same relationship to every other object.
    """
    
    def __init__(self, name):
        """ 
        Asymmetric associations require a forward and reverse relationship name
        and the primary object as the constructor args.
        """
        Base.__init__(self, SYMMETRIC_ASSOCIATION)
        self.name = name
    

class Asymmetric(Base):
    """
    This is an asymmetric association where there is a different name for the
    forward relationship than the reverse relationship (Eg. parent/child). Thus
    one object must be set as the primary. An example of an asymmetric would
    be a folder, since the contents of the folder and the folder have a parent/
    child relationship and there is no interelationship between the contents
    of the folder.
    """
    
    def __init__(self, forward, reverse, primary):
        """ 
        Asymmetric associations require a forward and reverse relationship name
        and the primary object as the constructor args.
        """
        Base.__init__(self, ASYMMETRIC_ASSOCIATION)
        self.forward = forward
        self.reverse = reverse
        self.primary = primary
    

class Root(Base):
    """
    Class that manages the association objects, this is actually a base class
    that should be subclassed to provide object management. For all intents and
    purposes this is itself an association.
    """
    __factory = (None,None)
    
    def __init__(self, name, factory=None):
        """ 
        Constructor, factory is the optional function used by cPickle to load
        or save an object in the association tree.
        """
        Base.__init__(self, ROOT_NODE)
        self.name = name
        if type(factory) in (types.TupleType, types.ListType):
            self.__factory = (factory[0], factory[1])
        elif factory is not None:
            raise AttributeError,"Factory should be a tuple of load,save" 
        
    
    
    
