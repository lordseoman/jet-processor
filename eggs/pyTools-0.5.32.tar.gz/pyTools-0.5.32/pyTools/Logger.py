"""
This is a logger mixin to provide a module Logging support.

$Id: Logger.py,v 1.7 2005/11/13 03:06:11 seoman Exp $
"""
__revision__ = "$Revision: 1.7 $"[11:-2]


import logging
from logging import DEBUG,INFO,WARN,ERROR,CRITICAL


class LoggerAware:
    """ Provides logger support to an object """
    _prefix    = ""
    _catagory  = ""
    
    __LogHandler__  = None
    __LogLevel__    = None
    __OrigLevel__   = None
    __Logger__      = None

    Errors = ()

    def reset(self):
        """ Ease of use method to turn stdout, debug and errMails off """
        self.setLogger(False, False, False)
    
    def setLogger(self, stdout=None, debug=None, errMails=None):
        """ Setup the logger overriding the configuration directives """
        logger = self.getLogger()
        # stdout is the 'console' handler, look for it on our logger
        if stdout is not None:
            console_logger = logging.getLogger('console')
            if console_logger.handlers:
                hdlr = console_logger.handlers[0]
                if stdout and hdlr not in logger.handlers:
                    logger.addHandler(hdlr)
                    logger.propagate = 0
                elif not stdout and hdlr in logger.handlers:
                    logger.removeHandler(hdlr)
                    logger.propagate = 1
            else:
                self._log(ERROR,"Logger has no 'console' logger.")
        # errMails is a errmail handler, do like stdout
        if errMails is not None:
            errmail_logger = logging.getLogger('errmail')
            if errmail_logger.handlers:
                hdlr = errmail_logger.handlers[0]
                if errMails and hdlr not in logger.handlers:
                    logger.addHandler(hdlr)
                elif not errMails and hdlr in logger.handlers:
                    logger.removeHandler(hdlr)
            else:
                self._log(ERROR,"Logger has no 'errmail' logger.")
        # Update the __LogLevel__ for debug
        level = self.getLoggingLevel()
        if debug is True and level != DEBUG:
            if self.__OrigLevel__ is None:
                self.__OrigLevel__ = level
            self.__LogLevel__ = DEBUG
        elif debug is False and level == DEBUG:
            self.__LogLevel__ = self.__OrigLevel__
        return
        
    def getLoggingLevel(self):
        """ Get the current level of the logger """
        if self.__LogLevel__ is None:
            return self.getLogger().level
        else:
            return self.__LogLevel__
    
    def getLogger(self):
        """ Return the logger """
        if self.__Logger__ is None:
            if self.__LogHandler__:
                self.__Logger__ = logging.getLogger(self.__LogHandler__)
        if self.__Logger__ and self.__LogLevel__ and self.__LogLevel__ != self.__Logger__.level:
            self.__Logger__.setLevel(self.__LogLevel__)
        return self.__Logger__
    
    def _adjustMessage(self, msg):
        return msg

    def _log(self, level, msg, *args, **kwargs):
        """ write something to the logger without line feed """
        logger = self.getLogger()
        if logger is not None:
            if logger.level == logging.NOTSET or logger.level <= level: 
                #kwargs['catagory'] = self._catagory or self.__class__.__name__
                #kwargs['prefix'] = self._prefix
                msg = self._adjustMessage(msg)
                logger.log(level, msg, *args, **kwargs)
        return
        
    def log_debug(self, msg, *args, **kwargs):
        """ output a DEBUG message to the logger """
        self._log(DEBUG, msg, *args, **kwargs)
        
    def log_info(self, msg, *args, **kwargs):
        """ output a INFO message to the logger """
        self._log(INFO, msg, *args, **kwargs)
        
    def log_warn(self, msg, *args, **kwargs):
        """ output a WARN message to the logger """
        self._log(WARN, msg, *args, **kwargs)
        
    def log_error(self, msg, *args, **kwargs):
        """ output a ERROR message to the logger """
        self._log(ERROR, msg, *args, **kwargs)

    def log_critical(self, msg, *args, **kwargs):
        """ output a CRITICAL message to the logger """
        self._log(CRITICAL, msg, *args, **kwargs)
        
    def log_exception(self, msg, *args, **kwargs):
        """ output a CRITICAL message to the logger """
        kwargs['exc_info'] = True
        self._log(CRITICAL, msg, *args, **kwargs)
        
