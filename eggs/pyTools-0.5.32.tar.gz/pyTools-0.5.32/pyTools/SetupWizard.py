"""
This is a setup wizard implementation that allows an application to generate a
set of graphical prompts to a sysadmin to guide them through the steps needed
to setup the application. It uses a .templates file and a simple script to walk
through the steps.

$Id: SetupWizard.py,v 1.1 2005/07/28 00:26:13 seoman Exp $
"""
__revision__ = "$Revision: 1.1 $"[11:-2]

import commands,os
from itertools import imap


class Whiptail(object):
    """
    This is a Configuration Wizard helper using popular Whiptail, most systems
    will have whiptail installed which makes setup simple for server or remote
    setups.
    
    Instanciate this class with the backtitle used at the top of the whiptail
    screen, eg: Whiptail('pyTools Configuration Guide')
    """
    __templates = {}

    def __init__(self, backtitle):
        """ Constructor """
        self.ui = commands.getoutput("which whiptail")
        if not self.ui:
            raise SystemExit("No whiptail found.")
        self.backtitle = backtitle
    
    def __cmd(self):
        return "%s --backtitle '%s'" % (self.ui,self.backtitle)
    cmd = property(__cmd)
    
    def run(self, line, args=""):
        cmd = "%s %s 0 74 %s 2>&1 1>/dev/tty 0</dev/tty"%(self.cmd,line,args)
        return commands.getstatusoutput(cmd)
    
    def loadTemplate(self, filename):
        """ Read a .templates file """
        if not (os.path.exists(filename) and os.path.isfile(filename)):
            raise ValueError("template file doesn't exist: %s" % filename)
        tmpl = None
        ln = 0
        for line in imap(str.strip,open(filename,'r')):
            ln += 1
            if line.startswith('Template: '):
                tmpl = {'name': line.split(':')[1].strip(),'message': ''}
                continue
            if tmpl is None:
                raise ValueError("templates file is malformed at %d"%ln)
            if line.startswith('Type: '):
                tmpl['type'] = line.split(':')[1].strip()
            elif line.startswith('Choices: '):
                tmpl['options'] = line.split(':')[1].strip().split(', ')
            elif line.startswith('Title: '):
                tmpl['title'] = line.split(':')[1].strip()
            elif line.startswith('Default: '):
                tmpl['default'] = line.split(':')[1].strip()
            elif line.startswith('Description: '):
                tmpl['question'] = line.split(':')[1].strip()
            elif not line:
                tmpl['message'] = tmpl['message'].strip().replace('\n ','\n')
                self.__templates[tmpl['name']] = tmpl
                tmpl = None
            elif line == '.':
                tmpl['message'] += '\n\n'
            else:
                tmpl['message'] += " " + line
        if tmpl is not None:
            tmpl['message'] = tmpl['message'].strip().replace('\n ','\n')
            self.__templates[tmpl['name']] = tmpl
        return
    
    def __call__(self, template):
        """ Call a specific template """
        tmpl = self.__templates.get(template)
        if not tmpl:
            raise ValueError("no such template: %s"%template)
        args = []
        title = tmpl.get('title','')
        if tmpl['type'] == 'note':
            method = self.msgbox
            message = tmpl['question'] + '\n\n' + tmpl['message']
        else:
            message = tmpl['message'] + '\n\n' + tmpl['question']
        if tmpl['type'] == 'string':
            method = self.inputbox
            args.append(tmpl.get('default',''))
        elif tmpl['type'] == 'select':
            method = self.selection
            args.append(tmpl['options'])
        elif tmpl['type'] == 'multiselect':
            method = self.checklist
            args.append(tmpl['options'])
        return method(title,message,*args)
    #
    # Accessor methods to the various Template types
    #
    def infobox(self, title, message):
        """ Display an InfoBox """
        return self.run("--title '%s' --infobox '%s'" % (title,message))
    
    def msgbox(self, title, message):
        """ Display a MessageBox """
        return self.run("--title '%s' --msgbox '%s'" % (title,message))
    
    def boolean(self, title, message, defaultyes=True):
        """ Display a Boolean question box """
        if defaultyes is True:
            s = "--title '%s' --yesno '%s'" % (title,message)
        else:
            s = "--title '%s' --defaultno --yesno '%s'" % (title,message)
        return self.run(s)
    
    def inputbox(self, title, message, default=''):
        """ Display an InputBox and return the string answer """
        return self.run(
            "--title '%s' --inputbox '%s'" % (title,message),default
        )[1]
    
    def selection(self, title, message, items, height=5, default=None):
        """ Display a Single Selection Menu """
        args = [str(height),] + [ "%s %s" % (x,x) for x in items ]
        return self.run("--title '%s' --noitem --menu '%s'" %
            (title, message), ' '.join(args),
        )[1]
        
    def radiolist(self, title, message, items, height=5, default=None):
        """ Display a Radio Box """
        args = [str(height),]
        for item in items:
            if item == default:
                args.append("%s on" % item)
            else:
                args.append("%s off" % item)
        return self.run(
            "--title '%s' --noitem --radiolist '%s'" % (title, message)," ".join(args)
        )
    
    def checklist(self, title, message, items, height=5, default=None):
        """ Display a CheckList of items """
        args = [str(height),]
        for item in items:
            if item == default:
                args.append("%s on" % item)
            else:
                args.append("%s off" % item)
        return self.run(
            "--title '%s' --noitem --checklist '%s'" % (title, message)," ".join(args)
        )[1].split()

