"""
Importing this imports all tests in this directory.

Running this script will also run all tests, the same args apply.

$Id: __init__.py,v 1.4 2004/08/25 07:30:43 seoman Exp $
"""
__revision__ = "$Revision: 1.4 $"[11:-2]


import os
from glob import glob
from pyTools.Testing import testRunner

path = os.path.join(os.path.dirname(__file__),'test_*.py')
map(__import__, [ t[:-3] for t in glob(path) ])

if __name__ == '__main__':
    testRunner(dependenciesOn=True)
