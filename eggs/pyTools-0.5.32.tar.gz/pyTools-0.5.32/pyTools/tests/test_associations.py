"""
Test suite for Associations

$Id: test_associations.py,v 1.6 2005/02/02 06:00:15 seoman Exp $
"""

from pyTools import Associations
from pyTools.Testing import testRunner
from pyTools.TestCases import pyTestCase

import cPickle


class A:
    def __init__(self, name):
        self.name = name

        
class Contact(object):
    def __init__(self,name,uid,email):
        self.name = name
        self.uid = uid
        self.email = email


class AssociationsTC(pyTestCase):
    """ Test various group types """
    
    def test_Association_01(self):
        """ Testing association properties """
        asy = Associations.Asymmetric('to','from',None)
        self.assertEquals(
            asy.type,
            Associations.ASYMMETRIC_ASSOCIATION,
            "Association is not the correct tyoe."
        )
        self.assertEquals(
            asy.meta_type,'Asymmetric',
            "The meta type for associations is the Class name, or should be,"
        )
        class t: pass
        self.assertRaises(AttributeError,asy.setObject,'testObject',t)
        def func(): pass
        self.assertRaises(AttributeError,asy.setObject,'testObject',func)
        self.assertEquals(asy.objectIds(),[],"Object should have no children.")
    
    def test_Association_02(self):
        """ Create a simple symmetric association """
        a = A('first object')
        a.colour = 'red'
        b = A('second object')
        b.flavour = 'spicy'
        ass = Associations.Root('folderA')
        ass.setObject(a.name, a)
        ass.setObject(b.name, b)
        o1 = ass.getObject('first object')
        o2 = ass.getObject('second object')
        self.assertEquals(o1.colour,'red',"Failed to get 'colour' off 1st ass")
        self.assert_(not hasattr(o2,'colour'),"'colour' found on 2nd.")
        self.assertEquals(o2.flavour,'spicy',"Failed to get attr off 2nd ass")
        self.assert_(not hasattr(o1,'flavour'),"'flavour' found on 1st.")
        res = ['first object','second object']
        self.assertEquals(ass.objectIds(),res,"objectIds() call failed")

    def test_Association_03(self):
        """ Create a layered symmetric association """
        a = A('first object')
        a.colour = 'red'
        b = A('second object')
        b.flavour = 'spicy'
        c = Associations.Symmetric('folderB')
        ass = Associations.Root('folderA')
        ass.setObject(a.name, a)
        ass.setObject(c.name, c)
        ass.setObject(b.name, b)
        o1 = ass.getObject('folderB')
        self.assertEquals(o1.topNode, ass, "'folderB's topNode is not the Root")
        res = ['first object','folderB','second object']
        self.assertEquals(ass.objectIds(),res,"objectIds() call failed")

    def test_Pickles_04(self):
        """ Save an association and reload """
        root = Associations.Root('Contacts')
        kevin = Contact('Kevin Joe','kjoe','kj@yahoo.com')
        root.setObject(kevin.uid,kevin)
        # staff
        staff = root.setObject('Staff',Associations.Symmetric('Staff'))
        simon = Contact('Simon Hookway','seoman','simon@ob.com')
        staff.setObject(simon.uid, simon)
        fred = Contact('Freddie Cruger','fred','fcruger@contact.com')
        staff.setObject(fred.uid, fred)
        barry = Contact('Barry Noob','barry','bnoob@domain.com')
        staff.setObject(barry.uid, barry)
        # casual staff
        casual = staff.setObject('Casual',Associations.Symmetric('Casual'))
        nick = Contact('Nick','nic','nik.r@ob.com')
        casual.setObject(nick.uid,nick)
        # clients
        clients = root.setObject('Clients',Associations.Symmetric('Clients'))
        barnie = Contact('Barnie Gumble','barnie',None)
        clients.setObject('bgum',barnie)
        
        # Test the new associations
        o1 = root.getObject('Staff')
        self.assertEquals(o1.name,'Staff',"Staff node name incorrect: %s."%o1.name)
        self.assertEquals(
            o1.objectIds(),
            ['seoman','fred','barry','Casual'],
            "Staff node has incorrect children: %s" % o1.objectIds(),
        )
        o2 = o1.getObject('seoman')
        self.assert_(isinstance(o2,Contact),"Contact is not the right object.")
        self.assertEquals(o2.name,'Simon Hookway',"Simon's name is incorrect.")
        self.assertEquals(o2.uid,'seoman',"Simon's uid is incorrect.")
        self.assertEquals(o2.email,'simon@ob.com',"Simon's email incorrect.")
        
        # pickle and unpickle
        c = cPickle.loads(cPickle.dumps(root,2))
        # finally load the save file and re-instate the group
        self.assert_(c,"Failed to load the data file.")
        self.assertEquals(c.name,'Contacts',"Root node name incorrect.")
        self.assertEquals(
            c.objectIds(),
            ['kjoe','Staff','Clients'],
            "Root node has incorrect children: %s" % c.objectIds(),
        )
        o1 = c.getObject('Staff')
        self.assertEquals(o1.name,'Staff',"Staff node name incorrect: %s."%o1.name)
        self.assertEquals(
            o1.objectIds(),
            ['seoman','fred','barry','Casual'],
            "Staff node has incorrect children: %s" % o1.objectIds(),
        )
        o2 = o1.getObject('seoman')
        self.assert_(isinstance(o2,Contact),"Contact is not the right object.")
        self.assertEquals(o2.name,'Simon Hookway',"Simon's name is incorrect.")
        self.assertEquals(o2.uid,'seoman',"Simon's uid is incorrect.")
        self.assertEquals(o2.email,'simon@ob.com',"Simon's email incorrect.")
        self.assert_(o2 != o1.getObject('fred'),"fred and seoman appear the same.")
        o2 = o1.getObject('fred')
        self.assert_(isinstance(o2,Contact),"Contact is not the right object.")
        self.assertEquals(o2.name,'Freddie Cruger',"Fred's name is incorrect.")
        self.assertEquals(o2.uid,'fred',"Fred's uid is incorrect.")
        self.assertEquals(o2.email,'fcruger@contact.com',"Fred's email incorrect.")
        o2 = o1.getObject('barry')
        self.assert_(isinstance(o2,Contact),"Contact is not the right object.")
        self.assertEquals(o2.name,'Barry Noob',"Barry's name is incorrect.")
        self.assertEquals(o2.uid,'barry',"Barry's uid is incorrect.")
        self.assertEquals(o2.email,'bnoob@domain.com',"Barry's email incorrect.")
        o2 = o1.getObject('Casual')
        self.assert_(
            isinstance(o2,Associations.Symmetric),
            "Casual is not a Symmetric object, it should be."
        )
        self.assertEquals(
            o2.objectIds(),['nic'],
            "Casual node has incorrect children: %s" % o2.objectIds(),
        )
        o3 = o2.getObject('nic')
        self.assert_(isinstance(o3,Contact),"Contact is not the right object.")
        self.assertEquals(o3.name,'Nick',"Nick's name is incorrect.")
        self.assertEquals(o3.uid,'nic',"Nick's uid is incorrect.")
        self.assertEquals(o3.email,'nik.r@ob.com',"Nick's email incorrect.")
        o1 = c.getObject('Clients')
        self.assert_(
            isinstance(o1,Associations.Symmetric),
            "Casual is not a Symmetric object, it should be."
        )
        self.assertEquals(
            o1.objectIds(),['bgum'],
            "Casual node has incorrect children: %s" % o2.objectIds(),
        )
        o2 = o1.getObject('bgum')
        self.assert_(isinstance(o2,Contact),"Contact is not the right object.")
        self.assertEquals(o2.name,'Barnie Gumble',"Barnie's name is incorrect.")
        self.assertEquals(o2.uid,'barnie',"Barnie's uid is incorrect.")
        self.assertEquals(o2.email,None,"Barnie's email incorrect.")


if __name__ == "__main__":
    testRunner(dependenciesOn=False)
