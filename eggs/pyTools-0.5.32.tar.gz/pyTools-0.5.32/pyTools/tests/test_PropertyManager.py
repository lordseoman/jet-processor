"""
Test suite for PropertyManager

$Id: test_PropertyManager.py,v 1.3 2005/06/01 00:50:49 seoman Exp $
"""
__revision__ = "$Revision: 1.3 $"[11:-2]


from pyTools.Testing import testRunner
from pyTools.TestCases import pyTestCase

from pyTools import PropertyManager

from mx import DateTime

        
class Contact(PropertyManager.PropertyAware):
    """ extend PropertyAware to use setattr and delattr """

    _properties = (
        {'id':'firstname','mode':'w','type':'string'},
        {'id':'lastname','mode':'w','type':'string'},
        {'id':'email','mode':'wr','type':'string'},
    )

    def getName(self):
        """ Return the fullname of the user """
        return "%s %s" % (self.firstname,self.lastname)

    def getContact(self):
        """ Returns email contact for user """
        return "%s <%s>" % (self.getName(),self.email)


class TC_PropertyAware(pyTestCase):
    """ Test an object with property support """
    __StopOnError__ = True
    
    def setUpTestCase(cls):
        cls.a = PropertyManager.PropertyAware()
        cls.a.testprop2 = 'test invalid'
        cls.contact = Contact()
    setUpTestCase = classmethod(setUpTestCase)
    
    def test_AddGet_01(self):
        """ Test creating properties """
        # make sure the property 'a' is empty first
        self.assertEqual(len(self.a._properties),0,"'a' is not empty.")
        # Now lets add a property
        self.a.addProperty('testprop',45,mode='w',label='prop')
        # test the property was set
        self.assertEqual(
            len(self.a._properties),1,
            "Should only be 1 property defined, is %d" % len(self.a._properties)
        )
        pn = self.a.propertyNames()
        self.assertEqual(
            len(pn),1,
            "propertyNames() returned an incorrect number of property names."
        )
        self.assertEqual(
            pn,['testprop'],
            "propertyNames() returned the wrong names."
        )
        self.assert_(hasattr(self.a,'testprop'),"testprop doesn't exist on 'a'.")
        self.assert_(
            self.a.hasProperty('testprop'),"hasProperty says 'testprop' doesn't exist."
        )
        self.assertEqual(self.a.testprop,45,"testprop is not the correct value.")
        self.assertEqual(
            self.a.getPropertyType('testprop'),int,
            "'testprop' is of incorrect type: %s" % self.a.getPropertyType('testprop')
        )
        self.assertEqual(
            self.a.propertyValues(),[('testprop',45),],
            "propertyValues is incorrect: %s" % self.a.propertyValues()
        )
        self.assertEqual(
            self.a.getPropertyMode('testprop'),'w',
            "'testprop' has an incorrect mode: %s" % self.a.getPropertyMode('testprop')
        )
        self.assertEqual(
            self.a.getPropertyLabel('testprop'),'prop',
            "'testprop' has an incorrect label: %s" % self.a.getPropertyLabel('testprop')
        )
        # adding again should raise propertyExists
        self.failUnlessRaises(
            PropertyManager.PropertyExists,
            self.a.addProperty,'testprop','string'
        )
        # should raise invalid as a attribute exists on the object
        self.failUnlessRaises(
            PropertyManager.InvalidProperty,
            self.a.addProperty,'testprop2','string'
        )

    def test_Setting_02(self):
        """ Test setting and changing properties """
        # first make sure testprop is still there
        self.assertEqual(
            self.a.propertyNames(),['testprop'],
            "propertyNames() returned the wrong names."
        )
        self.a.testprop = 6
        self.assertEqual(self.a.testprop,6,"testprop was not changed correctly.")
        # setting property to readonly should raise errors
        self.a.setPropertyMode('testprop','')
        self.failUnlessRaises(
            PropertyManager.NotAllowed,
            self.a.setProperty,'testprop','str'
        )
        # but _setProperty bypasses these checks
        self.a._setProperty('testprop',11)
        self.assertEqual(
            self.a.testprop,11,
            "_setProperty failed to change property: %s" % self.a.testprop
        )
        # testprop2 is an attribute not a property
        self.failUnlessRaises(
            PropertyManager.NoSuchProperty,
            self.a.setProperty,'testprop2','string'
        )

    def test_Deleting_03(self):
        """ Test removing properties """
        # first make sure testprop is still there
        self.assertEqual(
            self.a.propertyNames(),['testprop'],
            "propertyNames() returned the wrong names."
        )
        # currently mode is '' and deleting should raise an error
        self.failUnlessRaises(
            PropertyManager.NotAllowed,
            self.a.delProperty, 'testprop'
        )
        self.a.setPropertyMode('testprop','wd')
        del self.a.testprop
        self.assert_(not hasattr(self.a,'testprop'),"testprop exists on 'a', it shouldn't.")
        self.assertEqual(
            len(self.a.propertyNames()),0,
            "propertyNames() returned an incorrect number of property names."
        )
        
    def test_float_04(self):
        """ Test Float property conversions """
        # Now lets re-add a property
        self.a.addProperty('testfloat',45.0,mode='w')
        # updateProperty should raise a validation error due to type checking
        self.failUnlessRaises(
            PropertyManager.ValidationError,
            self.a.setProperty,'testfloat','sssss'
        )
        # this update shouldn't raise any errors, but should convert it
        self.a.testfloat = '409'
        self.assertEqual(
            type(self.a.testfloat),float,
            "testfloat #1 is not the correct type: %s" % type(self.a.testfloat)
        )
        self.assertEqual(
            self.a.testfloat,409,
            "type_conversion #1 failure for testfloat: %s"%self.a.testfloat
        )
        # this update shouldn't raise any errors, but should convert it
        self.a.testfloat = '4.09'
        self.assertEqual(
            type(self.a.testfloat),float,
            "testfloat #2 is not the correct type: %s" % type(self.a.testfloat)
        )
        self.assertEqual(
            self.a.testfloat,4.09,
            "type_conversion #2 failure for testfloat: %s"%self.a.testfloat
        )        
        # this update shouldn't raise any errors, but should convert it
        self.a.testfloat = 56
        self.assertEqual(
            type(self.a.testfloat),float,
            "testfloat #3 is not the correct type: %s" % type(self.a.testfloat)
        )
        self.assertEqual(
            self.a.testfloat,56,
            "type_conversion #3 failure for testfloat: %s"%self.a.testfloat
        )
        # this update shouldn't raise any errors, but should convert it
        self.a.testfloat = long(561783)
        self.assertEqual(
            type(self.a.testfloat),float,
            "testfloat #4 is not the correct type: %s" % type(self.a.testfloat)
        )
        self.assertEqual(
            self.a.testfloat,561783.0,
            "type_conversion #4 failure for testfloat: %s"%self.a.testfloat
        )
        
    def test_Selection_05(self):
        """ Test Selection properties """
        # Now lets re-add a property
        testSelection = PropertyManager.Selection(['simon','david','kevin','john'])
        self.failUnlessRaises(
            PropertyManager.ValidationError,
            testSelection.setValue,'value'
        )
        self.failUnlessRaises(
            TypeError,
            testSelection.setValue,('value',)
        )
        testSelection.value = 'david'
        self.a.addProperty('person',testSelection,mode='w')
        # updateProperty should raise a validation error due to type checking
        self.failUnlessRaises(
            PropertyManager.ValidationError,
            self.a.setProperty,'testfloat','sssss'
        )
        self.assertEqual(
            self.a.person,'david',
            "Selection prop 'person' should be 'david' not %s" % self.a.person
        )
        self.a.person = 'kevin'
        self.assertEqual(
            type(self.a.person),str,
            "Selection is not the correct type: %s" % type(self.a.person)
        )
        self.assertEqual(
            self.a.person,'kevin',
            "Selection set failed for person: %s"%self.a.person
        )
        
    def test_DateTime_06(self):
        """ Test DateTime properties """
        self.a.addProperty('testDate',self.getDate(),mode='w')
        self.assert_(
            self.a.hasProperty('testDate'),
            "testDate doesn't appear to exist."
        )
        self.assertEqual(
            type(self.a.testDate),DateTime.DateTimeType,
            "testDate is incorrect type: %s" % type(self.a.testDate)
        )
        self.assertEqual(
            self.a.getPropertyType('testDate'),DateTime.DateTimeType,
            "getPropertyType is returning incorrect type: %s" % self.a.getPropertyType('testDate')
        )
        # now test conversions
        now = self.getDate()
        self.a.setProperty('testDate',now)
        self.assertEqual(
            type(self.a.testDate),DateTime.DateTimeType,
            "testDate is incorrect type: %s" % type(self.a.testDate)
        )
        self.assertEqual(
            self.a.testDate,now,
            "testDate was incorrect changed: %s" % self.a.testDate
        )
        self.a.setProperty('testDate',self.getDate(now-DateTime.RelativeDateTime(minutes=4)))
        self.assertEqual(
            type(self.a.testDate),DateTime.DateTimeType,
            "testDate is incorrect type: %s" % type(self.a.testDate)
        )
        self.assertNotEqual(
            self.a.testDate,now,
            "testDate was incorrect changed: %s" % self.a.testDate
        )
        self.a.testDate = str(now)
        self.assertEqual(
            type(self.a.testDate),DateTime.DateTimeType,
            "testDate is incorrect type: %s" % type(self.a.testDate)
        )
        self.assertEqual(
            self.a.testDate,now,
            "testDate was incorrect changed: %s" % self.a.testDate
        )
        
    def test_Display_07(self):
        """ Testing display methods """
        self.assert_(False,"Not Written yet.")
        

if __name__ == "__main__":
    testRunner(dependenciesOn=False)

