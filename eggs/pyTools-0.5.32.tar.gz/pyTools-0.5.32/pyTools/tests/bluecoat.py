#!/usr/bin/python
"""
This importer uses the CLF to import Bluecoat logfiles.

Following are the ordered fields in the "main" logging format for the bluecoat
proxy device

  date time           - the date of the request 
  time-taken          - length to process request in seconds
  c-ip                - IP of the client
  sc-status           - protocol status code sent to the client
  s-action            - proxy action taken to process request
  sc-bytes            - bytes sent to the client to process request
  cs-bytes            - bytes client sent in request
  cs-method           - method of the request
  cs-uri-scheme       - 
  cs-host             - hostname client is sending request to
  cs-uri-port         - port for the request
  cs-uri-path         -
  cs-uri-query        -
  cs-username         -
  cs-auth-group       -
  s-hierarchy         - 
  s-supplier-name     -
  rs(Content-Type)    - response content type
  cs(Referer)         -
  cs(User-Agent)      -
  sc-filter-result    - filtering result; Denied, Proxied or Observed
  cs-categories       - categories this request falls into
  x-virus-id          -
  s-ip                - IP of the appliance

$Id$
"""

from pyTools.CLFParser import Parser

_map = {
    'a': ('string', 'appliance-ip'),
    'A': ('string', 'cache-action'),
    'b': ('number', 'bytes-sent'),
    'B': ('number', 'bytes-received'),
    'c': ('string', 'client-ip'),
    'C': ('quoted', 'filter-categories'),
    'g': ('string', 'groupname'),
    'h': ('string', 'cache-hierarchy'),
    'm': ('string', 'method'),
    'p': ('number', 'serverport'),
    'r': ('string', 'uri-scheme'),
    's': ('string', 'status'),
    'S': ('string', 'supplier-name'),
    't': ('isodate', 'datetime'),
    'T': ('number', 'time-taken'),
    'q': ('string', 'query_string'),
    'u': ('string', 'username'),
    'U': ('string', 'url-path'),
    'v': ('string', 'servername'),
    'V': ('string', 'virus-id'),
    'W': ('string', 'filter-result'),
    'Referer': ('string','referer'),
    'Content-Type': ('string', 'content-type'),
    'User-Agent': ('quoted', 'user-agent'),
}
parser = Parser('SG_main__2521001060447.log', _map)
parser.LogFormat = "%t %T %c %s %A %b %B %m %r %v %p %U %q %u %g %h %S %{Content-Type}i %{Referer}i %{User-Agent}i %W %C %V %a"

