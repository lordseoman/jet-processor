"""
Test suite for the Common-Log-Format parser.

$Id: test_clfparser.py,v 1.4 2006/03/10 09:37:39 seoman Exp $
"""

from pyTools.Testing import testRunner
from pyTools.TestCases import pyTestCase

from pyTools import CLFParser
from mx.DateTime import DateTime
from pprint import pprint
from itertools import izip
from cStringIO import StringIO


w1='www.obsidian.com.au 203.166.85.157 - [12/05/2003:11:12:45] "GET / HTTP/1.0" 200 5612'
w2='ian.com.au 203.166.85.157 - [12/05/2003:11:12:45] "GET /?f=3 HTTP/1.0" 200 5612'
w3='www.obs.com 203.166.85.157 - - [12/May/2003:11:12:45 +1000] GET "/" HTTP/1.1 200 5612 "-" "Mozilla/4.0 (compatible; MSIE 5.01; Windows 98)"'

class TC_CLFParser(pyTestCase):
    """ Test the common log format parser """
    __StopOnError__ = True
    
    def test_log_format_01(self):
        """ Testing logformat specification """
        p = CLFParser.Parser('clf_data_1.log')
        s = [ x[1] for x in p.getSet() ]
        self.assertEqual(
            s,
            ['servername','remote_host','remote_logname','remote_user','datetime',
             'request','status','bytes_sent','referer','user_agent'],
            "Default processing order is not correct: %s"%s
        )
        p.TimeFormat = "%d%m%Y%H%M%S"
        end,date = p._date(0,"[12052003111245]")
        self.assertEqual(date.day,12,"Day of date is not 12th: %d" % date.day)
        self.assertEqual(date.hour,11,"Hour of date is not 12th: %d" % date.day)
        self.assertEqual(date.minute,12,"Minute of date is not 12th: %d" % date.day)
        self.assertEqual(date.second,45.0,"Second of date is not 12th: %d" % date.day)
        self.assertEqual(date.month,5,"Month of date is not 12th: %d" % date.day)
        self.assertEqual(date.year,2003,"Year of date is not 12th: %d" % date.day)
        p.TimeFormat = "%d/%m/%Y %H:%M:%S"
        end,date = p._date(0,"[12/05/2003 13:11:09 +1000]")
        self.assertEqual(date.day,12,"Day of date is not 12th: %d" % date.day)
        self.assertEqual(date.hour,13,"Hour of date is not 12th: %d" % date.day)
        self.assertEqual(date.minute,11,"Minute of date is not 12th: %d" % date.day)
        self.assertEqual(date.second,9.0,"Second of date is not 12th: %d" % date.day)
        self.assertEqual(date.month,5,"Month of date is not 12th: %d" % date.day)
        self.assertEqual(date.year,2003,"Year of date is not 12th: %d" % date.day)
    
    def test_request_02(self):
        """ Testing Request line """
        p = CLFParser.Parser('clf_data_1.log')
        end,record = p._request(0,'"GET / HTTP/1.1"')
        self.assert_(record,"record is empty: %s" % record)
        self.assertEqual(end,17,"end of line is not correct: %d"%end)
        self.assertEqual(
            record['protocol'],'HTTP/1.1',
            "record protocol is incorrect: %s" % record['protocol']
        )
        self.assertEqual(
            record['method'],'GET',
            "record method is incorrect: %s" % record['method']
        )
        self.assertEqual(
            record['url_path'],'/',
            "record URI is incorrect: %s" % record['url_path']
        )
        end,record = p._request(0,'"post /fred/index.htm?p=45&r=shit HTTP/1.0"')
        self.assert_(record,"record is empty: %s" % record)
        self.assertEqual(end, 44, "end of line is not correct: %d" % end)
        self.assertEqual(
            record['protocol'],'HTTP/1.0',
            "record protocol is incorrect: %s" % record['protocol']
        )
        self.assertEqual(
            record['method'],'POST',
            "record method is incorrect: %s" % record['method']
        )
        self.assertEqual(
            record['url_path'],'/fred/index.htm',
            "record URI is incorrect: %s" % record['url_path']
        )
        self.assertEqual(
            record['query_string'],'?p=45&r=shit',
            "record QueryString is incorrect: %s" % record['query_string']
        )
    
    def test_line_03(self):
        """ Testing parsing a line """
        p = CLFParser.Parser(StringIO())
        p.LogFormat  = "%v %h %u %{%d/%m/%Y:%H:%M:%S}t \"%r\" %s %B"
        record = p.parse(w1)
        self.assert_(record,"record is empty: %s" % record)
        self.assertEqual(
            record['protocol'],'HTTP/1.0',
            "record protocol is incorrect: %s" % record['protocol']
        )
        self.assertEqual(
            record['method'],'GET',
            "record method is incorrect: %s" % record['method']
        )
        self.assertEqual(
            record['url_path'],'/',
            "record URI is incorrect: %s" % record['url_path']
        )
        self.assertEqual(
            record['status'],'200',
            "record status is incorrect: %s" % record['status']
        )
        self.assertEqual(
            record['bytes_sent'],5612,
            "record bytes_sent is incorrect: %s" % record['bytes_sent']
        )
        self.assertEqual(
            record['remote_host'],'203.166.85.157',
            "record remote_host is incorrect: %s" % record['remote_host']
        )
        self.assertEqual(
            record['remote_user'],'-',
            "record remote_user is incorrect: %s" % record['remote_user']
        )
        self.assertEqual(
            record['servername'],'www.obsidian.com.au',
            "record servername is incorrect: %s" % record['servername']
        )
        self.assertEqual(
            record['datetime'],DateTime(2003,5,12,11,12,45),
            "record datetime is incorrect: %s" % record['datetime']
        )

    def test_line_04(self):
        """ Testing parsing line without request """

    def test_basic_formatter_05(self):
        """ Testing as quick formatter """
        p = CLFParser.Parser('clf_data_1.log')
        f = CLFParser.Formatter()
        fp= open('clf_data_1.log')
        for record,line in izip(p,fp):
            s = f.format(record)
            self.assertEqual(
                line.strip(), s, "Parsed doesn't equal original: \n%s\n%s" % (line.strip(),s)
            )
    
    def test_bad_requests_06(self):
        """ Testing bad request handling """
        p = CLFParser.Parser('clf_data_1.log')
        p.LogFormat = "%r %>s"
        # check invalid methods
        s = '"get /scripts/..%255c../winnt/system32/cmd.exe?/c+dir" 404'
        r = p.parse(s)
        self.assertEqual(
            r['method'], 'GET', "Method on #1 is incorrect: %s" % r['method']
        )
        self.assertEqual(
            r['url_path'],
            '/scripts/..%255c../winnt/system32/cmd.exe',
            "URI on #1 is incorrect: %s" % r['url_path']
        )
        self.assertEqual(
            r['query_string'], '?/c+dir',
            "QueryString for #1 is incorrect: %s" % r['query_string']
        )
        self.assert_(
            'protocol' not in r,
            "Protocol on #1 is set: %s" % r.get('protocol')
        )
        # check badly formed requests with spaces
        r = p.parse('"GET / www.example.com HTTP/1.0" 404')
        self.assertEqual(
            r['method'], 'GET', "Method on #2 is incorrect: %s" % r['method']
        )
        self.assertEqual(
            r['url_path'], '/ www.example.com',
            "URI on #2 is incorrect: %s" % r['url_path']
        )
        self.assertEqual(
            r['protocol'], 'HTTP/1.0',
            "Protocol on #2 is incorrect: %s" % r['protocol']
        )
        # check missing protocol
        r = p.parse('"TRACE /" 404')
        self.assertEqual(
            r['method'], 'TRACE', "Method on #3 is incorrect: %s" % r['method']
        )
        self.assertEqual(
            r['url_path'], '/', "URI on #3 is incorrect: %s" % r['url_path']
        )
        self.assert_(
            'protocol' not in r, "Record has a protocol: %s" % r.get('protocol')
        )
        # check empty request
        r = p.parse('"-" 408')
        self.assert_('method' not in r,"Record has a method: %s"%r.get('method'))
        self.assert_('url_path' not in r,"Record has a url: %s"%r.get('url_path'))
        self.assert_('protocol' not in r,"Record has a protocol: %s"%r.get('protocol'))
    
    def test_formatter_07(self):
        """ Testing a more full formatter """
        p = CLFParser.Parser('clf_data_2.log')
        p.LogFormat = "%h %l %u %t \"%r\" %s %B %{Referer}i %{User-agent}i"
        f1 = CLFParser.Formatter()
        f1.LogFormat = "%h %l %u %t \"%r\" %s %B %{Referer}i %{User-agent}i"
        f2 = CLFParser.Formatter()
        f2.LogFormat = "%h %l %u %t \"%r\" %s %b %{Referer}i %{User-agent}i"
        self.assertEqual(f1._format_str(0),"-","format_str is failing.")
        fp= open('clf_data_2.log')
        for record,line in izip(p,fp):
            self.assert_(record,"record appears empty: %s" % record)
            # this is because our data is contradictary
            s1,s2 = f1.format(record),f2.format(record)
            if line.strip() not in (s1,s2):
                self.fail("Parsed doesn't equal original: \n%s\n%s\n%s"%(line.strip(),s1,s2))

    def test_file_08(self):
        """ Testing parsing a test file """
        p = CLFParser.Parser('clf_data_2.log')
        p.LogFormat = "%h %l %u %t \"%r\" %s %B %{Referer}i %{User-agent}i"
        data = {'total_hits': 0, 'total_bytes': 0, 'status': {}, }
        for record in p:
            data['total_hits'] += 1
            data['total_bytes']+= record['bytes_sent']
            if record['status'] not in data['status']:
                data['status'][record['status']] = 1
            else:
                data['status'][record['status']]+= 1
            if record['datetime'].day_of_year not in data:
                data[record['datetime'].day_of_year] = 1
            else:
                data[record['datetime'].day_of_year] += 1
        self.assertEqual(data['total_hits'],399030,"Total is out: %d"%data['total_hits'])
        self.assertEqual(len(p.messages),0,"Errored lines is out: %d"%len(p.messages))
        self.assertEqual(
            data['total_bytes'],2781483541L,
            "Total bytes sent is not correct: %ld" % data['total_bytes']
        )
        for doy,total in zip(xrange(152,160),[60540,58343,64900,34414,48184,72766,58853,1030]):
            self.assertEqual(
                data[doy],total,
                "Total hits on DoY %d is incorrect: %ld" % (doy,data[doy])
            )

    def test_archive_09(self):
        """ Testing archive processing """
        p = CLFParser.Parser('clf_data_2.log.gz')
        p.LogFormat = "%h %l %u %t \"%r\" %s3 %B %{Referer}i %{User-agent}i"
        data = {'total_hits': 0, 'total_bytes': 0, 'status': {}, }
        for record in p:
            data['total_hits'] += 1
            data['total_bytes']+= record['bytes_sent']
            if record['status'] not in data['status']:
                data['status'][record['status']] = 1
            else:
                data['status'][record['status']]+= 1
            if record['datetime'].day_of_year not in data:
                data[record['datetime'].day_of_year] = 1
            else:
                data[record['datetime'].day_of_year]+= 1
        self.assertEqual(data['total_hits'],399032,"Total is out: %d"%data['total_hits'])
        self.assertEqual(len(p.messages),0,"Errored lines is out: %d"%len(p.messages))
        self.assertEqual(
            data['total_bytes'],2781508993L,
            "Total bytes sent is not correct: %ld" % data['total_bytes']
        )
        for doy,total in zip(
            xrange(152,160),[60540,58344,64900,34414,48185,72766,58853,1030]):
            self.assertEqual(
                data[doy],total,
                "Total hits on DoY %d is incorrect: %ld" % (doy,data[doy])
            )


if __name__ == "__main__":
    testRunner(dependenciesOn=False)
