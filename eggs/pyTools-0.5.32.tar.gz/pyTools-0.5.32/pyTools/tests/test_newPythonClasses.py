"""
This is a quick test to ensure our objects work properly with pythons
new object models, and more specifically, for python properties.

$Id: test_newPythonClasses.py,v 1.4 2004/08/25 07:30:43 seoman Exp $
"""
__revision__ = "$Revision : $"[11:-2]

from pyTools.Testing import testRunner
from pyTools.TestCases import pyTestCase as TestCase


class A(object):
    
    def __init__(self):
        self._a = 0
        self.__color = 'a'
    
    def getf(self):
        return self._a
    
    def setf(self, x):
        self._a = x
    
    f = property(getf,setf,doc="f property")


class NewPythonClassTC(TestCase):
    
    def test_Property_01(self):
        """ Testing property """
        b = A()
        self.assertEqual(b.f,0,"f is not initialised")
        b.f = 2
        self.assertEqual(b.f,2,"Failed to set 'f' to 2")
        self.assertEqual(b._a,2,"Set failed to update the variable")


if __name__ == "__main__":
    testRunner(dependenciesOn=False)
