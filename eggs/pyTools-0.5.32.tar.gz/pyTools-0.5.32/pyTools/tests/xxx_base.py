# Test suite for ObjectRegistry

import unittest

__storeroom__ = {
    2 : {'name':'simon'},
    3 : {'name':'fred'},
    4 : {'name':'barnie'}
}

class DummyObject(dict):
    __type__ = "DummyObject"
    
class DummyOwner:
    _id = 318
    def __init__(self):
        pass
    def get(self,id):
        d = DummyObject()
        d.update(__storeroom__.get(id, {}))
        d.__id__ = id
        return d

class TestObjectRegistry(unittest.TestCase):
    def setUp(self):
        pass
    def tearDown(self):
        pass

def test_suite():
    return unittest.makeSuite(TestObjectRegistry, 'check')

if __name__ == "__main__":
    unittest.TextTestRunner().run(test_suite())
