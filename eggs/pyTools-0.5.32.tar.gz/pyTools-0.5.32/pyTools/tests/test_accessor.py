"""
Test suite for Accessor class

$Id: test_accessor.py,v 1.3 2004/08/25 07:30:43 seoman Exp $
"""
__revision__ = "$Revision: 1.3 $"[11:-2]

from pyTools import Accessor,TestCases
from pyTools.Testing import testRunner


def func(arg1, arg2, arg3=None, arg4="last"):
    """ A test function """
    s = "%s-%s" % (arg1,arg2)
    if arg3:
        s += "/"+arg3
    if arg4:
        s += ":"+arg4
    return s
    

class AccessorTC(TestCases.pyTestCase):
    """ Testing Accessor Module """

    def setUpTestCase(cls):
        """ Setting up tests """
        cls.accessor = Accessor.Accessor()
    setUpTestCase = classmethod(setUpTestCase)
        
    def test_Singleton_01(self):
        """ Testing Accessor is Singleton """
        a = Accessor.Accessor()
        self.assertEquals(id(a),id(self.accessor),"1: Not the same.")
        from pyTools.Accessor import Accessor as ac
        b = ac()
        self.assertEquals(id(a),id(b),"2: Not the same.")
        import pyTools.Accessor as ad
        c = ad.Accessor()
        self.assertEquals(id(c),id(b),"3: Not the same.")
        
    def test_RegisteringFunc_02(self):
        """ Testing method registration """
        e1 = self.accessor.add(func,arg2='testB',arg4='tttt')
        e2 = self.accessor.add(func,arg3='ssss')
        s1 = self.accessor[e1]['func']('s1',arg3='s1.3')
        self.assertEquals(s1, "s1-testB/s1.3:tttt", "s1 failed: %s"%s1)
        s2 = self.accessor[e2]['func']('s2a','s2b')
        self.assertEquals(s2, "s2a-s2b/ssss:last", "s2 failed: %s"%s2)


if __name__ == "__main__":
    testRunner(dependenciesOn=False)
