"""
This is the object associations module

Here we want to make an association between 2 objects without being too
concerned with what the objects actually are. As we want to store the
association we need to be able to identify the objects uniquely. One method
is to use an object registry so that we only have to store 2 things in order
to uniquely identify an object; its meta_type (or a unique registry identifier)
and the keys required by the object's class to identify it.

When the an association search is down, the registry can be queried with 
the unique identifier (which then goes and gets the object) in order to 
return the objects with the association.

$Id: AssociationManager.py,v 1.2 2004/04/13 05:13:10 seoman Exp $
"""
__revision__ = "$ Revision: $"[11:-2]


import ObjectRegistry

class BaseAssociation:
    def __init__(self):
        self._items = []
        self._subscribed = False
    def __del__(self):
        del self._items
    def insert(self, oid): 
        if oid not in self._items:
            self._items.append(oid)
            return True
        return False
    def remove(self, oid): 
        if oid in self._items:
            self._items.remove(oid)
            return True
        return False
    def list(self): 
        return self._items
    def listObjects(self):
        return map(lambda x: objectRegistry.getObject(x), self.list())
    def names(self):
        if hasattr(self, '_name'):
            return [self._name]
        elif hasattr(self, '_names'):
            return self._names
        else:
            return []

class SymmetricAssociation(BaseAssociation):
    """
    This is a group type association, where all object of the group have the
    same association with every other member of the group.
    """
    def __init__(self, name):
        "Takes the association name"
        self._name = name
        BaseAssociation.__init__(self)
    def valid(self):
        if len(self._items) > 1:
            return True
        return False
    
class AsymmetricAssociation(BaseAssociation):
    """
    This is a asymmetric association where there is a different name for the
    forward relationship than the reverse relationship (Eg. parent/child).
    """
    def __init__(self, forward, reverse):
        "Requires the forward and reverse naming for this association"
        self._names = (forward, reverse)
        BaseAssociation.__init__(self)
    def insert(self, oid):
        if len(self._items) < 2:
            self._items.append(oid)
            return True
        return False
    def valid(self):
        if len(self._items) == 2:
            return True
        return False

class AssociationManager:
    """
    Class that manages the association object base. 
    """
    def __init__(self):
        self.__objectStore = []
        self.__objectIndex = {}
        
    def associate(self, object, assType):
        """
        Associate an object, you would associate each object with the 
        association until all objects have been associated
        """
        oid = objectRegistry.getObjectID(object)
        if oid and oid not in assType.list():
            ok = assType.insert(oid)
            if not assType._subscribed and assType.valid():
                self._insert(assType)
                assType._subscribed = True
            return ok
        return False

    def clean(self):
        """
        Removes all empty associations, house cleaning.
        """
        for association in self.__objectStore:
            if len(association.list()) == 0:
                self._remove(association)
        return

    def _insert(self, association):
        self.__objectStore.append(association)
        return

    def _remove(self, association):
        """
        Removes and association from the store, returning it without recoupling
        the objects. This is done _only_ to allow different objectStore types
        and thus to remove objectStore operations from elsewhere.
        """
        try:
            ret = self.__objectStore.remove(association)
        except ValueError:
            ret = None
        else:
            ret._subscribed = False
        return ret

    def unassociate(self, object, assType):
        """
        Remove an association between 2 objects.
        """
        oid = objectRegistry.getObjectID(object)
        if oid and oid in assType.list():
            assType.remove(oid)
            return True
        return False

    def findAssociations(self, object=None, association=None):
        """
        Searches the object association store for associations with the 
        specified object and/or with this type of association. Returns a list
        of objects as found by calling listObjects() on each association that
        meets to search criteria.
        """
        retList = self.__objectStore
        if object:
            objId = objectRegistry.getObjectID(object)
            if objId:
                union = filter(lambda x: objId in x.list(), retList)
                retList = filter(lambda x: x in retList, union)
        if association:
            union = filter(lambda x: association in x.names(), retList)
            retList = filter(lambda x: x in retList, union)
        return retList

    def findObjects(self, object=None, association=None):
        retList = []
        results = self.findAssociations(object, association)
        map(lambda x: retList.extend(x.listObjects()), results)
        return retList

    def list(self):
        return self.__objectStore

