"""
Zope Testing Framework using our MetaClass system.

Discussion
----------
This is a standard ZopeTestCase which mixes in our unittest framework to provide
our extended functionality. 

$Id: ZopeTestCase.py,v 1.3 2006/04/10 04:12:40 seoman Exp $
"""
__revision__ = "$Revision: 1.3 $"[11:-2]

from Testing.ZopeTestCase import *
from framework import TestCase as utTestCase
from framework import AutoRegister


class TestCase(utTestCase, ZopeTestCase, object):
    __metaclass__ = AutoRegister
