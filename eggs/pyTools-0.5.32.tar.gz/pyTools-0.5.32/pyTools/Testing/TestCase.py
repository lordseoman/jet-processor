"""

$Id: TestCase.py,v 1.1 2004/08/25 07:30:43 seoman Exp $
"""
__revision__ = "$Revision: 1.1 $"[11:-2]

import unittest


class AutoRegister(type):
    def __init__(cls, *args):
        try:
            cls.alltestcases.append(cls)
        except AttributeError:
            cls.alltestcases = [cls]


class TestCase(unittest.TestCase, object):
    """
    Use this Class to subclass testcases instead of the unittests TestCase.
    """
    __metaclass__   = AutoRegister
    __StopOnError__ = False
    dependencies    = ()
    
    def setUpTestCase(cls):
        """ Set up testcase """
        pass
    setUpTestCase = classmethod(setUpTestCase)

    def tearDownTestCase(cls, result):
        """ Tear down testcase """
        pass
    tearDownTestCase = classmethod(tearDownTestCase)
