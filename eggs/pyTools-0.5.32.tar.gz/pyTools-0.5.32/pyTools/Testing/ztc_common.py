"""
Zope Testing Framework revised

You must set the INSTANCE_HOME and SOFTWARE_HOME in your environment
for these tests to run (inherited from the Zope Testing Framework). Also
if using Zeo then be sure the set ZEO_INSTANCE_HOME also.

To use add the following to every module:

    import os,sys
    if __name__ == '__main__':
        import pyTools.Testing
        execfile(os.path.join(pyTools.Testing.__file__,'ztc_common.py'))

    from pyTools.Testing.ZopeTestCase import TestCase

    class MyTestCase(ZopeTestCase):
        def test_first_01(self):
            self.assert_(False)

        ...

    if __name__ == '__main__':
        testRunner(dependenciesOn=False)

This is shamelessly copied from the framework.py script from Zope Framework
suite, along with a little tweaking.

$Id: ztc_common.py,v 1.3 2006/04/10 04:12:40 seoman Exp $
"""
__revision__ = "$Revision: 1.3 $"[11:-2]

import os,sys

# Save start state
__SOFTWARE_HOME = os.environ.get('SOFTWARE_HOME', '')
__INSTANCE_HOME = os.environ.get('INSTANCE_HOME', '')

if __SOFTWARE_HOME.endswith(os.sep):
    __SOFTWARE_HOME = os.path.dirname(__SOFTWARE_HOME)

if __INSTANCE_HOME.endswith(os.sep):
    __INSTANCE_HOME = os.path.dirname(__INSTANCE_HOME)

# Find and import the Testing package
if not sys.modules.has_key('Testing'):
    p0 = sys.path[0]
    if p0 and __name__ == '__main__':
        os.chdir(p0)
        p0 = ''
    s = __SOFTWARE_HOME
    p = d = s and s or os.getcwd()
    while d:
        if os.path.isdir(os.path.join(p, 'Testing')):
            zope_home = os.path.dirname(os.path.dirname(p))
            sys.path[:1] = [p0, p, zope_home]
            break
        p, d = s and ('','') or os.path.split(p)
    else:
        print 'Unable to locate Testing package.',
        print 'You might need to set SOFTWARE_HOME.'
        sys.exit(1)

import Testing, unittest
execfile(os.path.join(os.path.dirname(Testing.__file__), 'common.py'))

# Include ZopeTestCase support
p = os.path.join(os.path.dirname(Testing.__file__), 'ZopeTestCase')
if not os.path.isdir(p):
    print 'Unable to locate ZopeTestCase package.',
    print 'You might need to install ZopeTestCase.'
    sys.exit(1)

ztc_common = 'ztc_common.py'
ztc_common_global = os.path.join(p, ztc_common)

_found = False
if os.path.exists(ztc_common_global):
    execfile(ztc_common_global)
    _found = True
if os.path.exists(ztc_common):
    execfile(ztc_common)
    _found = True

if _found is False:
    print 'Unable to locate %s.' % ztc_common
    sys.exit(1)

# Override test_suite from the ZopeTestCase's ztc_common.py file.
def test_suite(testMetaClass=None):
    """ Returns a TestSuite from a loader using the metaclass """
    from pyTools.Testing import make_suite
    if testMetaClass is None:
        from pyTools.Testing.ZopeTestCase import TestCase
        testMetaClass = TestCase
    return make_suite(TestCase)

def testRunner(dependenciesOn,testMetaClass=None):
    from pyTools.Testing import make_suite,TestRunner
    if len(sys.argv) > 1:
        arg = sys.argv[-1]
        if arg in ('profile', 'profile-tests'):
            os.environ['PROFILE_TESTS'] = '1'
        elif arg == 'profile-setup':
            os.environ['PROFILE_SETUP'] = '1'
        elif arg == 'profile-teardown':
            os.environ['PROFILE_TEARDOWN'] = '1'
    runner = TestRunner()
    runner.dependenciesOn = dependenciesOn
    if not testMetaClass:
        from pyTools.Testing.ZopeTestCase import TestCase
        testMetaClass = TestCase
    runner.parseArgs()
    if not runner.run(make_suite(testMetaClass)):
        try:
            from Testing.ZopeTestCase import Profiler
            Profiler.print_stats()
        except ImportError:
            print "Install the ZopeProfiler for profile info."

# Debug
print 'SOFTWARE_HOME: %s' % os.environ.get('SOFTWARE_HOME', 'Not set')
print 'INSTANCE_HOME: %s' % os.environ.get('INSTANCE_HOME', 'Not set')
sys.stdout.flush()
