"""
A testing framework that extends and improves (we hope) on the unittest
framework. All you need to do is import TestCase from here instead of the
unittest one.

Thus:

    from framework import TestCase,testRunner

    class MyTestCase(TestCase):
        def test_mine_01(self):
            " A test "
            assert(False)

    if __name__ == '__main__':
        testRunner(dependenciesOn=False)

The name of the tests are 'test_*_xx' where xx is a 2 digit number for the
ordering of the tests.

$Id: __init__.py,v 1.3 2004/08/25 08:39:37 seoman Exp $
"""
__revision__ = "$Revision: 1.3 $"[11:-2]

import sys

from framework import TestCase,TestRunner,TestLoader


def make_suite(testMetaClass,prefix='test',sortUsing=None,suiteClass=None):
    """ Returns a TestSuite that can be run through a TestRunner """
    loader = TestLoader()
    loader.testMethodPrefix = prefix
    if sortUsing:
        loader.sortTestMethodsUsing = sortUsing
    if suiteClass:
        loader.suiteClass = suiteClass
    return loader.loadTestsByMetaClass(testMetaClass)


def testRunner(dependenciesOn, stream=sys.stderr):
    """ Runs the tests """
    runner = TestRunner(stream)
    runner.parseArgs()
    runner.dependenciesOn = dependenciesOn
    return runner.run(make_suite(TestCase))
        
