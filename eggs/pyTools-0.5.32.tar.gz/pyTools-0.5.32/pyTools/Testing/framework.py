"""
A testing framework that extends and improves (we hope) on the unittest
framework. All you need to do is import TestCase from here instead of the
unittest one.

Thus:

    from framework import TestCase,testRunner

    class MyTestCase(TestCase):
        def test_mine_01(self):
            " A test "
            assert(False)

    if __name__ == '__main__':
        testRunner(dependenciesOn=False)

The name of the tests are 'test_*_xx' where xx is a 2 digit number for the
ordering of the tests.


$Id: framework.py,v 1.8 2005/05/30 09:23:13 seoman Exp $
"""
__revision__ = "$Revision: 1.8 $"[11:-2]

import unittest,sys,getopt,time

USAGE = """testRunner method.

Options:

    --help | -h:
    Prints this help screen.

    --verbose | -v 
    Sets verbose output on.

    --quiet | -q
    Turns all output off except for the results.

    --dependencies | -d
    Turn on dependency checking.

Questions..
"""

class AutoRegister(type):
    def __init__(cls, *args):
        try:
            cls.alltestcases.append(cls)
        except AttributeError:
            cls.alltestcases = [cls]


class TestCase(unittest.TestCase, object):
    """
    Use this Class to subclass testcases instead of the unittests TestCase.
    """
    __metaclass__   = AutoRegister
    __StopOnError__ = False
    dependencies    = ()
    
    def setUpTestCase(cls):
        """ Set up testcase """
        pass
    setUpTestCase = classmethod(setUpTestCase)

    def tearDownTestCase(cls, result):
        """ Tear down testcase """
        pass
    tearDownTestCase = classmethod(tearDownTestCase)

    def __call__(self, result=None, indent=""):
        """ Runs this test case """
        result.startTest(self,indent)
        testMethod = getattr(self, self.__testMethodName)
        try:
            try:
                self.setUp()
            except KeyboardInterrupt:
                raise
            except:
                result.addError(self, self.__exc_info())
                return

            ok = 0
            try:
                testMethod()
                ok = 1
            except self.failureException:
                result.addFailure(self, self.__exc_info())
            except KeyboardInterrupt:
                raise
            except:
                result.addError(self, self.__exc_info())

            try:
                self.tearDown()
            except KeyboardInterrupt:
                raise
            except:
                result.addError(self, self.__exc_info())
                ok = 0
                
            if ok: 
                result.addSuccess(self)
        finally:
            result.stopTest(self,indent)
        return


class _TextTestResult(unittest._TextTestResult):
    passed = []

    def startTest(self, test, indent=""):
        """ Called for every test that is run """
        if isinstance(test, TestCase):
            self.testsRun += 1
        if self.showAll:
            self.stream.write(indent+"+ ")
            self.stream.write(self.getDescription(test))
            self.stream.write(" ... ")

    def stopTest(self, test, indent=""):
        """ 
        Called for every test after the tests ends, either by error, failure
        or completion. We test if the test has __StopOnError__ and if failed or
        errored then set the shouldStop flag on the result
        """
        failedTests = self.getFailedTestNames()
        if test.__class__.__name__ in failedTests and test.__StopOnError__:
            if self.showAll:
                self.stream.writeln("%s+ skipping remaining tests."%indent)
            self.shouldStop = True

    def addDependencyFailure(self, test):
        """ Add a test as failed due to dependencies """
        if self.showAll:
            self.stream.writeln("Dep Fail")
        elif self.dots:
            self.stream.write("D")

    def addSuccess(self, test):
        """ Add a successful test to queue """
        if test.__class__.__name__ not in self.passed:
            self.passed.append(test.__class__.__name__)
        unittest._TextTestResult.addSuccess(self, test)

    def getPassedTestNames(self):
        """ Returns a list of passed test names """
        failed = self.getFailedTestNames()
        return [ tn for tn in self.passed if tn not in failed ]

    def getFailedTestNames(self):
        """ Returns a list of all failed and errored test names """
        testFnNames = []
        for t,e in self.errors+self.failures:
            if t.__class__.__name__ not in testFnNames:
                testFnNames.append(t.__class__.__name__)
        return testFnNames
        

class TestSuite(unittest.TestSuite):
    dependencies = ()
    name = None

    def shortDescription(self):
        return self.name

    def __call__(self, result, indent="", dependenciesOn=False):
        """ Run the test suite """
        if not self._tests:
            return
            
        stream = result.stream
        if result.showAll and self.name:
            stream.writeln("%sRunning tests in: %s"%(indent,self.name))
        startTime = time.time()
        ran = 0
        
        # Run the setup for the testSuite
        try:
            self.setUpTestCase()
        except AttributeError,detail:
            stream.writeln("%sFailure in setUpTestCase: %s"%(indent,detail))
            return
        
        # Run the tests
        while self._tests:
            if result.shouldStop:
                break
            testcase = self._tests.pop(0)
            # Is dependency checking turned on
            if dependenciesOn is True:
                depsToCheck = testcase.dependencies
            else:
                depsToCheck = ()
            # check for dependencies
            for dependency in depsToCheck:
                if dependency not in result.testCaseNames:
                    stream.writeln("Warning: unknown dependency: %s"%dependency)
                    continue
                if dependency in result.getFailedTestNames():
                    result.startTest(testcase,indent+'  ')
                    ran += 1
                    result.addDependencyFailure(testcase)
                    break
                if dependency not in result.getPassedTestNames():
                    self._tests.append(testcase)
                    break
            else:
                if isinstance(testcase, TestCase):
                    testcase(result,indent+"  ")
                    ran += 1
                elif self.name:
                    testcase(result,indent+"  ",dependenciesOn)
                else:
                    testcase(result,indent,dependenciesOn)
        result.shouldStop = False
        
        # Run the tearDownTestCase
        try:
            self.tearDownTestCase(result)
        except AttributeError,detail:
            stream.writeln("%sFailure in setUpTestCase: %s"%(indent,detail))
        
        endTime = time.time()
        
        # Output some stats on the tests run
        timeTaken = float(endTime - startTime)
        if self.name and result.dots:
            stream.writeln("")
        if self.name and (result.dots or result.showAll):
            stream.writeln("%s-- Ran %d test(s) in %.3fs"%(indent,ran,timeTaken))
        return


class TestLoader(unittest.TestLoader):
    suiteClass = TestSuite
    
    def sortTestMethodsUsing(x,y):
        return cmp(x[-2:],y[-2:])
    sortTestMethodsUsing = staticmethod(sortTestMethodsUsing)

    def loadTestsFromTestCase(self, testCaseClass):
        """Return a suite of all tests cases contained in testCaseClass"""
        testFnNames = self.getTestCaseNames(testCaseClass)
        suite = self.suiteClass(map(testCaseClass, testFnNames))
        suite.name = testCaseClass.__name__
        suite.setUpTestCase = testCaseClass.setUpTestCase
        suite.tearDownTestCase = testCaseClass.tearDownTestCase
        suite.dependencies = testCaseClass.dependencies
        return suite

    def loadTestsByMetaClass(self, testMetaClass):
        tc_queue = testMetaClass.alltestcases
        tc_names = [ tc.__name__ for tc in tc_queue ]
        suite = self.suiteClass(map(self.loadTestsFromTestCase, tc_queue))
        suite.setUpTestCase = TestCase.setUpTestCase
        suite.tearDownTestCase = TestCase.tearDownTestCase
        suite.testCaseNames = tc_names
        return suite


class TestRunner(unittest.TextTestRunner):

    def _makeResult(self):
        return _TextTestResult(self.stream,self.descriptions,self.verbosity)
    
    def printErrors(self, result):
        """ Output any errors from the resultset """
        result.printErrors()
        result.stream.writeln(result.separator2)
        result.stream.write("FAILED (")
        failed, errored = map(len, (result.failures, result.errors))
        if failed:
            result.stream.write("failures=%d" % failed)
        if errored:
            if failed:
                result.stream.write(", ")
            result.stream.write("errors=%d" % errored)
        result.stream.writeln(")")
        result.stream.writeln("")
        return

    def parseArgs(self):
        """ Parse command args """
        try:
            opts,args = getopt.getopt(sys.argv[1:],'hvqd',
                ['help','verbose','quiet','deoendencies'])
        except getopt.error,detail:
            self.stream.writeln("Unhandled Option: %s" % detail)
            self.stream.writeln(USAGE)
            sys.exit(1)

        for x in opts:
            if x[0] in ('-h','--help'):
                self.stream.writeln(USAGE)
                sys.exit()
            elif x[0] in ('-v','--verbose'):
                self.verbosity = 2
            elif x[0] in ('-q','--quiet'):
                self.verbosity = 0
            elif x[0] in ('-d','--dependencies'):
                self.dependenciesOn = True
        return
            
    def run(self, suite):
        """ Run all tests in the suite """
        stream = self.stream
        if not isinstance(suite, TestSuite):
            stream.writeln("Call with a TestSuite.")
            return False
        # If there are no tests then exit nicely.
        if suite.countTestCases() == 0:
            stream.writeln("No Tests to run.")
            return True
        # Run the tests.
        startTime = time.time()
        result = self._makeResult()
        result.testCaseNames = suite.testCaseNames
        suite(result,dependenciesOn=self.dependenciesOn)
        endTime = time.time()
        # Ouput the error and failure results.
        if not result.wasSuccessful():
            self.printErrors(result)
        timeTaken = float(endTime - startTime)
        ran = result.testsRun
        stream.writeln("Ran a total of %d test(s) in %.3fs"%(ran,timeTaken))
        if self.verbosity > 1 and not result.wasSuccessful():
            stream.writeln(result.separator2)
            passed = result.getPassedTestNames() or ['None',]
            stream.writeln('passed: %s'%' '.join(passed))
            stream.writeln('failed: %s'%' '.join(result.getFailedTestNames()))
            stream.writeln(result.separator2)
        return result.wasSuccessful()
