"""
This file contains various utility functions

$Id: utils.py,v 1.11 2005/07/28 00:28:03 seoman Exp $
"""
__revision__ = "$Revision: 1.11 $"[11:-2]

import string,smtplib,os,socket,random,urlparse,stat,sys
import types,re,DNS,glob
from mx.DateTime import DateTimeType
from os import F_OK
from stat import S_ISDIR,S_ISREG
from email.Utils import formatdate
from email.MIMEText import MIMEText
from StringIO import StringIO


def validUsername(username):
    """
    Returns 1 if username is valid else 0
    """
    ok = username.strip()
    invalidChars = " ,/<>?';:[]{}\=|@$#%^*()`~\""
    for ch in invalidChars:
        if ch in username:
            ok = None
            break
    return ok

def validEmail(email, sloppy=0):
    """
    Returns email address if email is valid else None
    Checks the syntax and domain existance
    """
    if not email or type(email) != types.StringType:
        ok = None
    elif not '@' in email:
        ok = None
    else:
        ok = None
        parts = email.split('@')
        if sloppy and len(parts) == 2:
            ok = email
        elif len(parts) == 2:
            DNS.ParseResolvConf()
            uName = parts[0]
            domain = parts[1].split('.')
            if validUsername(uName):
                for x in range(len(domain)-1):
                    if DNS.mxlookup('.'.join(domain[x:])):
                        ok = email
                        break
    return ok

def resolveDomain(domain, qtype='A'):
    """
    Uses the DNS python module to resolve a domain. Be sure to call the 
    validDomain() function first to ensure that this is a validDomain.
    """
    DNS.ParseResolvConf()
    request = DNS.Request(domain, qtype=qtype)
    request.req()
    if len(request.response.answers) > 0:
        if qtype == 'A':
            return request.response.answers[0]['data']
        elif qtype == 'MX':
            return request.response.answers[0]['data'][1]
    return None

def validURL(url):
    """
    Ensures the given URL is valid, ie resolvable and of the correst form
    """
    if not url:
        ok = None
    else:
        parts = urlparse.urlparse(url)
        if not parts[0] or not parts[1]:
            ok = None
        else:
            try:
                socket.gethostbyname(parts[1])
            except socket.error:
                ok = None
            else:
                ok = url
    return ok

def validIPV4(ip):
    """
    Does error checking for a valid IPV4 ip address.
    """
    ok = 0
    if type(ip) in types.StringTypes and re.match('\d+.\d+.\d+.\d+', ip):
        try:
            socket.inet_aton(ip)
        except socket.error, detail:
            pass
        else:
            ok = ip
    return ok
checkIP = validIPV4

def validDomain(domain):
    """
    Ensures that the given domain is valid, ie resolvable
    """
    domain.strip()
    if '.' not in domain:
        return None
    try:
        socket.gethostbyname(domain)
    except socket.error:
        return None
    else:
        return domain

def generatePassword():
    """
    Returns a random clear & crypted password
    """
    random.seed()
    validChars = "pokmnjiuhbvgytfcxdreszawqzQWERTYUPLKJHGFDSAZXCVBNM"
    validChars += "23456789"
    validCharsPw = validChars + "-+_*()><"

    for n in range(200):
        tmp = ''
        tmpPw = ''
        for n in range(len(validChars)-1):
            x = random.randrange(0,len(validChars)-1)
            tmp += validChars[x]
            tmpPw += validCharsPw[x]
            validChars = validChars[x+1:] + validChars[:x]
            validCharsPw = validCharsPw[x+1:] + validCharsPw[:x]
        validChars += tmp
        validCharsPw += tmpPw
 
    clear_pw = ''
    salt = '$1$'
    for n in range(8):
        salt += validChars[random.randrange(0,len(validChars)-1)]
        clear_pw += validCharsPw[random.randrange(0,len(validCharsPw)-1)]
    salt += '$'
    
    return encryptPassword(clear_pw,salt)

def encryptPassword(clear_pw, salt=None):
    """
    Encrypts a presented password returning a tuple of (clear,crypt).
    If salt is not provided then a random salt is generated, thus to check
    passwords send in the clear password and the encrypted password and
    the return encrypted password should be the same as the salt.
    """
    try:
        import crypt
    except:
        return (clear_pw,clear_pw)
    
    if not salt:
        validChars = "pkmnjiuhbvgytfcxdreszawqzQWERTYUPLKJHGFDSAZXCVBNM"
        validChars + "23456789-_+@#!^&(){}][:;<>"
        for n in range(200):
            tmp = ''
            for n in range(len(validChars)-1):
                x = random.randrange(0,len(validChars)-1)
                tmp += validChars[x]
                validChars = validChars[x+1:] + validChars[:x]
            validChars += tmp
        salt = '$1$'
        for n in range(8):
            salt += validChars[random.randrange(0,len(validChars)-1)]
        salt += '$'

    crypt_pw = crypt.crypt(clear_pw,salt)
    return clear_pw,crypt_pw

def quoteAll(data, quot="'"):
    """
    Returns a quoted string output, using single quotes
    """
    if type(data) not in types.StringTypes:
        data = allStrings(data)
    data = data.strip("'\"")
    return '%s%s%s' % (quot,data,quot)

def doubleQuote(data):
    """
    Wrapper to quote using double qutes
    """
    return quoteAll(data,quot='"')

def allStrings(data,spacing=0,dec=4,pad=0):
    """
    Not the same as 'return data or ""', because we don't want to replace
    0 with "".
    """
    if data == None:
        data = ""
    format = "%"
    if pad:
        format += "0"
    if spacing:
        format += str(spacing)
    
    if type(data) in (types.IntType,types.LongType):
        format += "ld"
    elif type(data) == types.FloatType:
        if type(dec) == (types.IntType,types.FloatType,types.LongType):
            format += "." + str(int(dec))
        format += "f"
    elif type(data) in types.StringTypes + (DateTimeType,):
        data = str(data)
        data.strip()
        format += "s"
    else:
        data = str(data)
    data = format % data
    return data

def filebase(filename=""):
    """
    Returns the basename of the supplied filename
    """
    return filename.split("/")[-1]

def sendMail(text,toaddrs,fromaddr,subject,host,user=None,passwd=None,ssl=0):
    """
    Sends an email to everyone in the toaddrs with the message body in text,
    and the subject. Host is the SMTP host to use and must be supplied, if
    the user/pass is supplied then authentication with the SMTP host is done
    before attempting to send the email.
    """
    msg = MIMEText(text)
    if not subject:
        subject = "Logfile transcript."
    msg.add_header('Subject',subject)
    msg.add_header('From', fromaddr)
    msg.add_header('X-Sender', "pyTools.utils.sendMail()")
    msg.add_header('Date', formatdate(localtime=1))
    msg.add_header('To','')
        
    server = smtplib.SMTP(host)
    server.set_debuglevel(0)
    if user and passwd:
        try:
            server.login(user,passwd)
        except SMTPAuthenticationError,detail:
            return "Authentication Error:",detail
    
    for toaddr in toaddrs:
        msg.replace_header('To', toaddr)
        server.sendmail(fromaddr, [toaddr], msg.as_string())
        
    server.quit()
    return None

### Wrapper for openning files using lockf
##def openFile(fname,mode,defLock=0):
##    """
##    Opens a file in non-blocking incorporating locks for write modes
##    """
##    try:
##        fs = open(fname, mode)
##    except IOError,detail:
##        return None
##
##    if mode != 'r' or defLock:
##        try:
##            fcntl.flock(fs.fileno(), LOCK_EX | LOCK_NB)
##        except IOError:
##            fs.close()
##    return fs
##
### Wrapper for closing a file with the lockf use
##def closeFile(file):
##    if file:
##        fcntl.flock(file.fileno(), LOCK_UN)
##        file.close()

# Actually it seems more appropriate to use access() than stat()
def fileExists(path,base=os.sep):
    """
    Returns 1 if the absolute path exists, otherwise 0
    """
    path = allStrings(path)
    return os.path.exists(path)

def checkDirUID(uid):
    if getDirUID == int(uid):
        return 1
    else:
        return 0

def getDirUID(path):
    if not fileExists(path):
        raise IOError,"path must exist."
    return os.stat(path).st_uid

def findFile(fName,base=os.sep,recurse=1,relative=0):
    """
    Finds the file in the path given, returns a list of fullpaths to
    the requested fName, or just relative to base if 'relative' is set.
    """
    base = allStrings(base)
    if not fileExists(base):
        raise IOError,"Base must exist."

    # clean up the stray '/' if they exist, we could use strip('/')
    fName = allStrings(fName)
    if fName[0] == os.sep:
        fName = fName[1:]
    if fName[-1] == os.sep:
        fName = fName[:-1]
    if base[-1] == os.sep:
        base = base[:-1]
        
    i = 0
    if relative:
        i = len(base.split(os.sep))
    rList = []
    next  = [base]
    while next:
        this = next.pop()
        thisFile = os.path.basename(this)
        if recurse and os.path.isdir(this):
            for entry in os.listdir(this):
                fullpath = os.path.join(this,entry)
                if os.path.isdir(fullpath):
                    next.append(fullpath)
                elif os.path.isfile(fullpath) and entry == fName:
                    if relative:
                        rList.append(os.sep.join(fullpath.split(os.sep)[i:]))
                    else:
                        rList.append(fullpath)
        elif os.path.isfile(this) and thisFile == fName:
            if relative:
                rList.append(os.sep.join(fullpath.split(os.sep)[i:]))
            else:
                rList.append(fullpath)
    return rList

def findPath(path, base=os.sep, recurse=1, useGlob=None):
    """
    Finds the first instance of path starting from the base provided
    Returns 0 on failure or the fullpath on success
    Set useGlob to glob the base instead of doing a listdir.
    """
    # Checks on the base first
    base = allStrings(base)
    if not fileExists(base):
        raise IOError,"Base must exist."
    if base[-1] == os.sep:
        base = base[:-1]
    
    # clean up the stray '/' if they exist
    path = allStrings(path)
    if path[0] == os.sep:
        path = path[1:]
    if path[-1] == os.sep:
        path = path[:-1]
    n = len(path.split(os.sep))
    
    # Get the initial list of files..
    if useGlob is None:
        next = map(lambda x: os.path.join(base,x), os.listdir(base))
    else:
        next = glob.glob(os.path.join(base,useGlob))
    
    # Now run through the list.
    retVal = 0
    next.sort()
    next.reverse()
    while next:
        this = next.pop()
        if os.sep.join(this.split(os.sep)[-n:]) == path:
            retVal = this
            break
        elif recurse and os.path.isdir(this):
            l = map(lambda x: os.path.join(this,x), os.listdir(this))
            l.reverse()
            next = l + next
    
    return retVal

def getPathUsage(path,showDepth=1,skip=[]):
    """
    Calculates the file usage within a specified path, the path must
    exist and be an absolute path. You can use findPath first if your not
    sure where it is. showDepth is how far in to show. Size of directories
    and . & .. dirs are only included in the block size. skip is a list of 
    directories and or files not to be counted, can just be filename and 
    directory name instead of fullpaths, directories in skip will NOT be 
    recursed into.

    Returns a list, each entry is a truple of 3:
        the dir, actual size, block size (on disc)
    """
    if not path:
        return []
    if path[-1] == os.sep:
        path = path[:-1]
    if fileExists(path):
        return []
    
    blockSize = long(os.stat(path).st_blksize / 8)
    rootDepth = len(path.split(os.sep))
    usageList = []
    next = [path]
    dirs = {path: (0,0)}
    while next:
        this = next.pop()
        if this in skip or os.path.basename(this) in skip:
            continue
        bsize = os.stat(this).st_blocks * blockSize
        parts = this.split('/')
        base = string.join(parts[:rootDepth],'/')
        dirs[base] = (dirs[base][0],dirs[base][1]+bsize)
        for x in parts[rootDepth:]:
            base += '/%s' % x
            dirs[base] = (dirs[base][0],dirs[base][1]+bsize)
        for entry in os.listdir(this):
            fullpath = "%s/%s" % (this,entry)
            if fullpath in skip or entry in skip:
                continue
            mode = os.stat(fullpath).st_mode
            if S_ISDIR(mode):
                next.append(fullpath)
                dirs[fullpath] = (0,0)
            elif S_ISREG(mode):
                size = os.stat(fullpath).st_size
                bsize = os.stat(fullpath).st_blocks * blockSize
                parts = this.split('/')
                base = string.join(parts[:rootDepth],'/')
                dirs[base] = (dirs[base][0]+size,dirs[base][1]+bsize)
                for x in parts[rootDepth:]:
                    base += '/%s' % x
                    dirs[base] = (dirs[base][0]+size,dirs[base][1]+bsize)
            else:
                print "Skipping %s" % fullpath
    for dir in dirs.keys():
        if len(dir.split('/')) <= (rootDepth + showDepth):
            usageList.append((dir,)+dirs[dir])
    return usageList

def generateRandomInt(seed=None):
    """
    Returns a random integer number using the random function
    """
    random.seed(seed)
    return random.randrange(0,1607871644)
            
def createTimestamp(data=None):
    """
    Wrapper function to create a local timestamp
    """
    return long(time.time())

def checkInt(entry):
    """
    Checks the input for an int, returns an int if found
    """
    if type(entry) == type(""):
        entry = entry.strip()
    try:
        res = long(entry)
    except:
        return None
    else:
        return res

def createPid(file):
    """
    Creates a pid file with this processes process ID
    """
    try:
        ofs = open(file,'a')
    except:
        retStr = "failed to open pidfile"
    else:
        if ofs:
            ofs.write('%d' % os.getpid())
            ofs.close()
            retStr = None
        else:
            retStr = "open returned None pointer"
    return retStr

def checkPythonVersion(version):
    """
    This function returns 1 if the currently running version of python is 
    higher than or equal the requested version or 0 if lower.
    
    version should be a dot separated string like '2.2.3'
    """
    current_version = "%d.%d.%d" % sys.version_info[:3]
    return current_version >= version

def makeNonBlocking(fd):
    """ Make a file descriptor non-blocking """
    import fcntl
    fl = fcntl.fcntl(fd, fcntl.F_GETFL)
    fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.O_NDELAY)
    return

def runCommand(cmd, input, reqExitCode=None):
    """ 
    Uses a IO pipe to send input to a command fork using Popen3 and return
    the results of the command. If input is a file type object the data will
    be read out of the buffer using readline.
    """
    base = cmd.split()[0]
    if not os.path.exists(cmd.split()[0]):
        print "RunCommand failure, (%s) not found." % cmd.split()[0]
        return None,None
        
    import select,popen2
    
    buflen = 8192
    prc = popen2.Popen3(cmd,1)
    inFd  = prc.tochild.fileno()
    outFd = prc.fromchild.fileno()
    errFd = prc.childerr.fileno()
    
    if type(input) == str:
        input = StringIO(input)
    in_cache = input.read(buflen)
    output = StringIO()
    errput = StringIO()
    
    inWaits = [inFd,]
    outWaits = [outFd, errFd]
    while outWaits:
        ready = select.select(outWaits,inWaits,[])
        if inFd in ready[1]:
            if not in_cache:
                prc.tochild.close()
                inWaits = []
            else:
                count = os.write(inFd,in_cache)
                in_cache = in_cache[count:]
                if not in_cache:
                    in_cache = input.read(buflen)
        if outFd in ready[0]:
            outChunk = os.read(outFd,buflen)
            if outChunk == '':
                prc.fromchild.close()
                outWaits.remove(outFd)
            output.write(outChunk)
        if errFd in ready[0]:
            errChunk = os.read(errFd,buflen)
            if errChunk == '':
                prc.childerr.close()
                outWaits.remove(errFd)
            errput.write(errChunk)
    xcode = prc.wait()
    if reqExitCode is not None and os.WEXITSTATUS(xcode) != reqExitCode:
        print "%s returned %d." % (cmd.split()[0],os.WEXITSTATUS(xcode))
    return output.getvalue(),errput.getvalue()
