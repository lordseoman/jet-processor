"""
A test runner to run all tests

$Id: runTests.py,v 1.3 2005/05/30 09:16:30 seoman Exp $
"""
__revision__ = "$Revision: 1.3 $"[11:-2]


import os,glob
from pyTools.Testing import testRunner


def importTestDir(arg,dirname,files):
    """
    If there is a tests directory in this directory then change into the tests
    directory and import the __init__ file to load in all the tests.
    """
    if 'tests' in files:
        cwd = os.getcwd()
        dirname = os.path.normpath(os.path.join(dirname,'tests'))
        os.chdir(dirname)
        for modName in glob.glob('test_*.py'):
            try:
                __import__(modName[:-3])
            except ImportError,detail:
                print "ImportError:",dirname,detail
        os.chdir(cwd)
    return

if __name__ == "__main__":
    import sys
    if sys.path[0]:
        os.chdir(sys.path[0])
        sys.path[0] = ''
    os.path.walk('.',importTestDir,None)
    testRunner(dependenciesOn=True)

