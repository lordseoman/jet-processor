"""
Obsidian Consulting - DataStorage Handler
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

You use the db_pool to handle the storage of your data whether its in CDB files,
SQL servers or some other type of storage container. This is the primary object
in the Data Storage package that provides access to all objects within the
package.


++Classes
---------

  DataStorage

  Container

  Handler


++Errors
--------

  DbPoolError


++Usage
-------

To use, initiate the StorageHandler and then add/create a container.

So to fire up a connection to a MySQL server:

>>> from pyTools.dbPool import StorageHandler
>>> dataStorage = StorageHandler()
>>> cArgs = {'user': 'test', 'passwd': 'xxxx', 'database': 'test'}
>>> id1 = dataStorage.add('mysql',host='mysql.domain.com',**cArgs)
>>> dataStorage.setDefault(id1)
>>> dataStorage('default').getCursor().showTables()

To add a second SQL server:

>>> id2 = dataStorage.add('postgres',host='ps.domain.com',**cArgs)
>>> dataStorage.run(id2).getCursor().showTables()

You can add more than one server to an identifier, in which case the none 
updating commands will be sent via a round robin. Or you can specify which is 
the master in a replication set, so that update/insert queries are _only_ sent
to the master server. This would require the servers are replicated in some
manner external to the datastore.

Firstly, add a couple of extra hosts:

>>> dataStorage.add('mysql',host='s1.domain.com',identifier=id1,**cArgs)
>>> dataStorage.add('mysql',host='s2.domain.com',identifier=id1,**cArgs)

Now to  set the master get the Connector for the master:

>>> con = daraStorage(id1).getConnector('mysql.domain.com',0,None,'test')
>>> dataStorage(id1).setMaster(con)

Now any read type Queries will go round robin style through all 3 Connectors
while write type Queries will only go through the Master server.


++Transactions
--------------

Transactions are supported through the Cursor but implemented on the Connection.
To use them you need to use the same cursor (database connection) for all
subsequent requests. Not all cursors will support transactions, and some even
support nested transactions.

... configure and setup the pool ...

>>> cursor = dataStorage.run(idx).cursor
>>> cursor.begin()
>>> try:
>>>     cursor.updateRecord({'id':4},'testTable')
>>> except cursor.Errors, detail:
>>>     print "Error:",detail
>>>     cursor.rollback()
>>> else:
>>>     cursor.commit()

The final commit is not necessary if auto_commit is turned on for the container.
When a Cursor object is cleaned up it will check to see if a transaction is 
open and either commit it (if auto_commit is enabled) or rolled back if it isn't
enabled.

The primary method for initiating requests to a container pool is by calling
StorageHandler.run which takes the identifier, and initial method and a post
processing method and the parent. These are optional; if no identifier is 
provided then the default container pool is used. If an initial method is 
provided then it is run prior to running the request and the post method, if
supplied, is run after the request has returned results.

-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Copyright (C) 2003 LGPL Simon Hookway

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

$Id: db_pool.py,v 1.26 2005/06/02 01:21:18 seoman Exp $
"""
__revision__ = "$Revision: 1.26 $"[11:-2]


# System imports
import sys,time

# pyTool imports
from pyTools import HardError,SoftError

# Local imports
from Query import Queries


class DbPoolError(HardError):
    pass

class DepreciatedError(HardError):
    pass


class StorageHandler(object):
    """
    This is the DataStorage class, it is a SingleTon class that holds a pool
    of containers that can be used by an application. It is designed to hold the
    containers/backends where the data is stored so that all applications can
    access the backend without having to hold onto cursors and pass them around
    everywhere.

    It is also designed to allow data to be spread over multiple backends
    transparently of the application layer. 

    I eventually see this pool being a callback style backend that would make it
    safe and efficient to use in a multithreaded application.

    To use the pool, you need to add a Container using:

     >>> from pyTools.dbPool import StorageHandler
     >>> db_pool = StorageHandler()
     >>> db_pool.addContainer(
     ...    connector='mysql',
     ...    host='localhost',
     ...    username='test',
     ...    password='password',
     ...    database='testDB',
     ...    identifier='myhandler',
     ... )
     >>>

    The first container you add will become the default Container, you can set
    the default container by calling db_pool.setDefault(id) after adding the
    Container you want to be the default.

    To run a query on the container above, you would strictly use.

     >>> db_pool.run('myhandler').runquery('show tables')
     [2L]
     >>>

    This would execute the query directly on the backend container, which is not
    something you usually want to do in an application. When calling run() on
    the db_pool and passing in an identifier, you get back a Handler to the
    Container object. Most methods on the Container Handlers will fire up a
    Connector to the next available host, and then a Cursor to use. You can for
    example get a Cursor of off the next available host by calling getCursor().

    Its worth noting that calling run() without an identifier will attempt to
    return to default container.

    Please read the module.__doc__ for more info, or the docs/
    """
    # dictionary containing handlers to indentifier
    __handlers = {}

    # the default identifier to use
    __defIdentifier = 0

    # Errors raised by this object
    Errors = (DbPoolError,DepreciatedError,)

    def __new__(_class):
        """ 
        This is a singleton class, requesting a new instance of the pool 
        returns the current pool instance.
        """
        it = _class.__dict__.get("__it__")
        if it is None:
            _class.__it__ = it = object.__new__(_class)
            it.init()
        return it

    def init(self):
        """ Called on first instanciation """
        pass

    def __repr__(self):
        """ Return a nice representation of ourselves """
        return "<DataStore Pool Handler with %ld Container(s), %ld Open.>" % (
            len(self.__handlers.keys()),
            len(filter(None,self.__handlers.values())),
        )

    def __call__(self, _idx=None):
        """ Returns the requested container pool with _idx identifier """
        return self.run(_idx)

    def setDefault(self, identifier):
        """ Set the default container to use as represented by identifier """
        if not self.__handlers.has_key(identifier):
            raise DbPoolError("No such identifier can be found in the pool.")
        self.__defIdentifier = identifier

    def getDefault(self):
        """ Returns the default Container Handler without wrapping """
        return self.__handlers.get(self.__defIdentifier,None)

    def close(self, commit=1):
        """
        Close all Containers, this calls the close() method for each container
        registered with the pool.
        """
        for c in self.__handlers.values():
            c.close()
        return

    handlers = property(lambda s: s.__handlers)

    def __len__(self):
        return len(self.__handlers)
        
    def __contains__(self, identifier):
        return identifier in self.__handlers
            
    def get(self, identifier):
        """ Returns the container identified by id or None is none exists """
        return self.__handlers.get(identifier, None)
    getContainer = get

    def add(self,connector,host='',port=0,socket='',username='',password='',
            database='',identifier=None,readonly=False):
        """
        Fires up a containerHandler if its available.
        It is expected that the container opens the connection upon first
        use and not when the it is initialised.
        
            connector   - the connector module to use
            host        - hostname/ip of the database server
            port        - port to use, 0 for default
            socket      - set to use a socket connection inplace of TCP
            user/passwd - these are the login details
            database    - name of the db to use on the server
            identifier  - what Container to call/add for this connector 
            readonly    - fail any write type queries
         
        If identifier is given and valid, then the Connector is added to the
        container pool represented by the identifier. Otherwise, a new pool is
        created as identifier and the Connector is added to that pool. If no
        identifier is provided then a new identifier is created as the name of
        the database, if an identifier exists with this name then an exception
        is raised.
        
        Raises a db_pool.Errors exception if the container is not available.
        """
        # The addConnector method, used later
        ac = None
        
        # No identifier and the database is taken
        if not identifier and database in self.__handlers:
            raise DbPoolError("No identifier supplied, and DB name is taken.")
        # database is not taken as a valid identifier
        elif not identifier:
            identifier = database
        # if identifier exists, get the addConnector method
        elif identifier and identifier in self.__handlers:
            ac = self.__handlers[identifier].addConnector
        
        # If no ac, then a new Container is needed
        if not ac:
            self.__handlers[identifier] = Container(identifier)
            ac = self.__handlers[identifier].addConnector
        
        # Tell the Container to add the Connector
        ac(connector,host,port,socket,username,password,database)
        
        # If no default identifier is set yet, make it this one
        if not self.__defIdentifier:
            self.__defIdentifier = identifier
        return identifier
    addContainer = add

    def run(self, identifier=None, initMeth=None, postMeth=None, parent=None):
        """
        Call prior to running a query on a container to return a container
        identified by _identifier_. You can also pass initMeth and postMeth;
        initMeth is run before the handler is returned and postMeth is run just
        before the handler is removed and returned to the pool.

        initMeth and postMeth should take 2 arguments, the handler and parent.
        """
        if len(self.__handlers.keys()) == 0:
            raise DbPoolError("No containers are available.")
        if not identifier:
            identifier = self.__defIdentifier
        elif not self.__handlers.has_key(identifier):
            raise DbPoolError("No such identifier exists in the pool.")
        return Handler(self.__handlers[identifier],parent,initMeth,postMeth)


class Handler(object):
    """ 
    Temporary handler wrapper for containers, this class is used to give all
    Container Handlers the ability to run _pre_ and _post_ methods and pass the 
    parent for the returned object to the _ds_afterCreate method.
    
    You should NEVER hold onto this Wrapper instance when using the container,
    instead hold onto the result of getHandler(). Although you shouldn't really
    do this either as it shortcuts the Database Pool Handlers.
    """
    
    def __init__(self, handler, parent, initMethod=None, postMethod=None):
        """ 
        Hold the internal handler, parent and post method. 
        Run the initMethod straight away, passing it the handler and parent.
        """
        self.__handler = handler
        self.__parent = parent
        self.__postMethod = postMethod
        if initMethod is not None and hasattr(initMethod,'__call__'):
            initMethod(handler, parent)
        
    def __del__(self):
        """ When this wrapper is cleaned up, run the postMethod """
        if self.__postMethod is not None and \
            hasattr(self.__postMethod,'__call__'):
            self.__postMethod(self.__handler, self.__parent)
        
    def __getattr__(self, name, default=None):
        """ Wrapper to reference methods on the handler itself """
        try:
            return object.__getattribute__(self, name)
        except AttributeError:
            return getattr(self.__handler, name, default)

    handler = property(lambda s:s.__handler,doc="Handler to Container object.")


class Container:
    """ 
    This is Container Class.

    A Container is a Virtual storage repository for data, it does not refer to
    a particular host (you can often have multiple Containers refering to the
    same host). It allows you to segregate a set of data by the data instead of
    the host or type of backend.

    You may for example, have a single SQL server that contains a database for
    configiration details and a database for raw data. By making these separate
    Containers you can refer to them separately as if they were different hosts.
    Which may be useful if you replicate the data database but not the configur-
    ation database and want to have multiple containers in the data container
    pool.
    """
    Errors = (DbPoolError,DepreciatedError,)

    # Identifier the StorageHandler uses to refer to this Container
    __identifier = None
    identifier = property(lambda s: s.__identifier)

    # Connectors in this Container
    __connectors = None

    # Identifier of the master backend
    __master = None

    # Master is multi-purpose, can take select queries also
    __MasterIsReadable__ = True

    # Last connector used for select queries
    __last = None

    # Is client-side replication used
    __ClientSideReplication = False
    
    def __init__(self, identifier):
        """ Constructor for basic containers """
        self.__identifier = identifier
        self.__connectors = []

    def __del__(self):
        """ Called when the Container is deleted """
        self.close()

    def __repr__(self):
        """ Represent ourselves nicely """
        return "<Container with %d Connectors>" % len(self.__connectors)

    def __len__(self):
        """ Returns the number of Connectors in this Container """
        return len(self.__connectors)

    def close(self):
        """ Close all Connectors in this Container """
        for x in range(len(self.__connectors)):
            self.__connectors[x].close()
            del self.__connectors[x]
        return

    def __call__(self, query, params=None):
        """ Run a query on this Container """
        if query.__class__ in Queries:
            return self.execute(query)
        else:
            return self.connector.runquery(query,params)
    #
    # Locking implementation only used for Client Side Replication
    #
    __locked = False
    def lock(self):
        """ Locks the Handler """
        self.__locked = True
        
    def unlock(self):
        """ Releases the Handler """
        self.__locked = False
    
    def isLocked(self):
        """ Is this handler locked """
        return self.__locked
    #
    # Access Methods
    #
    def hasConnector(self, host, port, socket, database):
        """ Does this connector exist in the container pool """
        try:
            self.getConnector(host,port,socket,database)
        except DbPoolError:
            return False
        else:
            return True
    
    def getConnector(self, host, port, socket, database):
        """ Returns a Connector for the host/port/socket on db """
        for c in self.__connectors:
            if database != c.database:
                continue
            elif socket and socket == c.socket:
                return c
            elif c.host == host and port == c.port:
                return c
        raise DbPoolError("No such Connector exists for '%s'" % database)
    get = getConnector
    
    def walk(self):
        """
        This is a generator, so using it in a loop will step through the
        connectors starting from the last one accessed. It will step through
        twice, so be aware of this.
        """
        num = len(self.__connectors)
        if not num:
            raise DbPoolError("No Connectors Available.")
        tries = 0
        while tries < 3:
            if num == 1:
                yield self.__connectors[0]
            else:
                if self.__last is None:
                    self.__last = 0
                else:
                    self.__last += 1
                    if self.__last >= num:
                        self.__last = 0
                yield self.__connectors[self.__last]
            time.sleep(0.1)
            tries += 1
        return 

    def nextConnector(self):
        """
        Returns the next Connector in the Pool of Connectors but doesn't check
        whether that Connector has a Connection available. If may be better off
        using self.connection to return a Connection. 
        """
        for c in self.walk(): 
            return c
    connector = property(nextConnector,doc="Return the next Connector.")

    def __next_connection(self):
        """
        Return a Connection on the next available Connector, this will cycle
        through the Connectors until it finds one with an available Connection.
        """
        for cntr in self.walk():
            try:
                cntn = cntr.getConnection()
            except cntr.Errors:
                pass
            else:
                return cntn
        raise DbPoolError("No available Connections on any Connectors.")
    connection = property(__next_connection,doc="Next available Connection.")

    def __set_replication(self, value):
        """ Turn on Replication Support if available """
        if value:
            for c in self.__connectors:
                if not c.isTransactional():
                    break
            else:
                self.__ClientSideReplication = True
        else:
            self.__ClientSideReplication = False

    def __get_replication(self):
        return self.__ClientSideReplication

    replication = property(__get_replication,__set_replication)

    def setMaster(self, connector):
        """
        Sets the supplied Connector as the Master (used for updates and inserts)
        server for this container. If there is currently a master server then it
        is removed and returned to the pool. If you send None as the connector
        then it just returns the master to the pool.

        connector must be a Connector instance or None.
        """
        if connector is not None:
            if not isinstance(connector, ConnectorBase):
                raise DbPoolError("Must add Connector instance.")
            if connector not in self.__connectors:
                raise DbPoolError("Master is not in this Container.")
        # if there is currently a master add it back to the pool
        if self.__master is not None and not self.__MasterIsReadable__:
            self.__connectors.append(self.__master)
        self.__master = connector
        # Remove the Master from connectors if set and not multi-purpose
        if connector is not None and not self.__MasterIsReadable:
            self.__connectors.remove(connector)
        # Make sure Client Side Replication is disabled
        if connector is not None:
            self.replication = False

    def getMaster(self):
        """
        Returns the master server, or the next available Connector is there is
        no currently designated master server.
        """
        if self.__master is None:
            return self.nextConnector()
        else:
            return self.__master
    
    def add(self,cType,host='',port=0,socket='',username='',password='',db=''):
        """
        Add a new Connector to a _host_:_port_ to this Containers Pool of used
        Connectors. Connectors represent a specific database on a specific
        server, queries will be round robined amoung the Connectors in the Pool.
        """
        if self.hasConnector(host,port,socket,db):
            raise DbPoolError("A Connector to host/socket:database exists.")
        
        # Load the Connector from its module
        mName = "%s" % cType
        if mName not in sys.modules.keys():
            module = __import__(mName, globals(), locals(), ['Connector'])
            if not module:
                raise DbPoolError("Connector type not available.")
        else:
            module = sys.modules[mName]
            
        # Add the connector to the pool
        self.__connectors.append(
            module.Connector(
                self,
                host=host,
                port=port,
                socket=socket,
                username=username,
                password=password,
                db=db,
            )
        )
        return
    addConnector = add
    
    def getCursor(self):
        """
        Returns a new Cursor object for the next available Connector in this
        Container pool that has an available Connection.
        """
        return self.connection.cursor

    def execute(self, query):
        """
        Execute a query on the first available Connector (or on all Connectors
        if Client-Side Replication and Transaction support is enabled) where the
        query is a QueryType object. This object is converted into a useable
        format for each Connector.
        """
        if query.__class__.mro() not in Queries:
            raise DbPoolError("query must be QueryType object.")
        if query.type == 'edit':
            if self.replication:
                # Lock Container and run on all Connectors in transaction
                self.lock()
                cursors = []
                results = []
                try:
                    for con in self.__connectors:
                        cursor = con.cursor
                        cursors.append(cursor)
                        cursor.begin()
                        results.append(cursor.execute(query))
                except cursor.Errors,detail:
                    map(lambda c: c.rollback(), cursors)
                    self.unlock()
                    raise
                map(lambda c: c.commit(), cursors)
                self.unlock()
                return results
            elif self.__master is not None:
                # Run on the master server
                return self.__master.execute(query)
        # Otherwise just run on the next available Connector
        return self.connection.cursor.execute(query)

    def runquery(self, query, params=None):
        """
        Runs an traditional query on the Container, or USED to, this has been
        DEPRECIATED and should not be used as it could be dangerous. To do this
        now use: db.run(id).connector.runquery(query,params)
        """
        raise DepreciatedError("This method has been depreciated, see docs!")
    
