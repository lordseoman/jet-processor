"""
This is the basic DataStore object used for SQL object related datastorage.

-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Copyright (C) 2003 LGPL Simon Hookway

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

$Id: DataStore.py,v 1.4 2005/05/30 09:15:36 seoman Exp $
"""
__revision__ = "$Revision: 1.4 $"[11:-2]
   
   
import types

from pyTools.dbPool import StorageHandler
from pyTools.dbPool.Query import *
from pyTools import HardError,SoftError


db_pool = StorageHandler()


class DataStoreError(HardError):
    """ An error occurred manipulating the DataStore """

    
class DataStore(dict):
    """
    This is a global piece of data that is returned from a select or similar
    query, but instead of returning a dict or tuple (or list thereof) we
    return this object which allows for get/set of attributes (or fields).
    Use of this class requires that the table used has a unique index field
    as this is used for the set() call.
    """
    meta_type = "DataStore Object Dictionary"

    Errors = (DataStoreError,)
    
    # The following are set in _beforeCollect
    __TableName__  = None
    __TableType__  = 'normal'
    __IndexField__ = None
    __Fields__ = ()
    __id__ = None

    # AutoCommit mean we commit the D[k] = v every time
    __AutoCommit__ = True

    def __db(self):
        """ Returns a database Connector from the appropriate Container """
        if self.__id__ is None:
            raise DataStoreError("__id__ not configured properly in DS.")
        return db_pool.run(self.__id__,self)
    db = property(__db)
        
    def __cursor(self):
        """ Returns a new Cursor from the appropriate Container """
        return self.db.getCursor()
    cursor = property(__cursor)

    __isSetup = False
    def _ds_beforeReturn(self, resultset):
        """ 
        Called after the result object is created but prior to returning it
        from the ResultSet.
        """
        if self.__isSetup is False:
            self.__id__ = resultset.__id__
            self.__TableName__ = resultset.table_name
            self.__TableType__ = resultset.table_type
            self.__IndexField__= resultset.IndexField
            self.__Fields__ = resultset.fields
            self.__isSetup = True
        return

    def __update__(self):
        """ 
        D.__update__() -> None
        
        Update the backend datastore with the detail in this object.
        """
        if self.__isSetup is False:
            raise DataStoreError("Cannot update before the Object is setup.")
        d = [(k,self[k]) for k in self.__Fields__ if k != self.__IndexField__]
        query = Update(self.__TableName__,**dict(d))
        query.table_type = self.__TableType__
        query.wheres.add(**{self.__IndexField__:self[self.__IndexField__]})
        n = self.cursor.execute(query)
        if n != 1:
            print "cursor returned a n of",n
        return

    def __getattr__(self, name):
        """ Wrapper from getattr to getitem """
        if self.has_key(name):
            return self.__getitem__(name)
        raise AttributeError("no such attribute '%s'" % name)
        
    def __setitem__(self, key, value):
        """ 
        Override for setting an item and in the process updating the backend
        container, if the key doesn't exist or the handler is not set then the
        set will fail. Using this function you can only set one key to value.
        """
        # Return if the handler doesn't exist or if the key doesn't
        if self.__isSetup is False:
            return dict.__setitem__(self, key, value)
        elif not self.has_key(key):
            raise DataStoreError("no such field in the dataStore.")
        elif self.__id__ is None:
            raise DataStoreError("handler is undefined, can't set.")
        elif key == self.__IndexField__:
            raise DataStoreError("can't set the index on DataStore.")

        if self.__AutoCommit__ and self.__isSetup:
            index = self.__IndexField__
            query = Update(self.__TableName__,**{key:value})
            query.table_type = self.__TableType__
            query.wheres.add(**{index:self[self.__IndexField__]})
            self.cursor.execute(query)
        dict.__setitem__(self, key, value)

    def __delitem__(self, key):
        """
        We allow removal of fields for some types of DataStore objects, for
        example, LDAP entries can be removed and fields in a tagged table can
        be removed (as its a record per field), however normal SQL tables can't
        have fields deleted.
        """
        if self.__isSetup is False:
            return dict.__delitem__(self,key)
        raise AttributeError("You can't delete this attribute: %s"%key)
    #
    # State methods for pickling, we only store enough info to retrieve the
    # object from the DataStorage again.
    #
    def __getstate__(self):
        """ 
        Return the index_info for this data object, this includes the DS
        identifier used to collect the object, the table name and type and
        the (index, value) pair. We also include a list of fields since not
        all fields may have been requested.

            index_info = [ 
                identifier,
                tableName,
                tableType,
                (index_field_name, value), 
                fields, 
            ]
         
        """
        return [
            self.__id__,
            self.__TableName__,
            self.__TableType__,
            (self.__IndexField__, self[self.__IndexField__]),
            self.__Fields__,
        ]
        
    def __setstate__(self, index_info):
        """ 
        Restore a DataStore object by using the info from the data object, 
        which must be an index_info object (as described in the __getstate__
        method) and running a select on the passed handler to collect the
        data. If a handler is not passed in then the info hashes are updated
        and we attempt to get a handler from the data sources matching the
        container details saved in the info_hash. If this fails then an object
        is return unlinked to a container.
        """
        self.__isSetup = False
        self.__id__        = index_info[0]
        self.__TableName__ = index_info[1]
        self.__TableType__ = index_info[2]
        self.__IndexField__= index_info[3][0]
        self[self.__IndexField__] = index_info[3][1]
        
        query = Select(self.__TableName__,*self.__Fields__)
        query.table_type = self.__TableType__
        idx = self.__IndexField__
        query.wheres.add(idx=self[idx])

        results = self.cursor.execute(query)
        
        if not results:
            raise DataStoreError("no such object in backend.")
        if len(results) != 1:
            raise DataStoreError("should be 1 object, got %d."%len(results))

        for f in self.__Fields__:
            self[f] = results.getValue(0,f)
        
        self.__isSetup = True
        return 
    #
    # General Accessor methods
    #
    def set(self, **attrs):
        """
        D.set(**kw) -> None
        
        Set multiple fields on this object in one hit, we disable AutoCommit,
        set the fields and then manually call __update__.
        """
        ac = self.__AutoCommit__
        self.__AutoCommit__ = False
        for k,v in attrs.items():
            self[k] = v
        self.__update__()
        self.__AutoCommit__ = ac
        return

    def get(self, name, default=None):
        """
        D.get(name,[default]) -> Value or [value,..]
        
        Fetch name from the dict returning the value or default (if default is
        not passed in then None is returned). You can pass a list or names as
        name and a list will be returned with values in the order that names
        was passed.
        """
        if type(name) in (types.ListType, types.TupleType):
            return [ dict.get(self,n,default) for n in name ]
        elif self.has_key(name):
            return self[name]
        else:
            return default
            
    def popitem(self, key, value):
        raise NotImplementedError("popitem() is not valid on DataStore.")
    
    def pop(self):
        raise NotImplementedError("pop() is not valid on DataStore.")

    def update(self, d):
        """
        D.update(dict) -> None.

        Update the key/value pairs in dict to this object, this is like calling
        D.set(**dict).
        """
        self.set(**d)

    def setdefault(self, key, *d):
        raise NotImplementedError("setdefault() is not valid on DataStore.")
    
        
_d = DataStore()
DataStoreType = type(_d)
del(_d)

