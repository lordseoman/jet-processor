"""
This is the SQL Relay Container module

$Id: sqlrelay.py,v 1.4 2004/08/20 03:52:14 seoman Exp $
"""
__revision__ = "$Revision: 1.4 $"[11:-2]


import types,string,re,signal
from mx import DateTime

from SQLRelay import PySQLRDB, CSQLRelay
from pyTools import utils

from db_pool import DbPoolError,QueryType
from Handler import ContainerBase
from DataStore import DataStore,DataStoreType

SQLRELAY_CONTAINER_TYPE = "SQL Relay Container"


def timeoutHandler(signum, frame):
    """ Handle a timeout if needed, we just raise the appropriate error """
    raise DbPoolError("SQL Request timed out.")


class Container(ContainerBase):
    """ This is the container class for use with SQL Relay """
    meta_type = SQLRELAY_CONTAINER_TYPE
    type = 'sqlrelay'
    
    def __init__(self):
        """ Constructor """
        self.connectDB = PySQLRDB.connect
        ContainerBase.__init__(self)
        self.db = None
        self.useObject = 0
        # SQL-Relay doesn't seem to support timeouts, so use our own
        signal.signal(signal.SIGALRM, timeoutHandler)

    def __del__(self):
        for cursor in self.containers.values():
            cursor.close()
        if self.db:
            self.db.close()

    def strip(self, err):
        """
        SQLRelay has a annoying habit of putting <pre> tags around its error\
        messages so we strip them out here.
        """
        if utils.checkPythonVersion("2.2.3"):
            return str(err).lstrip('<pre>').rstrip('</pre>')
        else:
            return err
        
    def _connect(self, container):
        """
        Makes the SQL Relay connection
        """
        self.sendDebug("Initialising DB connection using SQL-Relay.")
        
        host = self.connArgs[container]['hostname']
        port = self.connArgs[container]['port']
        socket = self.connArgs[container]['socket']
        user = self.connArgs[container]['username']
        passwd = self.connArgs[container]['password']
        # SQL-Relay doesn't seem to timeout shit, so we force it here
        signal.alarm(10)
        self.db = self.connectDB(host,port,socket,user,passwd,0,1)
        signal.alarm(0)
        
        if not self.db:
            raise DbPoolError(self.strip("Failed to connect to SQL Relay."))
        cursor = self.db.cursor()
        return cursor

    def run(self, cursor, query, params=None):
        """
        Internal function that runs a query
        """
        if not CSQLRelay.ping(self.db.connection):
            raise DbPoolError("Connection to SQL Server failed.")
        try:
            num_affected = cursor.executemany(query,params)
        except PySQLRDB.DatabaseError, details:
            raise DbPoolError(self.strip(details))
        else:
            self.sendDebug("Cursor returned with: %s" % num_affected)
            if not num_affected:
                num_affected = CSQLRelay.rowCount(cursor.cursor)
            return num_affected

    def addRecord(self, data, table):
        query = self._buildInsert(data, table)
        c,n = self.runquery(query)
        self.runquery('commit')
        if n == 1:
            return self.getCursor(c).insert_id()
        return n

    def updateRecord(self,updates, table, wheres=None):
        query = self._buildUpdate(updates,table,wheres)
        c,n = self.runquery(query)
        self.runquery('commit')
        return n

    def getQueryType(self, query):
        ret = QueryType()
        t = query.split()[0].lower()
        if t not in ['select',]:
            ret.write = 1
        ret.name = t
        return ret

    def fetchdict(self, container):
        cursor = self.getCursor(container)
        ret = CSQLRelay.getRowDictionary(cursor.cursor,cursor.cur_row)
        cursor.cur_row += 1
        
        dict = DataStore()
        for k,v in ret.items():
            if k.lower() not in ('username','password',) \
                and type(v) == types.StringType:
                try:
                    val = long(v)
                except:
                    pass
                else:
                    v = val
            if re.match("[\d+-]+\w[\d+:]+",str(v)):
                try:
                    t = DateTime.DateTimeFrom(v)
                except:
                    pass
                else:
                    if t.strftime("%Y-%m-%d %H:%M:%S") == v:
                        v = t
            dict[k] = v
        return dict

    def fetchmanydict(self, container, num):
        """
        Returns a list of num dictionaries containing the next num records in
        the result set.
        """
        retList = []
        for x in range(num):
            retList.append(self.fetchdict(container))
        return retList

    def fetchalldict(self, container):
        """
        Returns the full result set as a list of dictionaries.
        """
        retList = []
        cursor = self.getCursor(container)
        for x in range(CSQLRelay.rowCount(cursor.cursor)):
            retList.append(self.fetchdict(container))
        return retList

    def escapeAndQuote(self,data):
        """
        We call this for all values passed into a query
        """
        if data == 'NULL':
            return data
        ret = utils.allStrings(data,dec=None)
        #for ch in ("'",'"'):
        #    ret = ret.replace(ch,"\\"+ch)
        return utils.quoteAll(ret)

    def _buildSelect(self,selects=["*"],wheres=None,froms=None,orderby=None):
        """
        Internal function to build a simple select string
        """
        if not froms:
            raise DbPoolError,"Need to tell me where to get the data from."
                                                                                      
        query = "SELECT %s FROM %s" % (','.join(selects),','.join(froms))
        if wheres:
            query += self._buildWheres(wheres)
        if orderby:
            query += " ORDER BY %s" % ' '.join(orderby)
        return query

    def _buildInsert(self,data,table):
        """
        If data is a list the first row is the field list, the rest are the
        values to add, otherwise if data is a dictionary the keys are the
        field names. 
        
        NOTE: you should always use a list since order is maintained.
        """
        # Sanitise the data into keys and a list of values
        if type(data) == types.DictType:
            keys,vals = data.keys(),[data.values()]
        elif type(data) in (types.TupleType,types.ListType):
            if len(data) < 2:
                raise DbPoolError("Invalid data length.")
            keys = data[0]
            vals = data[1:]
        else:
            raise DbPoolError("Invalid data type for insert.")

        # Now escape and stringify all the values
        keys = map(utils.allStrings, keys)
        vals = map(lambda x:'('+','.join(map(self.escapeAndQuote,x))+')',vals)

        # Build the insert query
        query = "INSERT INTO %s (" % table
        query += string.join(map(utils.allStrings,keys),",")
        query += ") VALUES %s" % ",".join(vals)
        return query

    def _buildInsert0(self,data,table):
        """
        If data is a list the first row is the field list, the rest are the
        values to add, otherwise if data is a dictionary the keys are the
        field names. 
        
        NOTE: you should always use a list since order is maintained.
        """
        # Sanitise the data into keys and a list of values
        if type(data) == types.DictType:
            keys,vals = data.keys(),[data.values()]
        elif type(data) in (types.TupleType,types.ListType):
            if len(data) < 2:
                raise DbPoolError(self.strip("Invalid data length."))
            keys = data[0]
            vals = data[1:]
        else:
            raise DbPoolError(self.strip("Invalid data type for insert."))

        # We stringify the keys just to be on the safe side
        keys = map(utils.allStrings, keys)
    
        # Now create a list of dicts for the parameters.
        data = []
        for insertSet in vals:
            tmp = {}
            for x in range(len(insertSet)):
                tmp['val%d' % (x+1)] = utils.allStrings(insertSet[x])
            data.append(tmp)

        # Make the vals
        vals = ':val'+',:val'.join(map(str,range(1,len(keys)+1)))

        # Build the insert query
        query = "INSERT INTO %s VALUES (%s)" % (table,vals)
        return query,data

    def _buildWheres(self,wheres):
        """
        Internal function that builds a wheres string
        """
        tmp = []
        majorJoinType = wheres[0]
        for item in wheres[1:]:
            joinType = item[0]
            setString = []
            for sets in item[1:]:
                condType = sets[0]
                sets[2:] = map(lambda x: self.escapeAndQuote(x), sets[2:])
                if condType == 'BETWEEN':
                    setString.append(" (%s BETWEEN %s AND %s)" % \
                                     (sets[1],sets[2],sets[3]))
                elif condType == 'IN':
                    setString.append("%s IN (%s)"%(sets[1],','.join(sets[2:])))
                elif condType in ('IS','IS NOT') and sets[2] == "'NULL'":
                    setString.append("%s %s NULL" % (sets[1],sets[0]))
                elif len(sets) == 1:
                    setString.append(sets[0])
                else:
                    setString.append("%s %s %s" % (sets[1],condType,sets[2]))
            tmp.append("(%s)" % string.join(setString," %s " % joinType))
        return " WHERE %s" % string.join(tmp," %s " % majorJoinType)

    def _buildUpdate(self,updates,table,wheres=None):
        """
        Internal function, updates a table records.
        
        updates - is a dictionary of the new values.
        wheres  - is a list of lists, see _buildWheres for details.
        """
        query = "UPDATE %s SET " % table
        sets = map(lambda x: "%s = %s" % (x[0],self.escapeAndQuote(x[1])), 
                    updates.items())
        query += string.join(sets,",")
        if wheres:
            query += self._buildWheres(wheres)
        return query

