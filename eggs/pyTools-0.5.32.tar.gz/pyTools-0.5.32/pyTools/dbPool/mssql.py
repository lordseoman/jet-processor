"""
This is the Microsoft SQL Container module

$Id: mssql.py,v 1.2 2004/08/20 03:52:14 seoman Exp $
"""
__revision__ = "$Revision: 1.2 $"[11:-2]


import types,string
import _mssql

from db_pool import DbPoolError,QueryType
from Handler import ContainerBase

MSSQL_CONTAINER_TYPE = 'Microsoft SQL Container'


class Container(ContainerBase):
    """ This is the container class for use with SQL Relay """
    meta_type = MSSQL_CONTAINER_TYPE
    type = 'mssql'
    
    def __init__(self):
        self.connectDB = _mssql.connect
        ContainerBase.__init__(self)
        self.fetchone = self.fetchtup
        self.fetchall = self.fetchalltup
        self.db = None

    def __del__(self):
        for cursor in self.containers.values():
            cursor.close()

    def _connect(self, container):
        """
        Makes the SQL Relay connection
        """
        host = self.connArgs[container]['hostname']
        user = self.connArgs[container]['username']
        passwd = self.connArgs[container]['password']
        dbName = self.connArgs[container]['database']
        try:
            cursor = self.connectDB(host,user,passwd)
        except _mssql.error, detail:
            raise DbPoolError(detail)
        if not cursor.select_db(dbName):
            raise DbPoolError("Failed to select Database: %s" % dbName)
        return cursor

    def run(self, cursor, sql):
        """
        Internal function that runs a query
        """
        if not cursor.query(sql):
            raise DbPoolError("SQL failed.")
        return 1

    def getQueryType(self, query):
        ret = QueryType()
        t = query.split()[0].lower()
        if t not in ['select','show','desc','explain']:
            ret.write = 1
        ret.name = t
        return ret

    def fetchdict(self, container):
        headers,rowCount,results = self.getCursor(container).fetch_array()
        retDict = {}
        for x in range(len(headers)):
            retDict[headers[x]] = results[0][x]
        return retDict

    def fetchalldict(self, container):
        retList = []
        cursor = self.getCursor(container)
        for x in range(cursor.rowCount()):
            retList.append(cursor.getRowDictionary(x))
        return retList

    def _buildSelect(self,selects=["*"],wheres=None,froms=None,orderby=None):
        """
        Internal function to build a simple select string
        """
        if not froms:
            raise DbPoolError,"Need to tell me where to get the data from."
                                                                                      
        query = "SELECT %s FROM %s" % (','.join(selects),','.join(froms))
        if wheres:
            query += self._buildWheres(wheres)
        if orderby:
            query += " ORDER BY %s" % ' '.join(orderby)
        return query
                                                                                      
    def _buildWheres(self,wheres):
        """
        Internal function that builds a wheres string
        """
        tmp = []
        majorJoinType = wheres[0]
        for item in wheres[1:]:
            joinType = item[0]
            setString = []
            for sets in item[1:]:
                condType = sets[0]
                sets[2:] = map(lambda x: self.escapeAndQuote(x), sets[2:])
                if condType == 'BETWEEN':
                    setString.append(" (%s BETWEEN %s AND %s)" % \
                                     (sets[1],sets[2],sets[3]))
                elif condType == 'IN':
                    setString.append("%s IN (%s)"%(sets[1],','.join(sets[2:])))
                else:
                    setString.append("%s %s %s" % (sets[1],condType,sets[2]))
            tmp.append("(%s)" % string.join(setString," %s " % joinType))
        return " WHERE %s" % string.join(tmp," %s " % majorJoinType)
                                                                                      

