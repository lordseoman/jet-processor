"""

$Id: converters.py,v 1.4 2005/10/05 13:34:11 seoman Exp $
"""
__revision__ = "$ Revision: $"[11:-2]

from mx.DateTime import ISO,\
    DateTimeType,DateTimeDeltaType,DateTimeDeltaFrom,Timestamp
from array import array,ArrayType
from types import NoneType


class Converter(dict):

    encoding = None
    
    def __init__(self, *a, **kw):
        self.update({
            DateTimeType      : self.DateTime2Str,
            DateTimeDeltaType : self.DateTimeDelta2Str,
            int         : self.Long2Str,
            long        : self.Long2Str,
            float       : self.Float2Str,
            dict        : self.convertDict,
            list        : self.convertSequence,
            tuple       : self.convertSequence,
            ArrayType   : self.Array2Str,
            unicode     : self.Unicode2Str,
            str         : self.literal,
            NoneType    : self.None2NULL,
        })
        dict.__init__(self, *a, **kw)

    def _orNone(self, method, s):
        try:
            return method(s)
        except:
            return None
    #
    # Converting from field type to return <-- backend
    #
    def DateTime_or_None(self, s):
        """ Convert a string to a DateTime object, or None """
        return self._orNone(ISO.ParseDateTime,s)

    def Date_or_None(self, s):
        """ Convert a string to a Date object, or None """
        return self._orNone(ISO.ParseDate,s)

    def Time_or_None(self, s):
        """ Convert a string to a Time object, or None """
        return self._orNone(ISO.ParseTime,s)

    def TimeDelta_or_None(self, s):
        """ Convert an interval to a Delta """
        return self._orNone(DateTimeDeltaFrom,s)
    
    def Timestamp_or_None(self, s):
        """ Convert a timestamp string into a Timestamp object """
        s = s + "0"*(14-len(s)) # padding
        p=map(int,filter(None,(s[:4],s[4:6],s[6:8],s[8:10],s[10:12],s[12:14])))
        return self._orNone(Timestamp,tuple(p))

    def Array(self, s):
        """ Turn a blob of text into an Array """
        return array.array('c',s)
    #
    # Converting to string method for -> backend
    #
    def DateTime2Str(self, date):
        """ Convert a DateTime object into a string for storing """
        return self.literal(date.strftime("%04Y-%m-%d %H:%M:%S"))

    def DateTimeDelta2Str(self, date):
        """ Convert a DateDelta object into a string for storing """
        return self.literal(date.strftime("%d:%H:%M:%S"))
    
    def None2NULL(self, o):
        return "NULL"
    
    def Long2Str(self, o):
        return str(o)

    def Float2Str(self, o):
        return '%.15g' % o

    def Unicode2Str(self, o):
        return "'" + o.encode(self.encoding, 'ignore') + "'"
        
    def convertDict(self, o):
        """ Convert the values of 'o' """
        for k in o.keys():
            o[k] = self(o[k])
        return o

    def convertSequence(self, o):
        """ Convert a sequence of values """
        return tuple([ self(x) for x in o ])
    
    def Array2Str(self, o):
        """ Convert an Array of text into a String """
        return self.literal(o.tostring())
    
    def literal(self, s):
        """ Make a String 's' a literal value for DB input """
        return "'" + s + "'"
    
    def __call__(self, ob):
        """ Call to convert ob """
        # if ob is in our list of converters
        if type(ob) in self:
            return self[type(ob)](ob)
        # see if o is an instance of any of the types in converters
        for t in self.keys():
            if isinstance(ob,t):
                return self[t](ob)
        # does the object have a __quote__ or _quote method
        if hasattr(ob,'__quote__') and hasattr(ob.__quote__,"__call__"):
            return ob.__quote__()
        if hasattr(ob,'_quote') and hasattr(ob._quote,"__call__"):
            return ob._quote()
        # otherwise just try repr'ing it
        return repr(ob)

