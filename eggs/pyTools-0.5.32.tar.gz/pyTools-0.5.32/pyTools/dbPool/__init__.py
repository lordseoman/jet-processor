"""
dbPool is another Python Database Storage Handler.

Usage
-=-=-

>>> from pyTools.dbPool import StorageHandler
>>> pool = StorageHandler()
>>> pool.loadConfigXML('datapool_config.xml')
>>> results = pool.run('SHOW TABLES')
>>> results.dump()
+----------------+
| Tables_in_test |
+----------------+
| testTable      |
+----------------+
>>> print len(results)
1
>>> print results
[{'Tables_in_test':'testTable'}]
>>> 

You can add containers using the pool.addContainer() method also.

The ResultSet class allows you to do iterative operations, even when the result
set is not complete. This is usefull for large result sets where the container
supports server side record caching.

How the DataPool works
-=-=-=-=-=-=-=-=-=-=-=

The Storage Handler is a Sington class that loads container modules. Container
modules have the code needed to generate SQL from input data and return a 
result set to the user application. It also has a data_pool that contains the
actual pool you have. For example, you may have a pool containing 2 MySQL dbs,
1 that is a slave and 1 a master. The 2 databases would be replicated on the 
servers side, of course.

When doing a pool.run(query) or pool(query) the handler will select the default
container pool and run the query through that. When a container is asked to run
a query, it requests a Cursor from the Container module and then runs the query
through the Cursor.

If transactions are supported by the container and auto_transactions are on, 
then the creation of a Cursor results in the beginning of a transaction. Or you
can run transactions manually:
    
>>> cursor = pool.getCursor('default')
>>> cursor.begin()
>>> try:
>>>     cursor.updateRecord({'id':4},'testTable')
>>> except cursor.Errors, detail:
>>>     print "Error:",detail
>>>     cursor.rollback()
>>> else:
>>>     cursor.commit()

The transaction is a little silly above as if it fails then there's nothing to
rollback. But if does mean you can run multiple update/add records and if any
fail then rollback.

Some Containers even support nested transactions, in this instance you can do:
    
>>> def addPerson(cur, person):
...     cur.begin()
...     try:
...         cursor.addRecord(p,'testTable')
...     except cursor.Errors, detail:
...         cursor.rollback()
...         return 0
...     else:
...         cursor.commit()
...         return 1
...
>>> cursor = pool.getCursor('default')
>>> cursor.begin()
>>> try:
>>>     cursor.addRecord({'id':4,'name':'test'},'groups')
>>> except cursor.Errors, detail:
>>>     print "Error:",detail
>>>     cursor.rollback()
>>>     return
>>> for p in people:
>>>     done += self._addPerson(cursor,p)
>>> if not done:
>>>     print "Failed to add any people, rolling back group too."
>>>     cursor.rollback()
>>> else:
>>>     try:
>>>         cursor.updateRecord({'members':done),'groups',['',['=','id',4]])
>>>     except cursor.Errors, detail:
>>>         print "Error:",detail
>>>         cursor.rollback()
>>>     else:
>>>         print "Added %d/%d people." % (len(people),done)
>>>         cursor.commit()

This is a more complicated example, we add a number of people to a new group,
here we create the group then add the people one at a time. If any of the people
fail thats okay, but if all failed then we roll the entire thing back. Also we
update the number of members last, to how many suceeded in being added, if that
fails then we also roll the entire transaction back.

Transaction support methods:
    
    begin    - starts a new transaction, adding it to the txn stack.
    rollback - rolls all updates back to the last begin position.
    commit   - commits all current updates.

$Id: __init__.py,v 1.7 2005/06/02 06:11:34 seoman Exp $
"""

__author__ = "Simon Hookway <simon@obsidian.com.au>"
__revision__ = """$Revision: 1.7 $"""[11:-2]
version_info = (
    0,
    3,
    1,
    "alpha",
    1)
if version_info[3] == "final": __version__ = "%d.%d.%d" % version_info[:3]
else: __version__ = "%d.%d.%d%1.1s%d" % version_info[:5]


from db_pool import StorageHandler,DbPoolError
from DataStore import DataStore,DataStoreType
from ResultSet import ResultSet
from Query import *

