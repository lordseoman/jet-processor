"""
This module contains the ResultSet object used to hold/map the returned result
set from a backend query into a list type object that the user can use to
examine or play with the results of the search.

We expect the cursor to return a Result Object as implemented by the backend,
the _get_result() on the Cursor is used to return this object. The only methods
which should be overriden by the backend is;

    _fetch_row(<result object>, <size>) => [(val1, val2, val3, ..), ..]

    This method takes the _result object returned from cursor._get_result()
    and the number of rows to wanted and returns a list of tuple values for
    the fields. If the size is '0' then all results should be returned in
    one big list.


class ResultSet:

    __new__(<cursor instance>)

        => Int(rows affected by query>

        OR

        => ResultSet loaded with results from Cursor

    Note:

        You can take slices and add items to this object, but generally you
        shouldn't. This object will be loaded at instanciation time and should
        then be iterated over or have objects removed, but _NOT_ have objects
        added to it.

        It behaves and inherits from list, but it should not be confused with
        one.

        __setitem__ raises an error.

    Public Attributes:

      o iterator
        Set to a type such as TupleType or DictionaryType, this determines
        the type used when iterating over the resultset in the normal fashion
        and the type of object returned from a __getitem__ or __slice__ call.

    Public Methods:

      o getValue(index,fieldname)

      o getDict(index, fieldname)

      o __iter__()

      o generator(i,j)

      o __as_dict__(i,j)

      o __as_tuple__(i,j,[fields])

      o pop([index])

    Methods not for general use:

      o insert(index, <tuple or dict>)

      o append(<tuple or dict>)

      o remove(<tuple or dict>)

      o __add__


This object is designed to store the values for a Query result as tuples and
not dicts, you can access them as dicts however. Its not a general purpose
holding object for dicts.


$Id: ResultSet.py,v 1.16 2005/10/09 23:45:37 seoman Exp $
"""
__revision__ = "$Revision: 1.16 $"[11:-2]

# Local imports
from pyTools import HardError,SoftError
from pyTools.PropertyManager import PropertyDictAware
from DataStore import DataStore


class ResultsError(HardError):
    """ Error collecting the results """
    pass


class ResultSetFull(SoftError):
    """ Results has hit the __MaxRows__ """
    pass


class ResultSet(list):
    """
    This is a mixin class to be implemented with a backend module to provide a
    ResultSet object when returning the results of a Query. It provides easy
    methods to iterate over the resultset as a dict, tuple or object type. We 
    also manage 'tagged' tables transparantly in here.
    """
    # Maximum rows we can cache, this is to prevent silly counts
    __MaxRows__ = 100000
    
    # Errors raised by this class
    Errors = (ResultsError,ResultSetFull,)

    # Default Object Class for __as_object__
    __Default_Object = DataStore

    __fields = ()
    fieldcount = 0
    description = None

    __table_name = ''
    __table_type = 'normal'
    __selected_fields = ()
        
    def __new__(cls, cursor):
        """
        Returns an instance of ResultSet if there are results, otherwise we
        return the number of affected rows by the query.
        """
        _result = cursor._get_result()
        if _result is None:
            # just return the affected rows
            return cursor.affected_rows()
        else:
            # Create a new ResultSet instance and load the results
            resultSet = list.__new__(cls)
            query = cursor.executed_query
            if query is not None:
                resultSet.__table_name  = query.table
                resultSet.__table_type  = query.table_type
                resultSet.__selected_fields = query.selects
                resultSet.IndexField = cursor.connection.getTableIndex(query.table)
            resultSet.__load_results(_result)
            return resultSet

    def __init__(self, cursor):
        """ Initialise with a cursor """
        self.__id__ = cursor.identifier

    table_name = property(lambda s:s.__table_name)
    table_type = property(lambda s:s.__table_type)
    fields = property(lambda s:s.__fields)
    
    def __load_results(self, _result):
        """
        Create a new ResultSet, we copy all of the rows from the backend
        result object into this list object. This seems a little strange and
        exhaustive to me, but without knowing why we can't just reference
        the backend result objects i'm doing it this way.
        """
        self.fieldcount = self._result_fieldcount(_result)
        self.description= self._result_description(_result)
        
        # Collect and Store the results
        rowcount = self._result_rowcount(_result)
        if self.__table_type == 'normal':
            # use the fields from the description since some Select can use
            # fields like 'count(row1) as hits' as the field which is not what
            # we want for fieldnames
            self.__fields = [ f[0] for f in self.description ]
            for r in self._walk_result(_result):
                self.append(r)
            # Check we got all the rows
            if rowcount != len(self):
                raise ResultsError("Didn't fetch all rows.")
        elif self.__table_type == 'tagged':
            # in tagged we _must_ trust the query as the not all records might
            # have all the keys as so we wont know which to set to None as the
            # resultSet must have an entry for each field selected to be 
            # consistant with the implementation. We also make sure that the
            # 'id' field is in the set.
            self.__fields = self.__selected_fields[:]
            if 'id' not in self.__fields:
                self.__fields.insert(0,'id')
            self.fieldcount = len(self.__fields)
            desc = ('id',)
            data = {}
            first = True
            count = 0
            for idx,attr,value in self._walk_result(_result):
                count += 1
                if attr not in desc:
                    desc += (attr,)
                # very first row
                if not data:
                    data = {'id': idx, attr: value, }
                # if the index has changed, save the data
                elif idx != data['id']:
                    self.append(tuple([ data.get(k) for k in self.__fields ]))
                    data = {'id': idx, attr: value, }
                # if this attr exists in data
                elif attr in data:
                    data[attr] = [data[attr],value]
                # otherwise new attr, add it to data
                else:
                    data[attr] = value
            # Add the final one
            if data:
                self.append(tuple([ data.get(k) for k in self.__fields ]))
            # Check we got all the rows
            if count != rowcount:
                raise ResultsError("Didn't fetch all rows.")
        else:
            raise ResultsError("Unknown table type from query: %s" %
                self.__table_type
            )
        return

    def _result_description(self, _result):
        raise NotImplementedError("implementation is missing override.")

    def _result_rowcount(self, _result):
        raise NotImplementedError("implementation is missing override.")

    def _result_fieldcount(self, _result):
        raise NotImplementedError("implementation is missing override.")

    def _fetch_row(self, _result, size=1):
        """ Return a single row from the _result object """
        return _result.fetch_row(size)
        
    def _walk_result(self, _result):
        """ Generator over the _result object returning them 1 at a time """
        while 1:
            rows = self._fetch_row(_result,1)
            if not rows:
                break
            for r in rows:
                yield r
        return

    def __getslice__(self, i=None, j=None):
        """ Return a slice of the ResultSet in the Iterable object type """
        return [ x for x in self.__Default_Iterator(i,j) ]

    def __setslice__(self, i=None, j=None):
        raise NotImplementedError("setting slices isn't allowed in ResultSet")

    def __delslice__(self, i=None, j=None):
        raise NotImplementedError("deleting slices isn't allowed in ResultSet")

    def __add__(self, l):
        """ Append the list 'l' onto ourselves and return us """
        for r in l:
            self.append(r)
        return self

    def __mul__(self, l):
        raise NotImplementedError("mul operator is not valid on ResultSet.")
    
    def append(self, value):
        """ Add a dict/tuple/list to the list """
        if len(self) == self.__MaxRows__:
            raise ResultSetFull("ResultSet is full, consider using a LIMIT.")
        if type(value) in (list,tuple):
            if len(value) != len(self.__fields):
                raise ValueError("appending tuple/list of wrong size.")
            list.append(self,tuple(value))
        elif type(value) != dict:
            raise TypeError("must append a dict/tuple/list only.")
        else:
            list.append(self,tuple([ value.get(k) for k in self.__fields ]))

    def insert(self, index, d):
        """ Add a dict/tuple/list to the list at position 'index' """
        if len(self) == self.__MaxRows__:
            raise ResultSetFull("ResultSet is full, consider using a LIMIT.")
        if type(d) in (list,tuple):
            if len(d) != len(self.__fields):
                raise ValueError("inserting tuple/list of wrong size.")
            list.insert(self,index,tuple(d))
        elif type(d) != dict:
            raise TypeError("RecordStore store dictionaries only.")
        list.insert(self, index, tuple([ d.get(k) for k in self.__fields ]))
    
    def remove(self, value):
        """ Delete an item by value """
        if type(value) == dict:
            list.remove(self,tuple([ d.get(k) for k in self.__fields ]))
        elif type(value) in (list,tuple):
            list.remove(self,value)
        else:
            raise TypeError("remove takes a list/tuple/dict value only.")
        
    def index(self, value):
        raise NotImplementedError("index is not valid on ResultSet.")
        
    def generator(self, i=None, j=None):
        """ Return a generator for the slice [i:j] using Default Iterator """
        return self.__Default_Iterator(i,j)

    def __getitem__(self, index):
        """ Returns an item/row as the Default Iterable object type """
        if type(index) not in (int,long):
            raise TypeError("index must be numeric.")
        for i in self.__Default_Iterator(index,index+1):
            return i
        raise ResultsError("Should not have gotten here.")

    def __setitem__(self, index, value):
        raise NotImplementedError("setitem is not valid on ResultSet.")
    #
    # Iterators using generators
    #
    def __iter__(self):
        """ Default the iterator to using __as_tuple__ """
        return self.__Default_Iterator()
    
    def __fix_xy(self, x, y):
        """ internal, fixes 'x' and 'y' for ranges """
        x = x is not None and x or 0
        if x < 0:
            x = len(self) + x
            x = (x > 0) and x or 0
        y = y is None and len(self) or (y or 0)
        if y < 0:
            y = len(self) + y
        return x,y
        
    def __as_object__(self, x=None, y=None, objectClass=None):
        """
        R.__as_object(x,y,objectClass) -> Generator.
        
        Generator to iterate over the results returning each result as an
        instance of 'objectClass' or Default Iterator Object.
        """
        objectClass = objectClass or self.__Default_Object
        x,y = self.__fix_xy(x,y)
        while x < len(self) and x < y:
            d = objectClass()
            if hasattr(d,'_getFieldMap'):
                mapping = d._getFieldMap()
                idlist = [ mapping[f] for f in self.__fields ]
            else:
                idlist = self.__fields
            for j in range(self.fieldcount):
                d[idlist[j]] = list.__getitem__(self,x)[j]
            try:
                d._ds_beforeReturn(self)
            except AttributeError:
                pass
            yield d
            x += 1
        return 
    
    def __as_dict__(self, x=None, y=None):
        """ 
        Generator to iterate over the resultset returning each result as a dict
        instead of a tuple.
        """
        x,y = self.__fix_xy(x,y)
        while x < len(self) and x < y:
            d = {}
            for j in range(self.fieldcount):
                d[self.__fields[j]] = list.__getitem__(self,x)[j]
            yield d
            x += 1
        return
    
    def __as_tuple__(self, x=None, y=None, fields=None):
        """ Walk the results from 'x' to 'y' returning tuples """
        x,y = self.__fix_xy(x,y)
        while x < len(self) and x < y:
            if fields is None:
                yield list.__getitem__(self,x)
            else:
                t = ()
                for f in fields:
                    try:
                        i = self.__fields.index(f)
                    except IndexError:
                        t += (None,)
                    else:
                        t += (list.__getitem__(self,x)[i],)
                yield t
            x += 1
        return
    
    __Default_Iterator = __as_tuple__
    def __set_iterator(self, ob):
        if ob is tuple:
            self.__Default_Iterator = self.__as_tuple__
        elif ob is dict:
            self.__Default_Iterator = self.__as_dict__
        elif dict in ob.mro():
            self.__Default_Object = ob
            self.__Default_Iterator = self.__as_object__
        else:
            raise ResultsError("Invalid type for iterator default.")
    iterator = property(fset=__set_iterator)
    #
    # Accessor methods
    #
    def getValue(self, index, name=None):
        """
        Return a value for a given field at the index provided, a name of None
        will return a tuple of values for that record number.
        """
        if name is None:
            return list.__getitem__(self,index)
        elif name not in self.__fields:
            raise AttributeError("'%s' is not a valid field name." % name)
        else:
            return list.__getitem__(self,index)[self.__fields.index(name)]
    
    def getDict(self, index):
        """ Returns a dictionary of the record at index """
        for i in self.__as_dict__(index,index+1):
            return i
        raise ResultsError("Should not have gotten here.")

