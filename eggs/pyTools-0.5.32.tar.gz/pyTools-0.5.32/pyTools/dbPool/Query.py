"""
General Request builder.

The idea of this module is to build a Request for a backend call using totally
abstract objects and build it in a OO manner. So that to build a request where
records either have a username of 'simon' or a status in 'cancelled',
'terminated' then you would:
    
    OR(username='simon',status=IN('cancelled','terminated'))

Example:
    
    >>> wheres = Wheres(
    ...     OR(username='simon',firstname=LIKE('imon')),
    ...     status=IN('active','suspended')
    ... )
    >>> wheres.sql()
    WHERE 
        (username = 'simon' OR firstname LIKE '%mon%')
      AND 
        status IN ('active','suspended')
    >>> 
        
Note that in request queries the order of the arguments is _very_ important to
the efficency of the resulting request. Also understand that in python you must
specify non-keyword args before keyword args, so doing the above query in 
reverse order is not possible. For this reason there is an add method that can
be used to add items to the query in order, so to do the above query with
reversed args:
    
    >>> wheres = Wheres(status=IN('active','suspended'))
    >>> wheres.sql()
    WHERE 
        status IN ('active','suspended')
    >>> wheres.add(OR(username='simon',firstname=LIKE('imon')))
    >>> wheres.sql()
    WHERE 
        status IN ('active','suspended')
      AND 
        (username = 'simon' OR firstname LIKE '%mon%')
    >>> 

Notice that it is default to AND the arguments, you could process the args as
an OR() before creating the Wheres or you can tell it to OR them:
    
    >>> wheres.sql(OR)    
    WHERE 
        status IN ('active','suspended')
      OR 
        (username = 'simon' OR firstname LIKE '%mon%')
    >>> 

These are paramstyle queries, to use them you would do something like:

    >>> db = MySQLdb.connect( ... )
    >>> cursor = db.cursor()
    >>> wheres = Wheres(status=IN('active','suspended'))
    >>> wheres.add(OR(username='simon',firstname=LIKE('imon')))
    >>> qry,args = wheres.do()(paramstyle='pyformat')
    >>> cursor.execute("SELECT * FROM table1 " + qry, args)
    >>> cursor.fetchall()
    >>>

--------------- CUT FROM Handler ------------------

, if you want columns from
2 tables you need to join then, ie:
    
    >>> con = db_pool.getContainer(identifier)
    >>> query = con.SelectQuery(['id','name'],table='table1')
    >>> query.sql
    SELECT
      id,name
    FROM
      table1
    >>> join = query.Join('table2','id','id')
    >>> join.select = ['desc']
    >>> query.sql
    SELECT 
      table1.id,table1.name,table2.desc 
    FROM 
      table1,table2 
    WHERE 
      table1.id = table2.id
    >>> query.wheres.add(name=con.LIKE('test'))
    >>> query.sql
    SELECT 
      table1.id,table1.name,table2.desc 
    FROM 
      table1,table2 
    WHERE 
      table1.id = table2.id 
      AND
      table1.name LIKE '%test%'
    >>> 

Note that when you do a Join and set something to be selected from the joined
table there is an implicit WHERE created between the linking columns. A basic
join takes the form:

  o Join(<tablename>,<column-name-on-left>,<column-name-on-join>)

And the implicit link is:
  
    <query.table>.<col-on-left> = <join.table>.<col-on-join>
    
Other joins are:
    
    o LeftJoin(<table>, <col-on-left>, <col-on-right>) 
      A left join selects primarily from the left table and fills in the selects
      from the right table where there is not a corresponding entry in the table
      with NULL's.
    
    o RightJoin(<table>, <col-on-left>, <col-on-right>)
      A right join is analagous to the left join; it fills in selects from the
      left table that do not has corresponding entries from the right table.
      
Example:
    
    >>> db = pool(identifier).getConnector()
    >>> request = db.Select(table='people')
    >>> request.select = ['id','firstname','lastname']
    >>> request.dumpSQL()
    SELECT
      id,firstname,lastname
    FROM
      people
    >>> join = request.LeftJoin('roles','id','uid')
    >>> join.select = ['role']
    >>> request.dumpSQL()
    SELECT 
      people.id,people.firstname,people.lastname,roles.role
    FROM 
      people
    LEFT JOIN
      roles
    ON
      people.id = roles.id
    WHERE 
      roles.id IS NOT NULL
    >>> join.wheres + ('=','roles.role','editor')
    >>> request.dumpSQL()
    SELECT 
      people.id,people.firstname,people.lastname,roles.role
    FROM 
      people
    LEFT JOIN
      roles
    ON
      people.id = roles.id
    WHERE 
      roles.id IS NOT NULL
      AND
      roles.role = 'editor'
    >>> 

This would return all people with the editor role. By default LeftJoin and 
RightJoin will include the correct WHERES to restrict the returned results to
those unique to the left or right table respectively. This behaviour can be 
changed by setting join.restrict = False.

Tagged tables _MUST_ have the following layout:

    id, attribute, value, start_date, end_date

$Id: Query.py,v 1.12 2005/06/23 04:25:33 seoman Exp $
"""
__revision__ = "$Revision: 1.12 $"[11:-2]


import types,re
from pyTools import HardError,SoftError
from converters import Converter

re_INSERT = re.compile(r'\svalues\s*(\(.+\))',re.IGNORECASE)


class BadQuery(HardError):
    """ Query is incorrectly setup """
    pass


class NamedMapping(list):
    """ A named map for generating requests using paramstyles """
    __s = ""

    def __getNextKey(self):
        return "nm_%05d" % (len(self)+1)
    next_key = property(__getNextKey)

    def prepend(self, qry_str, *values):
        """ Add qry_str to the front of the query """
        if type(qry_str) != types.StringType:
            raise TypeError("first argument must be a string.")
        map(lambda v,l=list,s=self: l.insert(s,0,v), values)
        self.__s = qry_str + self.__s
        return

    def append(self, qry_str, *values):
        """ Adds an item to the map and returns the key for it """
        if type(qry_str) != types.StringType:
            raise TypeError("first argument must be a string.")
        map(lambda v,l=list,s=self: list.append(s,v), values)
        self.__s += qry_str
        return

    def __call__(self, paramstyle='format'):
        """ Returns a paramstyle formatted string and args """
        if paramstyle == 'pyformat':
            m = re_INSERT.search(self.__s)
            if m:
                d2 = []
                for x in self:
                    d2.append(
                        dict([ ("nm_%05d"%(y+1),x[y]) for y in range(len(x)) ])
                    )
                d1 = [ "%%(%s)s" % k for k in d2[0].keys() ]
                d1.sort()
            else:
                d1,d2 = [],{}
                for x in range(len(self)):
                    d1.append("%%(nm_%05d)s" % (x+1))
                    d2["nm_%05d" % (x+1)] = self[x]
            return self.__s % tuple(d1), d2
        elif paramstyle == 'named':
            d1,d2 = [],{}
            for x in range(len(self)):
                d1.append(":nm_%05d" % (x+1))
                d2["nm_%05d" % (x+1)] = self[x]
            return self.__s % tuple(d1), d2
        elif paramstyle == 'format':
            return self.__s, self[:]
        elif paramstyle == 'qmark':
            return self.__s.replace("%s","?"), self[:]
        elif paramstyle == 'numeric':
            return self.__s % map(lambda n: str(n), range(len(self))), self[:]
        return self.query,None

    def __dict(self):
        """ Return the map """
        d = {}
        for x in range(len(self)):
            d["nm_%05d" % (x+1)] = self[x]
        return d
    dict = property(__dict)
    
    def quote(self, s):
        return "'"+s.replace("'","\\'").replace(";","\\;")+"'"
    
    def escape(self, o, conv=None):
        """
        Escape the object 'o' using 'conv' to convert 'o' into a string or
        storable object first and then escaping as necessary.
        """
        conv = conv or Converter({str:self.quote,})
        return conv(o)
    
    def query(self, conv=None):
        """ 
        Returns the de-parametized query using the provided 'conv' converter
        dictionary or the default converter.
        """
        m = re_INSERT.search(self.__s)
        if m:
            p = m.start(1)
            qv= self.__s[p:]
            q = [ self.__s % self.escape(self[0],conv) ]
            q.extend([ qv % self.escape(a,conv) for a in self[1:] ])
            return ','.join(q)
        else:
            return self.__s % self.escape(self,conv)
    query = property(query)

    def __qry_str(self):
        return self.__s
    qry_str = property(__qry_str)


class _Base(object):
    """ A base for both Query, Wheres and FieldBase """
    parent = None
    root = property(lambda s: s.parent is not None and s.parent.root or s)
    
    Errors = (BadQuery,)

    def __init__(self, ob):
        """ Takes a single value """
        if type(ob) == types.StringType:
            ob = EQUAL(ob)
        elif _Base not in ob.__class__.mro():
            raise BadQuery("Invalid object passed as value to %s." %
                self.__class__.__name__
            )
        ob.parent = self
        self._o = ob
        return

    def __get_transformer(self):
        if self.parent is None:
            return getattr(self,'_Base__transformer',TransformerFactory.factory)
        else:
            return self.root.transformer

    def __set_transformer(self, factory):
        if self.parent is None:
            self.__transformer = factory
        else:
            self.root.transformer = factory
        return

    transformer = property(__get_transformer,__set_transformer)

    def __get_processing(self):
        if self.parent is None:
            return getattr(self,'_Base__processing',False)
        else:
            return self.root.start_processing

    def __set_processing(self, value):
        if self.parent is None:
            if value:
                self.__processing = True
            else:
                del self.__processing
        else:
            self.root.start_processing = value
        return
    
    start_processing = property(__get_processing,__set_processing)

    def __map(self):
        """ Return the map from the paren, or a new Map """
        if self.start_processing is True:
            self.root._map = NamedMapping()
            self.start_processing = False
        elif not hasattr(self.root, '_map'):
            self.root._map = NamedMapping()
        return self.root._map
    map = property(__map)
            
    def once(self, item):
        """ Run through expanding single item """
        if isinstance(item,(AND,OR,NOT,NotFactory)):
            item.do()
        elif type(item) == types.TupleType and len(item) == 2:
            item[1].do(item[0])
        else:
            raise BadQuery("%s should never have gotton onto us." % item)
        return
        
    def traverse(self, separator, pre="", post=""):
        """ Generator to step through the args """
        if pre:
            self.map.append(pre)
        len_o = len(self._o)
        for x in range(len_o):
            self.once(self._o[x])
            if (x+1) < len_o:
                self.map.append(separator)
        if post:
            self.map.append(post)
        return
                
    def do(self):
        """ Returns a NamedMapping instance """
        if self.parent is None:
            self.start_processing = True
        self.transformer(self)
        return self.map

    def sql(self, *a, **kw):
        """ Return the SQL string this query represents """
        self.start_processing = True
        self.do(*a, **kw)
        return self.map.query
    

class _QueryBase(_Base):
    """ Base functionality for Insert, Delete and Update Queries """
    
    def __init__(self, table):
        """ Construct an Insert query on 'table' """
        self.__table = table
        return
    table = property(lambda s: s.__table)

    __table_type = 'normal'
    def __set_table_type(self, value):
        if type(value) != types.StringType:
            raise TypeError("table_type MUST be a string.")
        if value not in ('normal','tagged'):
            raise TypeError("table_type can only be 'normal' or 'tagged'.")
        self.__table_type = value

    def __get_table_type(self):
        return self.__table_type

    table_type = property(__get_table_type,__set_table_type)
    

class Wheres(_Base):
    """ Build a Where query """

    def __init__(self, *a, **kw):
        """ Construct the Wheres """
        self._o = []
        self.__join_type = AND
        if a or kw:
            self.add(*a, **kw)
        return

    def __set_join(self, op):
        if op not in (AND,OR):
            raise TypeError("join type must be AND or OR.")
        self.__join_type = op
    join_type = property(lambda s: s.__join_type,__set_join)

    def add(self, *a, **kw):
        """
        Add one or more args to the wheres, be aware of the kw and non-kw
        restrictions. You can call this as many times as you want to build the
        Wheres.
        """
        for o in a:
            if not isinstance(o,(AND,OR)):
                raise TypeError("Non-keyword args MUST be a AND or OR Object.")
            o.parent = self
            self._o.append(o)
        for f,o in kw.items():
            if FieldBase not in o.__class__.mro() and not \
                isinstance(o,(NOT,NotFactory)):
                o = EQUAL(o)
            o.parent = self
            self._o.append((f,o))
        return

    def sql(self, op=None):
        """ Return the SQL string this object represents """
        if op:
            self.join_type = op
        return _Base.sql(self)


###########################################
##                                       ##
##  Connectivity Objects: AND, OR, Join  ##
##                                       ##
###########################################

class AND(Wheres):
    """ AND query of all components as k=v """
    def do(self):
        """ Returns a NamedMapping instance """
        self.traverse(' AND ',pre="(",post=")")
        return self.map


class OR(Wheres):
    """ OR query all of the components as k=v """
    def do(self):
        """ Returns a NamedMapping instance """
        self.traverse(' OR ',pre="(",post=")")
        return self.map


################################################
##                                            ##
##  Field operators, such as LIKE, NOT, EQUAL ##
##                                            ##
################################################
    
class FieldBase(_Base):
    """ Basis of FieldBases objects; LIKE, IN, LESS,.. """
    def __init__(self, value):
        self.value = value
        
    def __eq__(self, other):
        """ self.value is equal to other """
        return other == self.value

    def __ne__(self,other):
        """ self.value is not equal to other """
        return not self.__eq__(other)

    def do(self, field):
        """ Return a NamedMapping instance built for the Query """
        self.transformer(self,field=field)
        return self.map


class NOT(FieldBase):
    """
    Inverse connective SQL Object, such as:
    
      o user=NOT('simon') -> user != simon
    
      o status=NOT(LIKE('imon')) -> user NOT LIKE %imon%
    
      o status=NOT(IN('t','s','c')) -> user NOT IN (t,s,c)
    
    You can use this with just about any of the Request Objects. However, we
    don't take efforts to make sure your SQL object makes sence, so some common
    sence needs to be used when creating these. Thus, the following would make
    no sence and will fail:
    
      o Wheres(NOT(AND(user='simon',a=NOT(4)))
    
        -> WHERE (user = simon AND NOT a != 4)
    
    AGAIN, care should be taken when using this object.
    """
    __init__ = _Base.__init__
    
    def do(self, field=None):
        """ Returns a NamedMapping instance """
        if field:
            self.once((field,self._o))
        else:
            self.once(self._o)
        return self.map

    def __eq__(self, other):
        return self._o == other


class EQUAL(FieldBase):
    """ Create a Equality structure, takes a single value """


class LIKE(FieldBase):
    """ Create a LIKE structure, takes a single string """
    def __init__(self, value):
        if type(value) != types.StringType:
            raise TypeError('LIKE can only operate on strings.')
        self.value = value
        
    def __eq__(self, other):
        """ Other must be a string, if self.value is in other, then True """
        if type(other) != types.StringType:
            return False
        elif other.find(self.value) > -1:
            return True
        else:
            return False
        

class IN(FieldBase):
    """ Create an IN list Query """
    def __init__(self, *values):
        """ List of values can actually be anything """
        if not values or len(values) < 2:
            raise TypeError("IN requires 2 or more values.")
        self.values = values

    def __contains__(self, other):
        """ Is other in our list of values """
        return other in self.values
    
    def __eq__(self, other):
        """ Is the object "other" in our list of values """
        return other in self.values


class LESS(FieldBase):
    """
    Keyword object where the keyword/field should be less than this value, also
    note that number=NOT(LESS(5)) means number >= 5.
    """
    def __eq__(self, other):
        """ True iff the value of other is less than me """
        return other < self.value


class GREATER(FieldBase):
    """
    Keyword object where the keyword/field should be greater than this value,
    also note that number=NOT(GREATER(5)) means number <= 5.
    """
    def __eq__(self, other):
        """ True iff the value of other is greater than me """
        return other > self.value


class BETWEEN(FieldBase):
    """ Create an SQL object where the field is between 2 values """
    def __init__(self, v1, v2):
        """ Takes 2 values that the field is between """
        self.v1 = v1
        self.v2 = v2
        
    def __eq__(self, other):
        """ Equal iff x1 <= other < x2 """
        return other >= self.v1 and other < self.v2
            
    def __ne__(self,other):
        """ If other is not between x1 and x2 """
        return not self.__eq__(other)

##################################
##                              ##
##  Top level Query objects     ##
##                              ##
##################################
    
class Insert(_QueryBase):
    """An insert query adds rows to a table """
    type = 'insert'
    delayed = False

    def __init__(self, table):
        """ Insert(<tablename>) => object """
        self.__d = []
        self.__f = []
        _QueryBase.__init__(self,table)

    data   = property(lambda s: s.__d)
    fields = property(lambda s: s.__f)

    def __repr__(self):
        return "<InsertQuery on '%s' with %d rows currently.>" % (
            self.table,
            len(self.__d),
        )
    
    def __len__(self):
        return len(self.__d)
    
    def clear(self):
        """
        Q.clear() -> None

        Removes all the data values that are in this Query. Usefull if you want
        to use the same query object a second time to add more data.
        """
        self.__d = []

    def setRows(self, data):
        """ set the rows for the insert, should be a list of strings """
        if self.__d:
            raise ValueError("Cannot set rows after data allocation.")
        if type(data) not in (types.ListType,types.TupleType):
            raise TypeError("data should be a list or tuple.")
        self.__f = []
        for k in data:
            if type(k) != str:
                raise TypeError("All row names MUST be strings.")
        self.__f = data
        return

    def __add__(self, data):
        """ Add a row of data, should be a list/tuple of values """
        if type(data) not in (types.ListType,types.TupleType):
            raise TypeError("data should be a list or tuple.")
        if len(data) != len(self.__f):
            raise ValueError("data does not appear to cover all rows.")
        self.__d.append(data)
        return self


class Delete(_QueryBase):
    """ Build a Delete Query """
    type = 'delete'

    def __init__(self, table):
        """ Construct a Delete query, 'table' name of table """
        _QueryBase.__init__(self,table)
        self.wheres = Wheres()
        self.wheres.parent = self

    def __repr__(self):
        return "<DeleteQuery on '%s'.>" % self.table


class Select(_QueryBase):
    """ Build a Select Query """
    type = 'select'
    join = None

    def __init__(self, table, *a):
        """ Construct a Select query, 'table' name of table and *a is fields """
        _QueryBase.__init__(self,table)
        self.wheres = Wheres()
        self.wheres.parent = self
        self.selects = a

    __selects = None
    def __set_selects(self, a):
        if type(a) == types.StringType:
            self.__selects = (a,)
        elif type(a) in (types.TupleType,types.ListType):
            if [ v for v in a if type(v) != types.StringType ]:
                raise TypeError("selects must be a list/tuple of strings.")
            self.__selects = tuple(a)
        else:
            raise TypeError("selects must be a list or tuple")
    selects = property(lambda s:s.__selects,__set_selects)

    def asDelete(self):
        """
        An ease of use method to return a Delete query for what was presumably
        just fetched using a Select query.
        """
        q = Delete(self.table)
        q.wheres = self.wheres
        q.wheres.parent = q
        return q

    __limit = None
    def __set_limit(self, limit):
        if not limit:
            self.__limit = None
        elif type(limit) != types.TupleType:
            raise TypeError("limit must be a tuple (x,y)")
        elif len(limit) != 2 and [v for v in limit if type(v) == types.IntType]:
            raise ValueError("limit must be tuple of 2, eg. (0,500).")
        self.__limit = limit
    limit = property(lambda s:s.__limit,__set_limit)

    __orderby = None
    def __set_orderby(self, o):
        if type(o) not in (types.TupleType,types.ListType):
            raise TypeError("orderby should be a list or tuple of strings.")
        if [ v for v in o if type(v) != types.StringType ]:
            raise TypeError("orderby should be a list or tuple of strings.")
        self.__orderby = o
    orderby = property(lambda s:s.__orderby,__set_orderby)

    __groupby = None
    def __set_groupby(self, o):
        if type(o) not in (types.TupleType,types.ListType):
            raise TypeError("groupby should be a list or tuple of strings.")
        if [ v for v in o if type(v) != types.StringType ]:
            raise TypeError("groupby should be a list or tuple of strings.")
        self.__groupby = o
    groupby = property(lambda s:s.__groupby,__set_groupby)


class Update(_QueryBase):
    """ An UPDATE query modifies rows in a table to new values """
    type = "update"

    def __init__(self, table, **kw):
        """ 
        Create an Update query on table setting the field=value as the keyword
        args to this constructor.
        
            qry = Update(<tablename>,<field>=<value>, ... ) => qry_object
            
        You can call set(<field>=<value>,...) then to add, override values.
        """
        _QueryBase.__init__(self,table)
        self.wheres = Wheres()
        self.wheres.parent = self
        self._d = kw.items()
        self._d.sort()

    def fields(self):
        """ Returns the fields being updated by this query """
        return [ x[0] for x in self._d ]

    def values(self):
        """ Return the data """
        return [ x[1] for x in self._d ]

    def items(self):
        """ Returns a list of (field,value) tuples """
        return self._d

    def set(self, **kw):
        """ Set field=value, this is an accumulative method """
        self._d.update(kw)


class TransformerFactory:
    """
    This is a Static class Mapper that provides methods for transforming from
    the Query Type objects to update the _map object and produce a backend
    compliant statement. I'm using this instead of a dictionary by type just
    because I can and it seems nicer to subclass and override for each backend
    than updating a dictionary.
    """
    
    def factory(self, *a, **kw):
        """
        The entry method that selects the correct transformer method on this
        class for the object being transformed and then calls it.
        """
        name = self.__class__.__name__
        if hasattr(self.root,'table_type'):
            name = "%s%s" % (self.root.table_type.capitalize(),name)
        return getattr(TransformerFactory,name)(self,*a,**kw)
    factory = staticmethod(factory)

    def NormalInsert(self):
        """ Prepare a normal Insert query """
        if not self.data:
            return
        values = "%s,"*len(self.fields)
        self.map.append("INSERT %sINTO %s (%s)" % 
            (self.delayed and "DELAYED " or "",self.table,','.join(self.fields))
        )
        self.map.append(" VALUES (%s)" % values[:-1], *self.data)
        return
    NormalInsert = staticmethod(NormalInsert)

    def TaggedInsert(self):
        raise NotImplementedError("This isn't implemented on this Transformer.")
    TaggedInsert = staticmethod(TaggedInsert)
        
    def NormalUpdate(self):
        """ Update _map on self with a standard SQL syntax """
        fields,values = [],[]
        for k,v in self.items():
            fields.append('%s=%%s' % k)
            values.append(v) 
        if fields:
            self.map.append("UPDATE %s SET " % self.table)
            self.map.append(','.join(fields),*values)
            self.wheres.do()
        return
    NormalUpdate = staticmethod(NormalUpdate)
    
    def TaggedUpdate(self):
        raise NotImplementedError("This is not implemented as a Transformer.")
    TaggedUpdate = staticmethod(TaggedUpdate)

    def NormalDelete(self):
        """ Generate a standard SQL delete query """
        self.map.append("DELETE FROM %s" % self.table)
        self.wheres.do()
        return
    NormalDelete = TaggedDelete = staticmethod(NormalDelete)

    def NormalSelect(self):
        """ Generate a standard SQL for selects """
        fields = self.selects or ['*',]
        if self.join is not None:
            fields = [ "%s.%s" % (self.table,f) for f in fields ]
        self.map.append("SELECT %s" % ','.join(fields))
        self.map.append(" FROM %s" % self.table)
        # Is there a Join
        if self.join is not None:
            self.map = self.join.do(self.table,'t2')
        # Run the where here
        self.wheres.do()
        # Only group for normal tables
        if self.groupby:
            self.map.append(" GROUP BY %s" % ','.join(self.groupby))
        # Append an orderby command
        if self.orderby:
            self.map.append(" ORDER BY %s" % ','.join(self.orderby))
        # Check the limits
        if self.limit:
            self.map.append(" LIMIT %d,%d" % self.limit)
        return
    NormalSelect = staticmethod(NormalSelect)

    def TaggedSelect(self):
        """
        Tagged Selects require a Join, eg:

            SELECT username FROM users WHERE email = 'simon@domain'

        would become:

            SELECT t1.* FROM users as t1 JOIN users as t2
            ON t1.tagid = t2.tagid
            WHERE t1.attribute = 'email' AND t1.value = 'simon@domain'
            ORDER BY t1.id

        This is a bit nasty but it can be done using another Query object. The
        id field is always added so the ResultSet can properly combine the
        resulting rows in a proper result set for normal tables.
        """
        if self.join is not None:
            raise BadQuery("Tagged Selects cannot have Joins.")
        query = Select(self.table)
        query.join = Join(self.table,'tagid','tagid')
        query.orderby = ['id','attribute']
        query.wheres = self.wheres
        map = query.do()
        return
    TaggedSelect = staticmethod(TaggedSelect)

    def __Wheres(self):
        """ The business end of creating the Wheres """
        if len(self._o) > 1:
            self.map.append(' WHERE ')
            ob = self.join_type()
            for o in self._o:
                if isinstance(o,(AND,OR)):
                    ob.add(o)
                else:
                    ob.add(**dict([o]))
            ob.parent = self
            ob.do()
        elif self._o:
            self.traverse('',pre=" WHERE ")
        return
    Wheres = NormalWheres = TaggedWhere = staticmethod(__Wheres)

    def EQUAL(self, field):
        """ Equality transformation mapping, eg. user = 'simon' """
        if self.parent and self.parent.__class__ is NOT:
            self.map.append("%s != %%s" % field, self.value)
        else:
            self.map.append("%s = %%s" % field, self.value)
        return
    EQUAL = NormalEQUAL = TaggedEQUAL = staticmethod(EQUAL)

    def LESS(self, field):
        """ Less Than tranformation operator """
        if self.parent and self.parent.__class__ is NOT:
            self.map.append("%s >= %%s" % field, self.value)
        else:
            self.map.append("%s < %%s" % field, self.value)
        return
    LESS = NormalLESS = TaggedLESS = staticmethod(LESS)

    def GREATER(self, field):
        """ Less Than tranformation operator """
        if self.parent and self.parent.__class__ is NOT:
            self.map.append("%s <= %%s" % field, self.value)
        else:
            self.map.append("%s > %%s" % field, self.value)
        return
    GREATER = NormalGREATER = TaggedGREATER = staticmethod(GREATER)

    def LIKE(self, field):
        """ LIKE transformation operator, eg. user LIKE 'simon' """
        inv = ''
        if self.parent and self.parent.__class__ is NOT:
            inv = 'NOT '
        self.map.append("%s %sLIKE %%s" % (field,inv), '%'+self.value+'%')
        return
    LIKE = NormalLIKE = TaggedLIKE = staticmethod(LIKE)
        
    def BETWEEN(self, field):
        """ Prepare a x <= y < z expression """
        if self.parent and self.parent.__class__ is NOT:
            part = "(%s < %%s OR %s >= %%s)" % (field,field)
        else:
            part = "(%s >= %%s AND %s < %%s)" % (field,field)
        self.map.append(part,self.v1,self.v2)
        return
    BETWEEN = NormalBETWEEN = TaggedBETWEEN = staticmethod(BETWEEN)

    def IN(self, field):
        """ Prepare a x in [] type expression """
        values = ",".join([ "%s" for v in self.values ])
        inv = ''
        if self.parent and self.parent.__class__ is NOT:
            inv = 'NOT '
        self.map.append("%s %sIN (%s)" % (field,inv,values), *self.values)
        return
    IN = NormalIN = TaggedIN = staticmethod(IN)
    

class NotFactory:
    def __init__(self, op):
        self.__op = op
    def __call__(self, *a):
        return NOT(self.__op(*a))


conditions = {
    # Field types
    '='          : EQUAL,
    '>'          : GREATER,
    '<'          : LESS,
    '!='         : NotFactory(EQUAL),
    '>='         : NotFactory(LESS),
    '<='         : NotFactory(GREATER),
    'LIKE'       : LIKE,
    'NOT LIKE'   : NotFactory(LIKE),
    'IN'         : IN,
    'NOT IN'     : NotFactory(IN),
    'BETWEEN'    : BETWEEN,
    'NOT BETWEEN': NotFactory(BETWEEN),
    # Joiner types
    'AND'        : AND,
    'OR'         : OR,
}


def ConvertWheres(wheres):
    qry = Wheres()
    qry.join_type = conditions[wheres[0]]
    for item in wheres[1:]:
        joinType = item[0]
        ss = {}
        for set in item[1:]:
            if set[0] not in conditions:
                raise KeyError("Failed to convert Wheres: %s" % set[0])
            ss[set[1]] = conditions[set[0]](*set[2:])
        qry.add(conditions[joinType](**ss))
    return qry


Queries = (Insert,Update,Delete,Select)
WheresQueries = (AND,OR,NOT,LIKE,EQUAL,BETWEEN,IN,GREATER,LESS)

__all__ = [
    'ConvertWheres',
    'conditions',
    'TransformerFactory',
    'Queries','WheresQueries',
    'Insert','Delete','Update','Select','Queries',
    'Wheres',
    'AND','OR',
    'NOT',
    'LIKE','EQUAL','BETWEEN','IN','GREATER','LESS',
]


if __name__ == "__main__":
    from code import interact
    interact(
        banner="Build a query using Insert, Select, Delete or Update.",
        local=globals().copy(),
    )
