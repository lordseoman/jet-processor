"""
This module contains a DB style interface to the Berkeley BSD system.
    
A pyTools dbPool connector is a base connector to BSD style backends, they do
not contain any database specific information.
    
It will look a lot like the bsddb/bsdtable.py module but rewritten for 
integration into the pyTools.dbPool system. The other main difference is that
there will be one table per file and the indexes are stored in a separate file
such as <table>_index_<key>.db in the database home directory. 

Using this module individually can be achieved as such:
    
    from pyTools.dbPool.bsddb import Connector
    
    con = Connector('/tmp/bsdTest','testDatabase')
    con.listTables()
    con.select('*','table1')

$Id: bsd.py,v 1.2 2005/02/02 05:09:14 seoman Exp $
"""
__revision__ = "$Revision: 1.2 $"[11:-2]

from bsddb.db import *
import cPickle as pickle
import os,sys,types,re

from db_pool import DbPoolError,QueryType
from Handler import ContainerBase
from pyTools import utils


CONTAINER_TYPE = 'bsdDB Container'


class Connector:
    """ 
    A BSD style Connector, a Connector connects to a specific database and does
    checks and db global tasks; such as creating Cursors, syncing the Tables,
    creating/listing/dropping tables, managing indexes and performing queries.
    """
    mode = 0600
    _reIllegalMatch = re.compile(r'(\s|\.|,|:|;)+',re.M)

    _tablenames = '__TABLE_NAMES__'
    _columnkeys = '._TABLE_INFO_'
    _indexkeys  = '._TABLE_INDEX_.'
    
    env = metadata = None
    errors = (DBNotFoundError,DbPoolError,DBError)

    def __init__(self, base, database, readonly=False):
        """ Construct the connector """
        self._basedir = base
        self._database = database
        self._env_directory = os.path.normpath(os.path.join(base,database))
        self._readonly = readonly
        
        # Check the base and database, creating them if they don't exist.
        if not os.path.exists(base):
            os.makedirs(base,0755)
        elif not os.path.isdir(base):
            raise DbPoolError("Base must a directory for all databases.")
        if not os.path.exists(self._env_directory):
            os.mkdir(self._env_directory,0755)
        elif not os.path.isdir(self._env_directory):
            raise DbPoolError("Database is must be a directory in _base_")

        # Setup flags for the environment
        self.__tables = {}
        self.flags = DB_THREAD|DB_CREATE
        self.env_flags = (DB_INIT_MPOOL|DB_INIT_LOCK|DB_INIT_LOG|DB_INIT_TXN)
    
    def __del__(self):
        """ On deletion close """
        self.close()
            
    def connect(self):
        """ Opens the environment and initialises the database """
        self.env = DBEnv()
        self.env.set_lk_detect(DB_LOCK_DEFAULT)
        self.env.open(self._env_directory, self.flags | self.env_flags)
        self.initialise()
        
    def initialise(self):
        """
        Initialise a new database, we create a metadata.db file that has info
        on the tables and all indexes for the tables in this database. Here we
        will open the metadata file and load in all tables.
        """
        self.metadata = DB(self.env)
        self.metadata.set_get_returns_none(1)
        fname = os.path.join(self._env_directory,'metadata.db')
        self.metadata.open(fname,DB_BTREE,DB_AUTO_COMMIT|self.flags,self.mode)
        txn = self.env.txn_begin()
        try:
            if not self.metadata.has_key(self._tablenames, txn):
                self.metadata.put(self._tablenames,pickle.dumps([],1),txn=txn)
        except:
            # This is evil and should be made nicer by handling errors properly
            txn.abort()
            raise
        else:
            txn.commit()
        return
        
    def getTableInfo(self, table):
        """ Returns the table description for table as a list of tuples """
        return pickle.loads(self.metadata.get(self.__tableinfo(table)))
        
    def __tableinfo(self, table):
        """ Returns the key string for table column info """
        return self.__tablename(table) + self._columnkeys
        
    def __tablename(self, table):
        """ Returns a safe table name """
        if type(table) != types.StringType:
            raise TypeError("The table name must be a string.")
        if (table.find(self._tablenames) > -1 or 
            table.find(self._columnkeys) > -1 or
            table.find(self._indexkeys) > -1):
            raise ValueError("Table name contains illegal metastrings.")
        if self._reIllegalMatch.match(table):
            raise DbPoolError("Tablename contains illegal characters.")
        return table.lower()
        
    def __tablefile(self, table):
        """ Returns the filename for the table """
        return self.__tablename(table) + '_data.db'
        
    def getCursor(self, table):
        """
        Opens a connection to a specific table and returns a Cursor object for
        that table. Tables are cached internally, but should be manually sync'ed
        and closed by the application after use.
        """
        if table not in self.__tables:
            if table not in self.listTables():
                raise DbPoolError("Table doesn't exist, please create first.")
            t = DB(self.env)
            t.set_get_returns_none(1)
            t.set_flags(DB_DUP)
            tfile = self.__tablefile(table)
            t.open(tfile, DB_BTREE, DB_AUTO_COMMIT | self.flags, self.mode)
            self.__tables[table] = t
        return Cursor(self.env, self.__tables[table], self.getTableInfo(table))

    def close(self):
        """
        Close the database, environment and any open tables. Be sure to sync any
        tables you want to as closing is not guaranteed to sync tables.
        """
        for table in self.__tables.values():
            table.close()
        self.__tables = {}
        if self.metadata is not None:
            self.metadata.close()
        if self.env is not None:
            self.env.close()
        self.env = self.metadata = None
        
    def transactions(self):
        """ Returns information on any transactions in the environment """
        return self.env.txn_stat()
        
    def locks(self):
        """ Returns information on any locks in place """
        return self.env.lock_stat()
        
    def listTables(self):
        """ Returns a list of tables """
        pickledtablelist = self.metadata.get(self._tablenames)
        if pickledtablelist:
            return pickle.loads(pickledtablelist)
        else:
            return []

    def createTable(self, table, column_data):
        """ 
        Make a new table in this database with a name of table using the column
        information provided. We don't actually use that information here, it
        is used when inserting, deleting or updating information in the table.
        As with the other Connector types, it should be a list of tuples.
        """
        tablename = self.__tablename(table)
        txn = self.env.txn_begin()
        try:
            # Collect the list of tables, append the new one
            data = self.metadata.get(self._tablenames, txn=txn, flags=DB_RMW)
            tablelist = pickle.loads(data)
            if tablename in tablelist:
                raise DbPoolError("Table '%s' already exists."%table)
            tablelist.append(tablename)
            self.metadata.delete(self._tablenames, txn)
            self.metadata.put(self._tablenames,pickle.dumps(tablelist,1),txn=txn)
            # Add the table info
            tableinfokey = self.__tableinfo(table)
            if self.metadata.has_key(tableinfokey,txn):
                raise DbPoolError("Table '%s' already exists."%table)
            self.metadata.put(tableinfokey,pickle.dumps(column_data,1),txn=txn)
        except (DBError,DbPoolError):
            txn.abort()
            raise
        else:
            txn.commit()
        return
        
    def dropTable(self, table):
        """ Drops a table, removing all data and indexes """
        txn = self.env.txn_begin()
        pickledtl = self.metadata.get(self._tablenames,txn=txn,flags=DB_RMW)
        tablelist = pickle.loads(pickledtl)
        try:
            # Remove the table from tablenames
            try:
                tablelist.remove(self.__tablename(table))
            except ValueError:
                pass
            else:
                self.metadata.delete(self._tablenames, txn)
                data = pickle.dumps(tablelist,1)
                self.metadata.put(self._tablenames,data,txn=txn)
            # Remove the column info
            self.metadata.delete(self.__tableinfo(table),txn)
            # Remove any indexes for this table
        except DBError, detail:
            txn.abort()
            raise
        else:
            txn.commit()
            # Close the table if its open
            if table in self.__tables:
                self.__tables[table].close()
                del self.__tables[table]
            # Attempt to let a db remove the database file for us
            t = DB(self.env)
            t.remove(self.__tablefile(table))
        return

    def sync(self):
        """ Try and syncronise the database """
        try:
            self.metadata.sync()
        except DBIncompleteError,detail:
            self.log_exeception("Error synchronising database.")
        
        
class Cursor:
    """ 
    A BSD style Cursor, a Cursor is a connection to a specific table in the 
    database and should be used as a request object. This means it handles 
    transactions and can be thrown away at the conclusion of the request.
    """
    def __init__(self, env, table, tableinfo):
        """ Initiate the Cursor """
        self.env = env
        self.table = table
        self.tableinfo = tableinfo
        self.txn = None
    
    def __del__(self):
        """ Ensure that any open transaction is aborted when deleting """
        self.abort()
    
    def __len__(self):
        """ Returns the number of records in the table """
        stat = self.stats()
        records = 0
        if stat['nkeys']:
            # there should be cols * records k/v pairs total
            records = stat['nkeys'] / len(self.tableinfo)
            if type(records) == type.FloatType:
                raise DbPoolError("Error, should be multiple of cols kv pairs.")
        return records
        
    def stats(self):
        """ Returns stats on this table """
        return self.table.stat()
    
    def begin(self):
        """ Start a transaction """
        self.txn = self.env.txn_begin()
        
    def commit(self):
        """ Commit the current transaction """
        if self.txn:
            self.txn.commit()

    def savepoint(self, mins=0):
        """ Set a transaction checkpoint """
        try:
            self.env.txn_checkpoint(mins)
        except DBIncompleteError:
            self.log_exeception("Error creating a transaction checkpoint.")
    
    def rollback(self):
        """ Abort the current transaction, does a rollback """
        if self.txn:
            self.txn.abort()


class Container(ContainerBase):
    """
    This is a container class, it converts standard dbPool API into usage for
    a BSD database style backend. We store tables as separate files named 
    <table>_data.db where table is the name of the table. Tables are created 
    as a RECIO type datastore that autoincrements a record number, One or more
    BTree indexes are used to access the table via an association with the
    primary data.
    """
    meta_type = CONTAINER_TYPE
    type = 'bsddb'
    
    def __init__(self,identifier):
        """ 
        Constructor should setup the container in a default state without 
        setting any parameters for a specific database/connector.
        """
        self.db = None
        self.env = DBEnv()
        self.env.set_lk_detect(DB_LOCK_DEFAULT)
        self.flags = DB_THREAD|DB_CREATE
        self.env_flags = (DB_INIT_MPOOL|DB_INIT_LOCK|DB_INIT_LOG|DB_INIT_TXN)
        return

    def hasConnector(self, database):
        """ Is there a connector to this database """
        for _id,c in self.connectors.items():
            if database == c.database:
                return True
        return False

    def getConnectorId(self, database):
        """ Returns a connector to the provided database """
        for _id,c in self.connectors.items():
            if database == c._database:
                return _id
        raise DbPoolError("No such connector exists for '%s'"%database)
    
    def getCursor(self, connectorId):
        """ Returns the cursor for a connector in the container pool """
        return self.getConnector(connectorId).getCursor()
        
    def getConnector(self, connectorId):
        """ Returns a connector for a given connector Id """
        try:
            return self.connectors[connectorId]
        except KeyError:
            raise DbPoolError("getCursor called with unknown connector.")
        
    def addConnector(self,datdir,database,readonly=False,debuglog=None):
        """ Create a connector for this container in the pool """
        try:
            _id = self.getConnectorId(database)
        except DbPoolError:
            self.connectors[_id] = _Connector(base,database,readonly,debuglog)
        return _id

    def _connect(self, connectorId):
        """ Called to actually connect one of the connector pools """
        return self.getConnector(connectorId).connect()
        
    def getQueryType(self, query):
        """ Called to determine whether the request is a read or write """
        return
        
    def insert_id(self, container):
        """ Returns the last record Id inserted into the container """
        return
        
    def escapeAndQuote(self,data):
        """ Make sure both data and keys are sane """
        return
        
    def _buildInsert(self, data, table, delayed=0):
        """ Override this function """
        pass
        
    def _buildDelete(self,table,wheres):
        """ Override this function """
        pass
        
    def _buildUpdate(self,updates,table,wheres=None):
        """ Override this function """
        pass
        
    def _buildSelect(self,selects=["*"],wheres=None,froms=None,orderBy=None,
                     groupBy=None,limit=None,tableType='normal'):
        """ Override this function """
        pass
        
    def run(self, cursor, query, params=None):
        """
        Internal method do actually run a query, used so the module can catch
        its own specific errors and report them without the base handler 
        having to know anything about them.
        """
        return
        
        