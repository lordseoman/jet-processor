"""
This module contains a DB style interface to the Berkeley BSD system.
    
It will look a lot like the bsddb/bsdtable.py module but rewritten for 
integration into the pyTools.dbPool system. The other main difference is that
there will be one table per file and the indexes are stored in a separate file
such as <table>_index_<key>.db in the database home directory. 

$Id: ContainerTemplate.py,v 1.1 2004/10/08 03:35:46 seoman Exp $
"""
__revision__ = "$Revision: 1.1 $"[11:-2]

from bsddb.db import *

from db_pool import DbPoolError,QueryType
from Handler import ContainerBase
from pyTools import utils


CONTAINER_TYPE = 'bsdDB Container'


class Container(ContainerBase):
    """
    This is a container class, it converts standard dbPool API into usage for
    a BSD database style backend.
    """
    meta_type = CONTAINER_TYPE
    type = 'bsddb'
    
    def __init__(self,identifier):
        """ 
        Constructor should setup the container in a default state without 
        setting any parameters for a specific database/connector.
        """
        return

    def _connect(self,container):
        """ Called to actually connect one of the connector pools """
        return
        
    def getQueryType(self, query):
        """ Called to determine whether the request is a read or write """
        return
        
    def insert_id(self, container):
        """ Returns the last record Id inserted into the container """
        return
        
    def escapeAndQuote(self,data):
        """ Make sure both data and keys are sane """
        return
        
    def _buildInsert(self, data, table, delayed=0):
        """ Override this function """
        pass
        
    def _buildDelete(self,table,wheres):
        """ Override this function """
        pass
        
    def _buildUpdate(self,updates,table,wheres=None):
        """ Override this function """
        pass
        
    def _buildSelect(self,selects=["*"],wheres=None,froms=None,orderBy=None,
                     groupBy=None,limit=None,tableType='normal'):
        """ Override this function """
        pass
        
    def run(self, cursor, query, params=None):
        """
        Internal method do actually run a query, used so the module can catch
        its own specific errors and report them without the base handler 
        having to know anything about them.
        """
        return
        
    def listTables(self):
        """ Returns a list of tables """
        return
        