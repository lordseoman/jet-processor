"""
This module contains the test for testing the common Storage and Container
handler methods and functionality. If a container class does anything 
special then this should be tested separately.

$Id: test_storagehandler.py,v 1.7 2005/05/30 09:15:36 seoman Exp $
"""
__revision__ = "$Revision: 1.7 $"[11:-2]

from pyTools.TestCases import TestCase
from pyTools.Testing import testRunner

from pyTools.dbPool.db_pool import StorageHandler
from pyTools import HardError,SoftError


class TC_StorageHandler(TestCase):
    """ Testing the Storage and Container Handlers """
    __StopOnError__ = True
    
    def test_Singleton_01(self):
        """ Is StorageHandler a Singleton """
        sh1 = StorageHandler()
        sh2 = StorageHandler()
        self.assert_(sh1 is sh2,"Not the same object 1.")

    def test_AddContainer_02(self):
        """ Adding/editing Containers """
        handler = StorageHandler()
        handler.addContainer(
            'mysql',
            'raven.obsidian.com.au',
            username='testSuite',
            password='hg873hS',
            database='testSuite',
            identifier="default",
        )
        self.assertEquals(handler.run().identifier,'default',"Handler doesn't have idx.")
        self.assertEqual(
            len(handler),1,
            "Too many handlers: %d" % len(handler)
        )
        self.assertEqual(
            len(handler.handlers),1,
            "Too many handlers: %d" % len(handler.handlers)
        )
        # if i add a container without identifier and dbname 'default' it should fail
        self.failUnlessRaises(
            HardError,
            handler.addContainer,
            'mysql',
            'raven.obsidian.com.au',
            username='testSuite',
            password='hg873hS',
            database='default',
        )
        self.assertEqual(
            len(handler),1,
            "Too many handlers: %d" % len(handler)
        )
        self.assert_('default' in handler,"__contains__ not working on Handler.")
        d = handler.getDefault().identifier
        self.assertEqual(
            d,
            'default',
            "Default handler should be default: %s" % d
        )
        # add another
        handler.addContainer(
            'mysql',
            'raven.obsidian.com.au',
            username='testSuite',
            password='hg873hS',
            database='testSuite',
            identifier="second",
        )
        self.assertEqual(
            len(handler),2,
            "Incorrect number of handlers: %d" % len(handler)
        )
        handler.setDefault('second')
        d = handler.getDefault().identifier
        self.assertEqual(
            d,
            'second',
            "Default handler should now be second: %s" % d
        )        


if __name__ == '__main__':
    testRunner(dependenciesOn=False)

