"""
Tests for the DataStore, Pool Handling and Containers.

$Id: __init__.py,v 1.4 2005/05/30 09:15:36 seoman Exp $
"""
__revision__ = "$Revision: 1.4 $"[11:-2]


import os
from glob import glob
from pyTools.Testing import testRunner

path = os.path.join(os.path.dirname(__file__),'test_*.py')
for mod in glob(path):
    modName = os.path.basename(mod)[:-3]
    try:
        __import__(modName)
    except ImportError,e:
        print "Error importing testcases from",modName,e


if __name__ == '__main__':
    testRunner(dependenciesOn=True)

