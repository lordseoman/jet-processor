"""
Test suite for MySQL DataStorage Container type

$Id: test_sqlite.py,v 1.4 2005/06/02 04:31:26 seoman Exp $
"""

from pyTools.TestCases import DbPoolTestCase
from pyTools.Testing import testRunner

from pyTools.dbPool.Query import *

from mx import DateTime

from utilities import TC_SQL


_table1 = """
CREATE TABLE %s (
  id   integer primary key,
  col1 integer not null,
  col2 text default '',
  col3 text default ''
)"""

_table2 = """
CREATE TABLE %s (
  id    integer primary key,
  name  text default '',
  state text default '',
  start datetime default null
)"""
                            

class TC_SQLite(TC_SQL,DbPoolTestCase):
    """ Test the SQLite Container """

    identifier = "sqlite"
    containerType = "sqlite"
    username = password = hostname = None
    database = "/tmp/dbTestSuite.sqlite"

    tables = [ ('table1',_table1), ('table2',_table2) ]
    
    def test_Connector_00(self):
        """ Test we are using the right Connector """
        self.assertEqual(
            self.connector.type,"SQLite Connector",
            "Using incorrect Connector type for test: %s" % self.connector.type
        )

    def test_Converter_02(self):
        """ Testing Converters """
        converter = self.connection.converter
        self.assertEqual(
            "'fred'",converter("fred"),
            "String converting incorrect: %s" % converter("fred")
        )
        result = converter("f';drop table;'red")
        self.assertEqual(
            "'f'';drop table;''red'",result,
            "String converting incorrect: %s" % result
        )
        now = DateTime.now()
        result = converter(now)
        self.assertEqual(
            now.strftime("'%Y-%m-%d %H:%M:%S'"),result,
            "DateTime conversion incorrect: %s" % result
        )
        result = converter([4.5,"'gt;t4",])
        self.assertEqual(
            ('4.5',"'''gt;t4'"),result,
            "List conversion incorrect: %s" % str(result)
        )
     
    def test_Tables_04(self):
        """ Testing table functions """
        tables = self.connection.listTables()
        self.assert_('table1' in tables,"table1 doesn't exist.")
        q = Select('sqlite_master','tbl_name')
        q.wheres.add(type='table')
        results = self.cursor.execute(q)
        self.assertEqual(
            [ x[0] for x in results ],tables,
            "The result from show don't match listTables: %s" % results
        )
        self.assert_(
            self.connection.tableExists('table1'),
            "tableExists failed to find table1."
        )
        

if __name__ == '__main__':
    testRunner(dependenciesOn=False)

