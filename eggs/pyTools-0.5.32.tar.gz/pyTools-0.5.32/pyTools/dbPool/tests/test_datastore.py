"""
This Test module contains the tests for ensuring the DataStore object
functions as expected.

$Id: test_datastore.py,v 1.6 2005/06/02 06:48:28 seoman Exp $
"""
__revision__ = "$Revision: 1.6 $"[11:-2]


from pyTools.TestCases import DbPoolTestCase
from pyTools.Testing import testRunner

from pyTools.dbPool import *

import cPickle
from mx import DateTime


_table1 = """
CREATE TABLE %s (
  id int(11) unsigned auto_increment,
  name varchar(64) NOT NULL,
  state varchar(32) NOT NULL default '',
  start datetime default NULL,
  PRIMARY KEY id (id)
) TYPE=MyISAM;"""


def now():
    d = DateTime.now()
    return d - DateTime.RelativeDateTime(seconds=d.second % 1)


class MyDataStore(DataStore):
    """ SubClass the DataStore object """
    pass
    

class TC_DataStore(DbPoolTestCase):
    """ Test the DataStore Object """
    dependencies    = ('TC_StorageHandler','TC_MySQL','TC_Query')
    __StopOnError__ = True

    identifier = "mysql"
    containerType = "mysql"
    username = "testsuite"
    password = "hg873hS"
    hostname = "127.0.0.1"
    database = "testSuite"

    tables = [ ('table1',_table1), ]

    def _checkSetup(self, table):
        tables = self.connection.listTables()
        self.assert_(table in tables,"%s doesn't exist."%table)
        results = self.cursor.execute(Select(table))
        self.assertEquals(
            len(results),5,
            "There should be 5 records in '%s': %s." % (table,results)
        )

    data = [
        ('simon', 'pending',  now()),
        ('dave',  'active',   now()),
        ('kevin', 'cancelled',now()),
        ('fred',  'suspended',now()),
        ('jessie','dead',     now()),
    ]

    fields = ('name','state','start')

    def setUp(self):
        DbPoolTestCase.setUp(self)
        q = Insert('table1')
        q.setRows(self.fields)
        for x in self.data:
            q += x
        self.cursor.execute(q)

    def test_DataCollection_01(self):
        """ Testing Collection of DataStore Object """
        self._checkSetup('table1')
        results = self.cursor.execute(Select('table1'))
        results.iterator = DataStore
        self.assertEqual(
            type(results[0]),
            DataStoreType,
            "Result is not a DataStore Object: %s" % type(results[0])
        )
        self.assertEqual(
            len(results),5,
            "There should be 5 results: %s" % len(results)
        )
        self.assert_(results[0]._DataStore__isSetup,"result isn't setup properly.")
        for x,d in enumerate(self.data):
            for i,v in enumerate(d):
                n = self.fields[i]
                self.assertEqual(
                    results[x][n],v,
                    "'%s' on Id %d is not %s: %s" % (n,results[x]['id'],v,results[x][n])
                )            

    def test_DataSetting_02(self):
        """ Testing the setting of DataStore attributes """
        self._checkSetup('table1')
        results = self.cursor.execute(Select('table1'))
        results.iterator = DataStore
        c2 = results[1]
        self.assertEqual(
            c2['id'],2,
            "Second child should be id 2: %d" % c2['id']
        )
        c2['state'] = 'non-functional'
        self.assertEqual(
            c2['state'],'non-functional',
            "Child not set correctly: %s" % c2['state']
        )
        # get it directly from backend and check state
        q = Select('table1','state')
        q.wheres.add(id=2)
        r = self.cursor.execute(q)
        self.assertEqual(len(r),1,"Should only have 1 result: %d"%len(r))
        self.assertEqual(
            r[0][0],'non-functional',
            "Backend not showing 'state' update immediately: %s" % r[0][0]
        )
        # now set auto commit off and test
        c2.__AutoCommit__ = False
        c2['state'] = 'active'
        self.assertEqual(c2['state'],'active',"Set #1 failed: %s"%c2['state'])
        c2['name']  = 'Bernie'
        self.assertEqual(c2['name'],'Bernie',"Set #2 failed: %s"%c2['name'])
        q = Select('table1')
        q.wheres.add(id=2)
        r = self.cursor.execute(q)
        self.assertEqual(len(r),1,"Should only have 1 result: %d"%len(r))
        r.iterator = dict
        for i,v in enumerate(self.data[1]):
            n = self.fields[i]
            self.assertEqual(
                results[1][n],v,
                "'%s' has changed when it shouldn't: %s" % (n,results[1][n])
            )
        # update and check
        c2.__update__()
        q = Select('table1')
        q.wheres.add(id=2)
        r = self.cursor.execute(q)
        self.assertEqual(len(r),1,"Should only have 1 result: %d"%len(r))
        r.iterator = dict
        self.assertEqual(r[0]['state'],'active',"Fetch on 'state' failed: %s"%r[0]['state'])
        self.assertEqual(r[0]['name'],'Bernie',"Fetch on 'name' failed: %s"%r[0]['name'])
        # quickly make sure there are still only 5 entries in the table
        r = self.cursor.execute(Select('table1'))
        self.assertEqual(len(r),5,"There should still be 5 entries: %d"%len(r))

    def test_PickleUnpickle_03(self):
        """ Testing Pickle and Unpickle of DataStore """



if __name__ == '__main__':
    testRunner(dependenciesOn=False)
