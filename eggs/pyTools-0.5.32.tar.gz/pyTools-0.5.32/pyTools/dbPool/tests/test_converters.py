"""
Test cases for the converters

$Id: test_converters.py,v 1.2 2005/05/30 09:15:36 seoman Exp $
"""

from pyTools.TestCases import pyTestCase
from pyTools.Testing import testRunner
from pyTools.dbPool.converters import Converter


class TC_Converters(pyTestCase):
    """ Test basic conversion routines """

    def test_Connector_00(self):
        self.assert_(True)


if __name__ == '__main__':
    testRunner(dependenciesOn=False)

