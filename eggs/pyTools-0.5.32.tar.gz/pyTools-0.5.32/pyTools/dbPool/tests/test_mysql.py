"""
Test suite for MySQL DataStorage Container type

$Id: test_mysql.py,v 1.7 2005/10/05 13:34:11 seoman Exp $
"""

from pyTools.TestCases import DbPoolTestCase
from pyTools.Testing import testRunner

from pyTools.dbPool.Query import *

from utilities import TC_SQL
from mx import DateTime


_table1 = """
CREATE TABLE %s (
  id int(11) unsigned auto_increment,
  col1 int(11) default NULL,
  col2 varchar(32) NOT NULL default '',
  col3 varchar(32) NOT NULL default '',
  PRIMARY KEY id (id)
) TYPE=INNODB;"""

_table2 = """
CREATE TABLE %s (
  id int(11) unsigned auto_increment,
  name varchar(64) NOT NULL,
  state varchar(32) NOT NULL default '',
  start datetime default '0123:01:02 12:34:56' not null,
  PRIMARY KEY id (id)
) TYPE=INNODB;"""


class TC_MySQL(TC_SQL, DbPoolTestCase):
    """ Test the MySQL Container """

    identifier = "mysql"
    containerType = "mysql"
    username = "testsuite"
    password = "hg873hS"
    hostname = "172.16.4.150"
    database = "testSuite"

    tables = [ ('table1',_table1), ('table2',_table2) ]

    def test_Connector_00(self):
        """ Test we are using the right Connector """
        self.assertEqual(
            self.connector.type,"MySQL Connector",
            "Using incorrect Connector type for test: %s" % self.connector.type
        )

    def test_Converter_02(self):
        """ Testing Converters """
        converter = self.connection.converter
        self.assertEqual(
            "'fred'",converter("fred"),
            "String converting incorrect: %s" % converter("fred")
        )
        result = converter("f';drop table;'red")
        self.assertEqual(
            "'f\\';drop table;\\'red'",result,
            "String converting incorrect: %s" % result
        )
        now = DateTime.now()
        result = converter(now)
        self.assertEqual(
            now.strftime("'%Y-%m-%d %H:%M:%S'"),result,
            "DateTime conversion incorrect: %s" % result
        )
        for x in (1, 50, 99, 100, 555, 999, 1000):
            now = DateTime.DateTimeFrom(x)
            result = converter(now)
            self.assertEqual(
                now.strftime("'%04Y-%m-%d %H:%M:%S'"), result,
                "DateTime conversion incorrect: %s" % result
            )
        now = DateTime.DateTimeFrom(0)
        result = converter(now)
        self.assertEqual(
            now.strftime("'%Y-%m-%d %H:%M:%S'"), result,
            "DateTime conversion incorrect: %s" % result
        )
        result = converter([4.5,"'gt;t4",])
        self.assertEqual(
            ('4.5',"'\\'gt;t4'"),result,
            "List conversion incorrect: %s" % str(result)
        )
    
    def test_Tables_04(self):
        """ Testing table functions """
        tables = self.connection.listTables()
        self.assert_('table1' in tables,"table1 doesn't exist.")
        results = self.cursor.runquery("show tables")
        self.assertEqual(
            [ x[0] for x in results ],tables,
            "The result from show don't match listTables: %s" % results
        )
        self.assert_(
            self.connection.tableExists('table1'),
            "tableExists failed to find table1."
        )


if __name__ == '__main__':
    testRunner(dependenciesOn=False)

