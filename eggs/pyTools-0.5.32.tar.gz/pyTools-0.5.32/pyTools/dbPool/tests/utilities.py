"""
Utilities and Bases for dbPool testcases

$Id: utilities.py,v 1.7 2005/10/05 13:34:11 seoman Exp $
"""

from mx import DateTime
from pyTools.dbPool.Query import *
import random,string


class TC_SQL:
    """ Test the SQLite Container """
    dependencies = ('TC_StorageHandler','TC_Query','TC_Converters')
    __StopOnError__ = True

    def _checkSetup(self, table):
        tables = self.connection.listTables()
        self.assert_(table in tables,"%s doesn't exist."%table)
        results = self.cursor.execute(Select(table))
        self.assert_(
            not results,
            "There is data in '%s': %s." % (table,results)
        )

    def test_Database_01(self):
        """ Test Cursor links """
        self.assert_(self.connector is not None,"Connector is None.")
        self.assert_(self.connection is not None,"Connection is None.")
        self.assert_(self.cursor is not None,"Cursor is None.")

    def test_Converter_02(self):
        """ Testing Converters """
        converter = self.connection.converter
        self.assertEqual(
            "'fred'",converter("fred"),
            "String converting incorrect: %s" % converter("fred")
        )
        result = converter("f';drop table;'red")
        self.assertEqual(
            "'f';drop table;'red'",result,
            "String converting incorrect: %s" % result
        )
        now = DateTime.now()
        result = converter(now)
        self.assertEqual(
            now.strftime("'%Y-%m-%d %H:%M:%S'"),result,
            "DateTime conversion incorrect: %s" % result
        )
        result = converter([4.5,"'gt;t4",])
        self.assertEqual(
            ('4.5',"''gt;t4'"),result,
            "List conversion incorrect: %s" % str(result)
        )
    
    def test_RoundRobin_03(self):
        """ Testing connection pooling """
        self.assert_(True)

    def test_Tables_04(self):
        """ Testing table functions """
        tables = self.connection.listTables()
        self.assert_('table1' in tables,"table1 doesn't exist.")
        self.assert_(
            self.connection.tableExists('table1'),
            "tableExists failed to find table1."
        )

    def test_Insertion_05(self):
        """ Testing the insertion of data """
        self._checkSetup('table1')
        # now add some data
        q = Insert('table1')
        q.setRows(('col1','col2','col3'))
        q += (55,'t2','t3')
        # check the SQL Query object
        self.assertEqual(
            q.sql(),
            "INSERT INTO table1 (col1,col2,col3) VALUES (55,'t2','t3')",
            "SQL #1 isn't correct: %s" % q.sql(),
        )
        m = q.do()
        self.assertEqual(
            m,[(55,'t2','t3'),],
            "Mapper has incorrect args: %s" % m,
        )
        self.assertEqual(
            m.qry_str,
            "INSERT INTO table1 (col1,col2,col3) VALUES (%s,%s,%s)",
            "Mapper string is incorrect: %s" % m.qry_str,
        )
        ar = self.cursor.execute(q)
        self.assertEqual(ar,1,"first insert expected to return 1: %s"%ar)
        idx = self.cursor.insert_id
        self.assertEqual(idx,1,"InsertId failed: %d"%idx)
        # now check that the record is correct
        results = self.cursor.execute(Select('table1'))
        self.assertEqual(len(results),1,"Too many results: %d"%len(results))
        self.assertEqual(
            results.getValue(0,'col1'),55,
            "Select #1 - col1 not 55: %s" % results.getValue(0,'col1')
        )
        self.assertEqual(
            results.getValue(0,'col2'),'t2',
            "Select #1 - col2 not t2: %s" % results.getValue(0,'col2')
        )
        self.assertEqual(
            results.getValue(0,'col3'),'t3',
            "Select #1 - col3 not t3: %s" % results.getValue(0,'col3')
        )
        # do another multi-insert
        q.clear()
        q += (49,'t20','t30')
        q += (16,'lev','too')
        rows = self.cursor.execute(q)
        self.assertEqual(rows,2,"Affected rows from multi-insert not 2: %d"%rows)
        idx = self.cursor.insert_id
        self.assertEqual(idx,3,"InsertId failed: %d"%idx)
        results = self.cursor.execute(Select('table1'))
        self.assertEqual(len(results),3,"Too many results: %d"%len(results))
    
    def generateSample(self, num):
        count = 0
        while count < num:
            yield (
                random.randint(0,9999),
                ''.join(random.sample(string.letters,10)),
                ''.join(random.sample(string.letters,27))
            )
            count += 1
        return
    
    def test_Transactions_06(self):
        """ Testing transactional support """
        if not self.connection.transactional:
            return
        self._checkSetup('table1')
        # add 10 records in a transaction
        q = Insert('table1')
        q.setRows(('col1','col2','col3'))
        self.cursor.begin()
        try:
            for d in self.generateSample(10):
                q.clear()
                q += d
                ar = self.cursor.execute(q)
                if ar != 1:
                    raise ValueError("not inserted 1 row: %d" % ar)
        except self.cursor.Errors+(ValueError,),e:
            self.cursor.rollback()
            self.fail(e)
        # check the 10 entries are in the table
        r = self.cursor.execute(Select('table1'))
        self.assertEqual(len(r),10,"Not 10 records in table: %s"%len(r))
        # check the table is empty to new connections, some connectors
        # can only have a single connection. So we can't check transactions
        # in this way properly.
        try:
            connection = self.connector.newConnection()
        except self.connector.Errors,e:
            connection = self.connection
        else:
            self.assert_(connection is not self.connection)
            r = connection.cursor.execute(Select('table1'))
            self.assertEqual(len(r),0,"Records in table: %s"%r)
        # commit and ensure that the records are available to new connection
        self.cursor.commit()
        r = connection.cursor.execute(Select('table1'))
        self.assertEqual(len(r),10,"Not 10 records in table: %s"%r)
        if connection is not self.connection:
            connection.close()
            del connection
        # now run the tests doing a rollback instead
        self.cursor.begin()
        try:
            for d in self.generateSample(10):
                q.clear()
                q += d
                ar = self.cursor.execute(q)
                if ar != 1:
                    raise ValueError("not inserted 1 row: %d" % ar)
        except self.cursor.Errors+(ValueError,),e:
            self.cursor.rollback()
            self.fail(e)
        # check the 10 entries are in the table
        r = self.cursor.execute(Select('table1'))
        self.assertEqual(len(r),20,"Not 20 records in table: %s"%len(r))
        # check the table is empty to new connections, some connectors
        # can only have a single connection. So we can't check transactions
        # in this way properly.
        try:
            connection = self.connector.newConnection()
        except self.connector.Errors,e:
            connection = self.connection
        else:
            self.assert_(connection is not self.connection)
            r = connection.cursor.execute(Select('table1'))
            self.assertEqual(len(r),10,"Not 10 records in table: %s"%len(r))
        # commit and ensure that the records are available to new connection
        self.cursor.rollback()
        r = connection.cursor.execute(Select('table1'))
        self.assertEqual(len(r),10,"Not 10 records in table: %s"%r)
    
    def test_Readonly_07(self):
        """ Testing readonly mode """
        self.assert_(True)

    def test_ContainerLocking_08(self):
        """ Testing Container locking during updates """
        self.assert_(True)
        
    def test_DataCollectionNormal_09(self):
        """ Testing data collection from normal tables """
        self.assert_(True)

    def test_DataCollectionTagged_10(self):
        """ Testing data collection from tagged tables """
        self.assert_(True)

    def test_Deletion_11(self):
        """ Testing the deletion of records """
        self._checkSetup('table1')
        q = Insert('table1')
        q.setRows(('col1','col2','col3'))
        q += (11,'t2','t3')
        q += (22,'simon','fred')
        q += (33,'dave','bort')
        ar = self.cursor.execute(q)
        self.assertEquals(ar,3,"Affected rows #1 incorrect: %d"%ar)
        idx = self.cursor.insert_id
        self.assertEqual(idx,3,"InsertId #1 failed: %d"%idx)
        # check total
        results = self.cursor.execute(Select('table1'))
        self.assertEquals(len(results),3,"Fetch failed: %s"%len(results))
        # add some more
        q.clear()
        q += (55,'home','bort')
        ar = self.cursor.execute(q)
        self.assertEquals(ar,1,"Affected rows #2 incorrect: %d"%ar)
        idx = self.cursor.insert_id
        self.assertEqual(idx,4,"InsertId #2 failed: %d"%idx)
        q.clear()
        q += (44,'jakie','fred')
        q += (66,'jgggg','ssss')
        ar = self.cursor.execute(q)
        self.assertEquals(ar,2,"Affected rows #3 incorrect: %d"%ar)
        idx = self.cursor.insert_id
        self.assertEqual(idx,6,"InsertId #3 failed: %d"%idx)
        # get the id from the record for the second entry
        results = self.cursor.execute(Select('table1'))
        self.assertEquals(len(results),6,"Fetch failed, not 6: %s"%len(results))
        id = results.getValue(1,'id')
        q = Delete('table1')
        q.wheres.add(id=id)
        num = self.cursor.execute(q)
        self.assertEquals(num,1,"Deleted records not 1: %d"%num)
        # make sure there are only 5 records
        results = self.cursor.execute(Select('table1'))
        self.assertEqual(
            len(results),5,
            "Checking records in table doesn't show 5: %s" % len(results)
        )
        # delete 2 :- 3 < id <= 5
        q = Delete('table1')
        q.wheres.add(id=GREATER(3))
        q.wheres.add(id=NOT(GREATER(5)))
        num = self.cursor.execute(q)
        self.assertEquals(num,2,"Deleted records not 2: %d"%num)
        # make sure there are only 3 records (1,3,6)
        results = self.cursor.execute(Select('table1'))
        self.assertEqual(
            len(results),3,
            "Checking records in table doesn't show 3: %s" % len(results)
        )
        self.assertEqual(
            [ x['id'] for x in results.__as_dict__() ],
            [1,3,6],
            "Unexpected records in table: %s" % results
        )

    def test_Drop_12(self):
        """ Testing the removal of tables/databases """
        self.assert_(True)

    def test_complex_13(self):
        """ Testing complex types """
        self._checkSetup('table2')
        q = Insert('table2')
        q.setRows(('name','state','start'))
        date = DateTime.DateTime(5)
        str1 = "p';ending"
        q += ('simon',str1,date)
        ar = self.cursor.execute(q)
        self.assertEqual(ar,1,"Should have only inserted 1: %d"%ar)
        id = self.cursor.insert_id
        # fetch the row back and check types
        results = self.cursor.execute(Select('table2'))
        self.assertEqual(len(results),1,"Fetch failed: %s"%len(results))
        self.assertEqual(
            type(results.getValue(0,'start')),
            DateTime.DateTimeType,
            "Date isn't returned as a DateTime object: %s" % type(results.getValue(0,'start'))
        )
        self.assertEqual(
            date.strftime("%Y-%m-%d %H:%M:%S"),
            results.getValue(0,'start').strftime("%Y-%m-%d %H:%M:%S"),
            "Date (%s) is incorrect: %s" % (date,results.getValue(0,'start'))
        )
        self.assertEqual(
            str1,
            results.getValue(0,'state'),
            "state isn't correct: %s" % results.getValue(0,'state')
        )

