"""
This Test module contains the tests for the BSD DB3 module Connector.

$Id: test_bsd.py,v 1.2 2005/05/30 09:15:36 seoman Exp $
"""
__revision__ = "$Revision: 1.2 $"[11:-2]


import os,sys

from pyTools.TestCases import DbPoolTestCase
from pyTools.Testing import testRunner
from utilities import TC_SQL


##class TC_BSD(TC_SQL,DbPoolTestCase):
##    """ Test the BSD DB backend """
##
##    identifier = "bsd"
##    containerType = "bsd"
##    hostname = username = password = None
##    database = "dbTestSuite.bsd"
##       
##    def test_Connector_00(self):
##        """ Test we are using the right Connector """
##        self.assertEqual(
##            self.connector.type,"Berkley BSD Connector",
##            "Using incorrect Connector type for test: %s" % self.connector.type
##        )
##

if __name__ == '__main__':
    testRunner(dependenciesOn=False)
