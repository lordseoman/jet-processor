"""
This Test module contains the tests for ensuring the Query objects function as
expected.

We should be able to pass in a Query object and then collect the SQL or Param
attributes and get an expected result. This object operation should not depend
on the backend being used since we can use a custom converter to ensure that
it all works properly.

$Id: test_query.py,v 1.7 2005/05/30 09:15:36 seoman Exp $
"""
__revision__ = "$Revision: 1.7 $"[11:-2]


from pyTools.TestCases import pyTestCase
from pyTools.Testing import testRunner

from pyTools.dbPool.Query import *


class TC_Query(pyTestCase):
    """ Test Query for Normal Tables """
    dependencies    = ('TC_StorageHandler',)
    __StopOnError__ = False
    
    def test_Select_01(self):
        """ Testing basic Select """
        q = Select('table1','a','b','c')
        self.assertEquals(q.table,'table1','Table is incorrectly set.')
        self.assertEquals(
            q.table_type,'normal',
            "The default table type should be normal."
        )
        self.assertEquals(q.orderby,None,"orderby is set when it shouldn't be.")
        self.assertEquals(q.limit,None,"limit should be None by default.")
        self.assertEquals(q.groupby,None,"groupby should be '' by default.")
        s = q.sql()
        self.assertEquals(
            s,
            "SELECT a,b,c FROM table1",
            "SQL returned is incorrect: %s" % s
        )

    def test_Equality_02(self):
        """ Testing Equality (=,>,<) """
        t = EQUAL(5)
        self.assert_(t == 5,"__eq__ test failed.")
        m = t.do('a')
        self.assertEquals(
            m,[5,],
            "EQUAL map is incorrect: %s" % m
        )
        s = t.sql('a')
        self.assertEquals(
            s,
            "a = 5",
            "SQL returned is not correct: %s" % s
        )
        t = GREATER(5)
        self.assert_(t == 6,"__gt__ test failed.")
        m = t.do('a')
        self.assertEquals(
            m,[5,],
            "EQUAL map is incorrect: %s" % m
        )
        s = t.sql('a')
        self.assertEquals(
            s,
            "a > 5",
            "SQL returned is not correct: %s" % s
        )
        t = LESS(5)
        self.assert_(t == 4,"__lt__ test failed.")
        m = t.do('a')
        self.assertEquals(
            m,[5,],
            "EQUAL map is incorrect: %s" % m
        )
        s = t.sql('a')
        self.assertEquals(
            s,
            "a < 5",
            "SQL returned is not correct: %s" % s
        )

    def test_NOT_03(self):
        """ Testing NOT operator """
        t = NOT(EQUAL(5))
        self.assert_(t != 4,"__ne__ test failed.")
        m = t.do('a')
        self.assertEquals(
            m,[5,],
            "EQUAL map is incorrect: %s" % m
        )
        s = t.sql('a')
        self.assertEquals(
            s,
            "a != 5",
            "SQL returned is not correct: %s" % s
        )
        t = NOT(GREATER(5))
        m = t.do('a')
        self.assertEquals(
            m,[5,],
            "EQUAL map is incorrect: %s" % m
        )
        s = t.sql('a')
        self.assertEquals(
            s,
            "a <= 5",
            "SQL returned is not correct: %s" % s
        )
        t = NOT(LESS(5))
        m = t.do('a')
        self.assertEquals(
            m,[5,],
            "EQUAL map is incorrect: %s" % m
        )
        s = t.sql('a')
        self.assertEquals(
            s,
            "a >= 5",
            "SQL returned is not correct: %s" % s
        )

    def test_ANDOR_04(self):
        """ Testing AND/OR """
        a = AND(a=EQUAL(3),b=EQUAL('simon'))
        self.assertEquals(a.do(),[3,'simon'],"AND map has incorrect values.")
        s = a.sql()
        self.assertEquals(
            s,
            "(a = 3 AND b = 'simon')",
            "SQL returned is not correct: %s" % s
        )
        o = OR(x=EQUAL('fred'),g=EQUAL(4.5))
        m = o.do()
        self.assertEquals(
            m,['fred',4.5],
            "OR map is incorrect: %s" % m
        )
        s = o.sql()
        self.assertEquals(
            s,
            "(x = 'fred' OR g = 4.5)",
            "SQL returned is not correct: %s" % s
        )
        x = AND(user='simon')
        x.add(OR(a=EQUAL(3),b=EQUAL(2.06)))
        x.add(d='no')
        m = x.do()
        self.assertEquals(
            m,['simon',3,2.06,'no'],
            "x Map is incorrect: %s" % m
        )
        s = x.sql()
        self.assertEquals(
            s,
            "(user = 'simon' AND (a = 3 OR b = 2.06) AND d = 'no')",
            "SQL returned is not correct: %s" % s
        )

    def test_Wheres_05(self):
        """ Testing basic Wheres """
        w = Wheres(a=1)
        w.add(b='simon')
        w.add(c=5.61)
        self.assertEquals(w.join_type,AND,"Default join should be AND.")
        s = w.sql()
        self.assertEquals(
            s,
            " WHERE (a = 1 AND b = 'simon' AND c = 5.61)",
            "SQL returned is incorrect: %s" % s
        )
        class e: pass
        try:
            w.join_type = e
        except TypeError,detail:
            pass
        else:
            self.fail("No error raised when setting invalid join type.")
        w.join_type = OR
        self.assertEquals(w.join_type,OR,"Failed to set join_type.")
        s = w.sql()
        self.assertEquals(
            s,
            " WHERE (a = 1 OR b = 'simon' OR c = 5.61)",
            "SQL returned is incorrect: %s" % s
        )

    def test_IN_06(self):
        """ Testing IN """
        w = Wheres(a=1)
        w.add(b=IN(2,4,6))
        m = w.do()
        self.assertEquals(
            m,[1,2,4,6],
            "x Map is incorrect: %s" % m
        )
        s = w.sql()
        self.assertEquals(
            s,
            " WHERE (a = 1 AND b IN (2,4,6))",
            "SQL returned is incorrect: %s" % s
        )
        w.add(d=NOT(IN('a','b')))
        w.start_processing = True
        m = w.do()
        self.assertEquals(
            m,[1,2,4,6,'a','b'],
            "x Map is incorrect: %s" % m
        )
        s = w.sql()
        self.assertEquals(
            s,
            " WHERE (a = 1 AND b IN (2,4,6) AND d NOT IN ('a','b'))",
            "SQL returned is incorrect: %s" % s
        )        

    def test_BETWEEN_07(self):
        """ Testing BETWEEN """
        w = Wheres(b=BETWEEN(2,4))
        w.join_type = OR
        m = w.do()
        self.assertEquals(
            m,[2,4],
            "x Map is incorrect: %s" % m
        )
        s = w.sql()
        self.assertEquals(
            s,
            " WHERE (b >= 2 AND b < 4)",
            "SQL returned is incorrect: %s" % s
        )
        w.add(d=NOT(BETWEEN('a','b')))
        w.start_processing = True
        m = w.do()
        self.assertEquals(
            m,[2,4,'a','b'],
            "x Map is incorrect: %s" % m
        )
        s = w.sql()
        self.assertEquals(
            s,
            " WHERE ((b >= 2 AND b < 4) OR (d < 'a' OR d >= 'b'))",
            "SQL returned is incorrect: %s" % s
        )

    def test_LIKE_08(self):
        """ Testing LIKE """
        w = Wheres(a=1)
        w.add(user=LIKE('imo'))
        m = w.do()
        self.assertEquals(
            m,[1,'%imo%'],
            "x Map is incorrect: %s" % m
        )
        s = w.sql()
        self.assertEquals(
            s,
            " WHERE (a = 1 AND user LIKE '%imo%')",
            "SQL returned is incorrect: %s" % s
        )
        w.add(d=NOT(LIKE('ttry')))
        w.start_processing = True
        m = w.do()
        self.assertEquals(
            m,[1,'%imo%','%ttry%'],
            "x Map is incorrect: %s" % m
        )
        s = w.sql()
        self.assertEquals(
            s,
            " WHERE (a = 1 AND user LIKE '%imo%' AND d NOT LIKE '%ttry%')",
            "SQL returned is incorrect: %s" % s
        )

    def test_Mapper_09(self):
        """ Testing mapper creation """
        q = Select('table1','a','b','c')
        self.assertEquals(q.table,'table1','Table is incorrectly set.')
        m1 = q.do()
        self.assertEquals(m1.qry_str,"SELECT a,b,c FROM table1","qry_str on mapper1 incorrect.")
        self.assertEquals(m1,[],"mapper values incorrect.")
        m2 = q.do()
        self.assertEquals(m2.qry_str,"SELECT a,b,c FROM table1","qry_str on mapper2 incorrect.")
        self.assertEquals(m2,[],"mapper values incorrect.")
        q.wheres.add(AND(a=1,b='4'))
        m1 = q.do()
        self.assertEquals(
            m1.qry_str,
            "SELECT a,b,c FROM table1 WHERE (a = %s AND b = %s)",
            "qry_str on mapper1 (take 2) incorrect: %s" % m1.qry_str
        )
        self.assertEquals(m1,[1,'4'],"mapper1 (take 2) values incorrect.")
        m2 = q.do()
        self.assertEquals(
            m2.qry_str,
            "SELECT a,b,c FROM table1 WHERE (a = %s AND b = %s)",
            "qry_str on mapper2 (take 2) incorrect: %s" % m2.qry_str
        )
        self.assertEquals(m2,[1,'4'],"mapper2 (take 2) values incorrect.")
 
    def test_Select_10(self):
        """ Testing a complex SELECT query """
        q = Select('t1')
        self.assertEquals(
            q.sql(),
            "SELECT * FROM t1",
            "Select #1 produces incorrect SQL: %s" % q.sql(),
        )
        q.orderby = ('a',)
        self.assertEquals(
            q.sql(),
            "SELECT * FROM t1 ORDER BY a",
            "Select #2 with OrderBy produced bad SQL: %s" % q.sql(),
        )
        q.groupby = ('b',)
        self.assertEquals(
            q.sql(),
            "SELECT * FROM t1 GROUP BY b ORDER BY a",
            "Select #3 with OrderBy produced bad SQL: %s" % q.sql(),
        )

    def test_Insert_11(self):
        """ Testing a complex INSERT query """
        q = Insert('t1')
        q.setRows(('a','b','c'))
        q += (1,2,3)
        m = q.do()
        self.assertEquals(
            m,[(1,2,3),],
            "Mapper is incorrect for Insert: %s" % m
        )
        self.assertEquals(
            m.qry_str,
            "INSERT INTO t1 (a,b,c) VALUES (%s,%s,%s)",
            "Insert Mapper string incorrect: %s" % m.qry_str
        )
        self.assertEquals(
            q.sql(),
            "INSERT INTO t1 (a,b,c) VALUES (1,2,3)",
            "Insert #1 produces incorrect SQL: %s" % q.sql(),
        )
        q += ('a',4.5,7001)
        self.assertEquals(
            q.sql(),
            "INSERT INTO t1 (a,b,c) VALUES (1,2,3),('a',4.5,7001)",
            "Insert #2 produces incorrect SQL: %s" % q.sql(),
        )
        q.clear()
        self.assertEquals(q.do(),[],"Clear failed on Insert.")
        q += ('a','45',45)
        self.assertEquals(
            q.sql(),
            "INSERT INTO t1 (a,b,c) VALUES ('a','45',45)",
            "Insert #3 produces incorrect SQL: %s" % q.sql(),
        )
        # test delayed insert query
        q.delayed = True
        self.assertEquals(
            q.sql(),
            "INSERT DELAYED INTO t1 (a,b,c) VALUES ('a','45',45)",
            "Insert #4 produces incorrect SQL: %s" % q.sql(),
        )
 
    def test_Update_12(self):
        """ Testing a complex UPDATE query """
        q = Update('t1',a=4,b=4.2,c='simon')
        self.assertEquals(
            q.sql(),
            "UPDATE t1 SET a=4,b=4.2,c='simon'",
            "Update #1 SQL is incorrect: %s" % q.sql(),
        )
        q.wheres.add(AND(a=2,c='Simon'))
        self.assertEquals(
            q.sql(),
            "UPDATE t1 SET a=4,b=4.2,c='simon' WHERE (a = 2 AND c = 'Simon')",
            "Update #2 SQL is incorrect: %s" % q.sql()
        )

    def test_Delete_13(self):
        """ Testing a complex DELETE query """
        q = Delete('t1')
        self.assertEquals(
            q.sql(),"DELETE FROM t1","Delete #1 SQL is incorrect: %s" % q.sql()
        )
        q.wheres.add(c='simon')
        self.assertEquals(
            q.sql(),
            "DELETE FROM t1 WHERE c = 'simon'",
            "Delete #2 SQL is incorrect: %s" % q.sql(),
        )


##class TC_TaggedTables(pyTestCase):
##    """ Test Query for Tagged Tables """
##    dependencies    = ('StorageHandlerTC','TC_NormalTables')
##    __StopOnError__ = True
##    
##    def test_Select_01(self):
##        """ Testing basic Select """
##        self.fail("Test not implemented.")
##
##    def test_Select_02(self):
##        """ Testing a more complicated Select query """
##        self.fail("Test not implemented.")

if __name__ == '__main__':
    testRunner(dependenciesOn=False)

