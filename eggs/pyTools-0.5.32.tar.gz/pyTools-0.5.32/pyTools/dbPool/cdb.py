"""
This is the CDB handler backend for dataStorage.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

$Id: cdb.py,v 1.1 2003/11/20 22:54:56 seoman Exp $
"""
__revision__ = "$ Revision: $"[11:-2]
__author__ = "Simon Hookway 2003 (Obsidian Consulting Group)"
__author_email__ = "simon@obsidian.com.au"


import cdb,cPickle,string
from db_pool import ContainerBase,DbPoolError,QueryType
from pyTools import utils

class Container(ContainerBase):
    """
    This is a container class it handles the CDB specific storage and
    retrieval of the data objects using a generic form.
    """
    def __init__(self):
        containerBase.__init__(self)

    def __del__(self):
        pass

    def _connect(self,container):
        """
        Makes a connection to a MySQL DB, an internal function called by
        runquery when the connection isn't open.
        """
        base = self.connArgs[container].get('db_base','')
        db = self.connArgs[container].get('database','')
        fn = os.path.join((base,db))
        if not utils.pathExists(fn):
            raise DbPoolError("Failed to open CDB storage container.")
        cursor = Cursor(db_path=fn)
        self.containers[container] = cursor
        return cursor
 
    def run(self,cursor,query):
        """
        Internal function actually runs the query, used to encapsulate the
        execute function of the cursor as they differ slightly between
        db backends (especially this one).
        """
        results = []
        if query[0] == 'get':
            tmp,tables,select,wheres,orderby = query
            for table in tables:
                results.extend(cursor.get(table,select))
            
 
    def getQueryType(self, query):
        qt = QueryType()
        if query[0] in ('set','add','del'):
            qt.write = 1
        qt.name = query[0]
        return qt

    def insert_id(self, container):
        return self.getCursor(container).insert_id()

    def _buildSelect(self,selects=["*"],wheres=None,froms=None,orderby=None):
        """
        Internal function to build a simple select string
        """
        if not froms:
            raise DbPoolError,"Need to tell me where to get the data from."
        return ('get',froms,selects,wheres,orderby)
    
    def _buildInsert(self,data,table):
        """
        If data is a list the first row is the field list, the rest are the 
        values to add, otherwise if data is a dictionary the keys are the
        field names.
        """
        # in CDB we store a the key:value pairs as the value to the record
        # index. So here we want to pass back a list of dictionaries
        if type(data) == types.DictType:
            ret = [data]
        elif type(data) in (types.TupleType,types.ListType):
            if len(data) < 2:
                raise DbPoolError("Invalid data length.")
            ret = []
            for row in data[1:]:
                for x in range(len(data[0])):
                    ret[data[0][x]] = data[1][x]
        else:
            raise DbPoolError("Invalid data type for insert.")
            
        return ('add',froms,ret)

    def _buildUpdate(self,data,table,wheres):
        """
        Internal function, updates a table records.
        
        updates - is a dictionary of the new values.
        table   - is the table to update
        wheres  - is a dictionary of where 'key' = 'field', field can be a
                  list for 'IN' type wheres
        """
        return ('set',[table],data,wheres)

    def getIndexForTable(self,table):
        retVal = None
        if self.tableExists(table):
            c,n = self.runquery('desc %s' % table)
            desc = self.fetchalltup(c)
            for row in desc:
                if row[5] == 'auto_increment':
                    retVal = row[0]
                    break
        return retVal
 
    def listDBs(self):
        """
        List all existing databases, for backup purposes.
        """
        c,n = self.runquery("show databases")
        return map(lambda x:x[0],self.fetchalltup(c))

    def listTables(self):
        """
        List all existing tables within the current database, for consistency
        check purposes.
        """
        c,n = self.runquery("show tables")
        return map(lambda x:x[0],self.fetchalltup(c))
        
    def tableExists(self,table=None):
        """
        Returns 1 if the table exists, 0 otherwise.
        """
        if table and table in self.listTables():
            return 1
        else:
            return 0
 
class Cursor:
    """
    This is the cursor class for the CDB dataStorage backend. The idea is
    that all the CDB access logic goes here. This is because we have to open
    a separate file for each table, we can keep a number of index tables 
    (or files) to speed lookups. So there is one Cursor instance per file,
    or table in use.
    """
    def __init__(self, baseName):
        """
        Constructor, we don't expect to know what table/file we are openning
        until a get/set/add/del method is called. This class handles all the 
        index cdb files associated with the tables.
        """
        self.baseName = baseName
        self.tables = {}
        self.indexes = {}

    def __del__(self):
        pass

    def get(self, table, selects="*"):
        """
        Returns a list
        """
        pass
