"""
This module contains the base for Container Handlers. All Containers should
inherit from the ContainerBase class in this module.

Containers are a virtual concept defining a data storage area. I may have 2
data storage areas in an application in order to keep application configuration
and data separate. Or I may be using an LDAP group and contact storage and
DBM data storage areas. In these cases I would have 2 separate Containers. This
is primarily usefull for segregating data sets for distribution or if the data
your reading from is maintained by a separate application in different databases
and even on different hosts.

Containers have 1 or more Connectors; these maintain 1 or physical connections
to the backend.

Public Classes:

  o CursorBase -

  o ConnectionBase -

  o ConnectorBase -

-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Copyright (C) 2003 LGPL Simon Hookway

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

$Id: Handler.py,v 1.24 2005/12/07 06:54:24 seoman Exp $
"""
__revision__ = "$Revision: 1.24 $"[11:-2]

# System imports
import types,time,sys,weakref

# pyTool imports
from pyTools import HardError,SoftError

# Local imports
from ResultSet import ResultSet
from db_pool import DbPoolError
from Query import *


class TransactionError(SoftError):
    """ Something in transactional support failed """
    

class NoAvailableConnectors(SoftError):
    """ Exception raised when a Connector cannot be opened """
    

class NoAvailableConnections(SoftError):
    """ Exception raised when a Connector cannot be opened """
    
    
class InvalidQuery(HardError):
    """ Exception raised when the Query is not valid """


class CursorBase:
    """
    A Cursor runs queries on the backend, this is the guts of the backend.
    """
    # The ID of the last insert operation performed
    __lastrowid = 0
    insert_id = property(lambda s: s.__lastrowid)
   
    # Errors this class raises
    Errors = (TransactionError,)
    
    # The object returned as the result set
    __ResultSet__ = ResultSet

    # Executed a query?
    __executed = False

    # What factory is used to transform Query objects into SQL
    TransformerFactory = TransformerFactory

    def __init__(self, connection):
        """ New Cursor passing in the Connection that spawned it """
        self.__connection = weakref.ref(connection)
        self.cleanup()
        
    id = property(lambda s: id(s))

    def close(self):
        self.__connection = None

    def cleanup(self):
        self.messages = []
        self.__lastrowid = 0
        self.__executed = False

    def __get_connection(self):
        """ Return the Connection for this Cursor """
        if self.__connection is None:
            raise DbPoolError("Cursor is closed.")
        return self.__connection()
    connection = property(__get_connection)

    identifier = property(lambda s:s.connection.connector.container.identifier)
    handler_type = property(lambda s:s.connection.connector.handler_type)
    
    def _get_result(self):
        """ Return a result object from the backend library """
        raise NotImplementedError("This should be overridden.")
    #
    # Transactions are implemented through the Connection, these are wrappers
    #
    def begin(self):
        """ Start a transaction """
        self.connection.begin()

    def rollback(self):
        """ Rollback a transaction to a savepoint or the beginning """
        self.connection.rollback()

    def commit(self):
        """ Commit the transaction """
        self.connection.commit()
    #
    # Access methods
    #
    def isTaggedTable(self, tablename):
        """ Returns True iff table appears to conform to tagged format """
        pass

    def isTaggedQuery(self, query):
        return query.table_type == 'tagged' and self.isTaggedTable(query.table)

    def __execute(self, query):
        """ Execute Query object without predjudice """
        query.transformer = self.TransformerFactory.factory
        self.__executed = query
        qry,params = query.do()(paramstyle=self.connection.paramstyle)
        return self.runquery(qry,params)

    def execute(self, query):
        """ 
        Cursor.execute(Query) -> ResultSet or Int
        
        Run a Query of Insert, Delete, Update or Select as defined in Query
        on this Cursor and return the ResultSet or affected_rows.
        """
        if not isinstance(query,(Insert,Update,Delete,Select)):
            raise InvalidQuery("query must be an instance of Query.")
        # Make sure any previously executed queries are cleaned out
        self.cleanup()
        return self.__execute(query)
        
##        XXX - this needs more thought
##        if self.isTaggedQuery(query) and isinstance(query,Update):
##            # Collect the unique Id for all matching objects
##            selects = ['id','tagid','attribute','value']
##            qry = Select(query.table,*selects)
##            qry.wheres = query.wheres
##            # We need to go through the ids and remove any list type values
##            # where the list is bigger than the list in _sets_:
##            #    UPDATE t1 set end_date=now() where id=%s
##            ids = {}
##            for row in results.__as_dict__():
##                if row['tagid'] in ids:
##                    t = ids[row['tagid']]
##                    if row['attribute'] in t:
##                        ids[row['tagid']]
##                else:
##                    ids[row['tagid']] = {row['attribute']: [row['id'],]}
##
##            # Then we update the remaining _id_ rows:
##            #    UPDATE t1 set value=%s where id IN (ids)
##            # And finally add any left over ones:
##            #    INSERT INTO t1 (id,attribute,value,type,start_date) VALUES (%s)
##            # Thus it concludes.
##            allQueries = []
##            insert = Insert(query.table)
##            insert.setRows(['tagid','attribute','value'])
##            deletes = []
##            updates = {}
##            for k,v in query.items():
##                # tagged values should ALWAYS be a list of values, but be sane
##                if type(v) not in (types.ListType,types.TupleType):
##                    v = [v,]
##                # go through the rows
##                for tagid,vals in ids:
##                    attrVals = vals.get(k,[])
##                    for x in range(max(len(v),len(attrVals))):
##                        if x >= len(attrVals):
##                            insert += (tagid,k,v[x])
##                        elif x >= len(v):
##                            deletes.append(attrVals[x])
##                        elif v[x] != attrVals[x]:
##                            if v[x] in updates:
##                                updates[v[x]].append(attrVals[x])
##                            else:
##                                updates[v[x]] = [attrVals[x],]
##            # add an update query for each value being set
##            for val,ids in updates.items():
##                update = Update(query.table,value=val)
##                update.wheres.add(id=IN(*ids))
##                allQueries.append(update)
##            # now add the insert and delete queries
##            allQueries.append(insert)
##            delete = Delete(query.table)
##            delete.wheres(id=IN(*deletes))
##            allQueries.append(delete)
##            return queries
##        else:

    def last_insert_id(self):
        """
        Cursor.last_insert_id() -> Int
        
        Returns the last rowid used by an insert or update query.
        """
        return self.connection.insert_id()
    
    def runquery(self, query, params=None):
        """ 
        Cursor.runquery(<SQL Query String>,[params]) -> ResultSet or Int
        
        Runs a Traditional query on this Cursor, this is a SQL query string
        and can accept parameters in the paramstyle of the backend.
        """
        conn = self.connection
        try:
            self._result = conn.query(query,params)
            self.__lastrowid = self.last_insert_id()
            self._check_for_warnings()
        except self.Errors, e:
            msg = (e.__class__.__name__,e.__str__(),query,params)
            self.messages.append(msg)
            raise
        if not self.__executed:
            self.__executed = True
        return self.result

    def __get_execed_query(self):
        """ Internal method to return the last executed Query object """
        if self.__executed in (True,None):
            return None
        else:
            return self.__executed
    executed_query = property(__get_execed_query)
    
    def getResult(self):
        """ 
        Cursor.getResult() -> ResultSet or Int or None.
        
        Returns the results of the last query executed, you cannot collect the
        results of a query more than once. If no Query has been run (thus no
        results are available) then None is returned. Otherwise an Int showing
        the affected_rows or a ResultSet instance is returned.
        """
        result = None
        if self.__executed is not None:
            result = self.__ResultSet__(self)
            self.__executed = None
        return result
    result = property(getResult)
    
    def affected_rows(self):
        """ 
        Cursor.affected_rows() -> Int or None
        
        Returns the number of affected rows resulting from the last query run
        or None if no Query has been run on the Cursor yet.
        """
        return self.connection.affected_rows()

    def _check_for_warnings(self):
        """ Check for warning from the query """
        return
    
    
class ConnectionBase:
    """
    The Connection class is used to hold a single connection to a specific host
    and database. Cursors are created by the Connection and Transactional
    support should be implemented through the Connection.

    This class is usually Mixed In with the Specific backend Connection class.
    """
    # Cursor class to use
    __CursorClass__ = CursorBase
    
    # converter dictionary, should be set in the __init__
    converter = None
    
    # Parameter style used by this connection
    paramstyle = 'pyformat'

    # Errors raised by this class
    Errors = (TransactionError,)

    def __init__(self, connector=None):
        """ Constructor """
        self.__connector = weakref.ref(connector)
        self.__cursors = weakref.WeakValueDictionary()
        self.__closed = False
        self.messages = []

    connector = property(lambda s:s.__connector())
    closed = property(lambda s:s.__closed)
        
    def __del__(self):
        """ Connection is being garbage collected """
        self.close()
        
    def _close(self):
        raise NotImplementedError("Needs to be implemented by the Connection.")

    def size(self):
        raise NotImplementedError("Needs to be implemented by the Connection.")
        
    def close(self, commit=False):
        """ 
        Connection.close() -> None
        
        Close this Connection doing an optional rollback. We let the Cursors
        close themselves since they don't hold any reference to the Connection
        anyway.
        """
        if self.__closed is True:
            return
        if commit:
            self.commit()
        else:
            self.rollback()
        for cursor in self.__cursors.data.values():
            cursor().close()
        self._close()
        self.connector.removeConnection(self)
        self.__closed = True

    def insert_id(self):
        raise NotImplementedError("Needs to be implemented by the Connection.")
    #
    # Connection locking is used to prevent multiple accesses
    #
    __locked = False
    def lock(self):
        """ Locks the Handler """
        self.__locked = True
        
    def unlock(self):
        """ Releases the Handler """
        self.__locked = False
    
    def isLocked(self):
        """ Is this handler locked """
        return self.__locked
    #
    # Access methods
    #
    def getCursor(self):
        """ 
        Connection.getCursor() -> Cursor
        
        Returns a new Cursor on this Connection. Cursors should be thrown away
        after they are used and no stored. If you need another one just grab
        a new Cursor.
        """
        if self.__closed is True:
            raise ConnectionClosed("getCursor failed.")
        cursor = self.__CursorClass__(self)
        self.__cursors[id(cursor)] = cursor
        return cursor
    cursor = property(getCursor,doc="Return a new Cursor")

    def query(self, query, params=None):
        """ Should be defined in the module, runs all queries on the server """
        raise NotImplementedError("Needs to be implemented by the Connector.")
    #
    # Parameter and Query sanitiser
    #
    def literal(self, o):
        """
        Connection.literal(object) -> String or Sequence
        
        This is a DB API non-standard method to convert the object 'o' into an
        SQL safe string. If 'o' is a string it is returned after conversion, if
        its a non-string sequence then it each item of the sequence is convert-
        ed and returned as a safe sequence.
        """
        return self.converter(o)
        
    def unicode_literal(self, u, dummy=None):
        """
        Connection.unicode_literal(object) -> String or Sequence
        
        Convert a unicode object u to a string using the current character set
        as the encoding. If that's not available, latin1 is used.
        """
        return self.literal(u.encode(self.character_set_name()))
    #
    # Transactional methods
    #
    def isTransactional(self):
        """
        C.isTransactional() -> True/False

        Override for a specific server implementation to return whether the
        server has transactional support or not.
        """
        return False
    
    __transactional_support = None
    def __get_transactional(self):
        if self.__transactional_support is None:
            self.__transactional_support = self.isTransactional()
        return self.__transactional_support
    transactional = property(__get_transactional)
    
    # Transaction, when its alive
    __txn = False
    
    BeginStatement = "START TRANSACTION"
    def begin(self):
        """
        Connection.begin() -> None

        Start a new transaction, raising an TransactionError if support for
        transactions is not available in this backend. If transaction nesting
        is supported then we nest, if savepoints are supported then
        """
        if not self.transactional:
            raise TransactionError("Transactions are not supported.")
        if self.__txn is False:
            self.query(self.BeginStatement)
            self.__txn = True
            
    RollbackStatement = "ROLLBACK"
    def rollback(self):
        """ 
        Connection.rollback() -> None
        
        Rollback the transaction if one is current and transactions are sup-
        ported by this backend.
        """
        if not self.transactional:
            raise TransactionError("Transactions are not supported.")
        if self.__txn is True:
            self.query(self.RollbackStatement)
            self.__txn = False

    CommitStatement = "COMMIT"
    def commit(self):
        """ 
        Connection.commit() -> None
        
        Commits the current transaction if there is one, raises an Error if
        transactional support is not implemented by the backend.
        """
        if not self.transactional:
            raise TransactionError("Transactions are not supported.")
        if self.__txn is True:
            self.query(self.CommitStatement)
            self.__txn = False
    #
    # Utility methods
    #
    def getTableIndex(self, table):
        """ Return the index of the table or None """
        return None
    
    def tableExists(self, table):
        """ Returns True iff a table of this name exists in the DB """
        return table in self.listTables()

    def optimiseTable(self, table):
        """ Optimise and compact the space used by a table """
        return

    def getNewId(self, table):
        """ Returns the next available id """
        raise NotImplementedError("Needs to be implemented by the Connection.")

    def listTables(self):
        """ Returns a list of tables in the database """
        raise NotImplementedError("Needs to be implemented by the Connection.")
        
    def descTable(self, table):
        """ Returns a description of the specified table """
        raise NotImplementedError("Needs to be implemented by the Connection.")

    def dropTable(self, table):
        """ Remove a table and all its contents """
        raise NotImplementedError("Needs to be implemented by the Connection.")
        

class ConnectorBase:
    """
    A Connector represents a pool of connections to particular backend server.
    """
    # Type of this connector; eg, MySQL, PostgreSQL, MS-SQL, ...
    type = "Unset"
    
    # Errors raised by the Connector class
    Errors = (DbPoolError, NoAvailableConnections,)
    
    # Maximum connections to host allowed
    MaxConnections = 3

    # Determines whether host is locked on updates
    __LockOnWrites__ = False

    def __init__(self, container, host, port, socket, username, password, db):
        """ Setup this Connector to the backend """
        self.__container = container
        self.__connections = []
        self.host = host
        self.port = port
        self.socket = socket
        self.username = username
        self.__ = password
        self.database = db

    container = property(lambda s:s.__container)

    def __del__(self):
        """ Called when this Connector is removed """
        self.close()

    def close(self):
        """ Close all Connections on this Connector """
        x = 0
        while self.__connections:
            try:
                self.__connections[x].close()
            except Exception,detail:
                print "Failed to close:",self.__connections[x],'-',detail
                x += 1
            else:
                del self.__connections[x]
        self.__container = None
        return

    def removeConnection(self, connection):
        if connection in self.__connections:
            self.__connections.remove(connection)
        return connection
    
    def _cleanConnections(self):
        """ Clean up any excessive Connections """
        x = len(self.__connections) - 1
        while (len(self.__connections) > self.MaxConnections):
            if not self.__connections[x].isLocked():
                self.__connections[x].close()
            x -= 1
        return

    def isTransactional(self):
        """ Opens at least 1 connection to figure out server capabilties """
        con = self.getConnection()
        if con is None:
            raise DbPoolError("Can't get a Connection to server.")
        return con.transactional
    #
    # Readonly
    #
    __readonly = False
    def __set_readonly(self, value):
        """ Sets the readonly, not the same as opening the db as readonly """
        if value:
            self.__readonly = True
        else:
            self.__readonly = False

    def __get_readonly(self):
        """ Returns whether this connection is readonly """
        return self.__readonly
    readonly = property(__get_readonly,__set_readonly)
    #
    # Access methods
    #
    def dropDatabase(self):
        """
        Connector.dropDatabase() -> None
        
        Drop the current database closing all open connections to the database
        first.
        """
        raise NotImplementedError("dropDatabase is not implemented.")
    
    def newConnection(self):
        """
        Create a new Connection using _connect, add it to the pool and return
        the Connection.
        """
        if len(self.__connections) >= self.MaxConnections:
            raise DbPoolError("Connection pool is full.")
        connection = self.__ConnectionClass__(self)
        self.__connections.append(connection)
        return connection
    
    def getConnection(self):
        """
        Returns a connection from those available, when first used there are no
        connections and _connect is used to create one and place it in the 
        """
        self._cleanConnections()
        for x in range(self.MaxConnections):
            if x >= len(self.__connections):
                return self.newConnection()
            elif not self.__connections[x].isLocked():
                return self.__connections[x]
        raise DbPoolError("No available connections at this time.")

    def setMaxConnections(self, value):
        """
        Set the maximum number of connections, this will not create any new
        connections but will close down any unused connections until the number
        is less than or equal to MaxConnections.
        """
        if type(value) not in (types.IntType, types.LongType):
            raise TypeError("setMaxConnections requires and Int or Long value.")
        self.MaxConnections = value
        self._cleanConnections()
        return

    def getCursor(self):
        """ Returns a new Cursor on this Connector """
        con = self.getConnection()
        if con is not None:
            return con.cursor
        raise DbPoolError("No available connections at the moment.")
    cursor = property(getCursor)

    def execute(self, query):
        """ Execute a QueryType Object on the first available Connection """
        return self.getConnection().cursor.execute(query)

    def runquery(self, query, params=None):
        """
        Run a traditional style query on this Connector, we select the next
        available Connector for this.
        """
        return self.cursor.runquery(query,params)
    #
    # Legacy methods for backward compatability
    #
    def listDBs(self):
        """ This is depreciated, you should use the new methods """
        raise DepreciatedError("listDbs() is very old, do not use.")
        
    def addRecord(self,data,table,tableType='normal',delayed=False):
        """ This is depreciated, you should use the new methods """
        query = Insert(table)
        query.table_type = tableType
        query.delayed = delayed
        if type(data) == types.DictionaryType:
            query.setRows(data.keys())
            query += [ data[val] for val in query.rows ]
        elif type(data) in (types.ListType,types.TupleType):
            query.setRows(data[0])
            for row in data[1:]:
                query += row
        else:
            raise DbPoolError("data in addRecord of incorrect type.")
        return self.execute(query)

    def addMultipleRecords(self,data,table,tableType='normal',delayed=False):
        raise DepreciatedError("addMultipleRecords() is very old, do not use.")
    
    def deleteRecords(self,table,wheres,tableType='normal'):
        """ This is depreciated, you should use the new methods """
        query = Delete(table)
        query.table_type = tableType
        query.wheres = ConvertWheres(wheres)
        return self.execute(query)
       
    def updateRecord(self,data,table,wheres=None,tableType='normal'):
        """ This is depreciated, you should use the new methods """
        if type(data) != types.DictionaryType:
            raise TypeError("data must be a dictionary.")
        query = Update(table)
        query.table_type = tableType
        query.set(data)
        query.wheres = ConvertWheres(wheres)
        return self.execute(query)

    def selectOne(self,selects=None,wheres=None,froms=None,
                  orderBy=None,groupBy=None,limit=None,tableType='normal'):
        """ This is depreciated, you should use the new methods """
        raise DepreciatedError("selectOne() is very old, do not use.")

    def selectMany(self,selects=None,wheres=None,froms=None,orderBy=None,
                   groupBy=None,limit=None,tableType='normal'):
        """ This is depreciated, you should use the new methods """
        raise DepreciatedError("selectMany() is very old, do not use.")

    def simpleFetch(self,froms,wheres=None,orderBy=None,groupBy=None,limit=None,
                    tableType='normal',object=None):
        """ This is depreciated, you should use the new methods """
        raise DepreciatedError("simpleFetch() is very old, do not use.")

