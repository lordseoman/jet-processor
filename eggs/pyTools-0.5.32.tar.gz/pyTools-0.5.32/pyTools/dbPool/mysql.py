"""
This file contains the SQL code linking MySQL to the DB handler

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software 
Foundation; either version 2 of the License, or (at your option) any later 
version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with 
this program; if not, write to the Free Software Foundation, Inc., 
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

 * original by Kevin Littlejohn contactable on darius@obsidian.com.au, adapted
   for use with snmp DB by Simon Hookway 2002 under LGPL
 
 * adapted again for use with multiple DB Connectors by Simon Hookway 2003

 * adapted yet again for Container/Connector which is a DB refactor 2004

mysql.py, Copyright (C) 2003 Simon Hookway

mysql.py comes with ABSOLUTELY NO WARRANTY; This is free software, and you are
welcome to redistribute it under certain conditions, as per LGPL licencing.

This is no longer a callable script, it is an integral part of the DataStorage
system and while it may be useful in adapting MySQLdb for your purposes it is
unlikely to be useable outside of DataStorage Containers.

$Id: mysql.py,v 1.33 2008/02/04 02:01:42 seoman Exp $
"""
__revision__ = "$Revision: 1.33 $"[11:-2]

# System imports
import string, types, re, os, sys
from mx.DateTime import *

# Local imports
from Handler import ConnectorBase,ConnectionBase,CursorBase,TransactionError
from Query import Insert,Update,Delete,Select
from ResultSet import ResultSet as ResultMixin
import converters


MYSQL_CONNECTOR_TYPE = 'MySQL Connector'

re_INSERT = re.compile(r'\svalues\s*(\(.+\))',re.IGNORECASE)

import _mysql
from MySQLdb.constants import FIELD_TYPE,CLIENT,FLAG


from _mysql_exceptions import *
_Errors = (
    MySQLError,
    Warning,
    Error,
    InterfaceError,
    DatabaseError,
    DataError,
    OperationalError,
    IntegrityError,
    InternalError,
    ProgrammingError,
    NotSupportedError,
)


class Converter(converters.Converter):
    
    def literal(self, s):
        return _mysql.string_literal(s)
    
    def None2NULL(self, o):
        return _mysql.NULL
        

def getConverters():
    """
    Collect a converters dictionary used to convert types to an escaped sequence
    for MySQL and for converting FIELD types from MySQL into python objects for 
    return values.
    """
    converter = Converter({
        FIELD_TYPE.TINY      : int,
        FIELD_TYPE.SHORT     : int,
        FIELD_TYPE.LONG      : long,
        FIELD_TYPE.FLOAT     : float,
        FIELD_TYPE.DOUBLE    : float,
        FIELD_TYPE.DECIMAL   : float,
        FIELD_TYPE.LONGLONG  : long,
        FIELD_TYPE.INT24     : int,
        FIELD_TYPE.YEAR      : int,
    })
    converter.update({
        FIELD_TYPE.TIMESTAMP : converter.Timestamp_or_None,
        FIELD_TYPE.DATETIME  : converter.DateTime_or_None,
        FIELD_TYPE.TIME      : converter.Time_or_None,
        FIELD_TYPE.DATE      : converter.Date_or_None,
        FIELD_TYPE.BLOB      : [(FLAG.BINARY, converter.Array),(None, None),],
    })
    converter.encoding = sys.getdefaultencoding()
    return converter

    
class ResultSet(ResultMixin):
            
    def _result_description(self, _result):
        return _result.describe()

    def _result_rowcount(self, _result):
        return _result.num_rows()

    def _result_fieldcount(self, _result):
        return _result.num_fields()

    def _fetch_row(self, _result, size=1):
        """ Collect rows from the MySQL result object """
        if _result:
            return _result.fetch_row(size,0)
        else:
            return ()
            

class Cursor(CursorBase):
    """ A MySQL Cursor """
    __ResultSet__ = ResultSet
    Errors = CursorBase.Errors + _Errors
    
    def last_insert_id(self):
        """
        C.last_insert_id() -> Int
        
        MySQLdb has a oddity when doing multi-inserts in a single query, that
        is, where the values are comma separated. The backend asks for the next
        insert Id only once and increments it internally for each of the sub-
        sequent inserts. This means the connection.insert_id doesn't return the
        last insert id at all, but the first insert Id of the last Insert query
        which is rather annoying.
        """
        offset = 0
        if isinstance(self._CursorBase__executed,Insert):
            offset = len(self._CursorBase__executed) - 1
        return self.connection.insert_id() + offset
    
    def _get_result(self):
        """ Return a result object from the backend library """
        return self.connection.store_result()
    
    def _check_for_warnings(self):
        """ Check for warning from the query """
        from string import atoi, split
        info = self.connection.info()
        if info and atoi(split(info)[-1]):
            raise Warning(info)
        return
    

class Connection(_mysql.connection, ConnectionBase):
    """
    A Connection to a MySQL server, the _mysql module overrides the escape and
    manages the connection and chatter to the database while the Cursor is the
    end-users interface to the backend, this class does the real work.
    """
    __CursorClass__ = Cursor
    
    # Savepoints for transactions
    __savepoints = []
    
    # Savepoints names must match these
    _re_savepoints = re.compile(r'^[a-zA-Z]\w*$')
    
    # Errors raised by this class
    Errors = ConnectionBase.Errors + _Errors
    
    # set default paramstyle, this is not the style the Cursor accepts but the
    # style the backend uses to submit queries to the DB.
    paramstyle = 'format'

    # do we auto create databases
    autocreate = True
    
    def __init__(self, connector):
        """ Start a connection """
        ConnectionBase.__init__(self, connector)
        _mysql.connection.__init__(
            self,
            host=connector.host,
            port=connector.port,
            user=connector.username,
            passwd=connector.__,
            unix_socket=connector.socket,
            db='',
        )
        self.converter = getConverters()
        if connector.database in self.listDBs():
            self.select_db(connector.database)
        elif self.autocreate is True:
            self.query("CREATE DATABASE %s" % connector.database)
            self.select_db(connector.database)
        else:
            self.close()
            raise DatabaseError("database doesn't exist, and no autocreate.")
    
    def __deparam(self, query, params):
        """
        This is an internal function used by query to deparametise the query
        since SQLite doesn't handle parametised queries. While we could have
        used paramstyle of None, SQLite doesn't handle comma separated lists of
        values for iterative queries. So here we make up a semi-colon separated
        list of queries to be run en-masse.
        """
        try:
            return query % self.literal(params)
        except TypeError, e:
            if e.args[0] in (
                "not enough arguments for format string",
                "not all arguments converted"):
                raise ProgrammingError(e.args[0])
            raise ProgrammingError(e)
        
    def query(self, query, params=None):
        """
        Connection.query(SQL,[params]) -> None

        Runs an SQL safe query on the MySQL server using this Connection, the
        result should be obtained through the Cursor.
        """
        if params:
            m = re_INSERT.search(query)
            if m:
                p = m.start(1)
                qv= query[p:]
                q = [ self.__deparam(query,params[0]), ]
                q.extend([ self.__deparam(qv,a) for a in params[1:] ])
                query = ','.join(q)
            else:
                query = self.__deparam(query,params)
        return _mysql.connection.query(self,query)

    def listDBs(self):
        """
        Connection.listDBs() -> [ String, ... ]

        Returns a list of Database names currently on this server, including
        ones you don't have permissions to access.
        """
        return [ x[0] for x in self.cursor.runquery("show databases") ]
        
    def isTransactional(self):
        return self.server_capabilities & CLIENT.TRANSACTIONS
    
    _close = _mysql.connection.close
        
    def savepoint(self, name=None):
        """
        Saves a transaction at this point, so it can be partially rolled back
        if needed.
        """
        if not self.transactional:
            raise TransactionalError("Transactions are not supported.")
        if name is None:
            name = "sp_%02d" % len(self.__savepoints)
        elif name in self.__savepoints:
            del self.__savepoints[name]
        elif type(name) != types.StringType or not self._re_savepoints(name):
            raise TransactionalError("Savepoint name is invalid.")
        self.query("SAVEPOINT %s" % name)
        self.__savepoints.append(name)
        
    def undo(self):
        """ Rollback to the last savepoint """
        if self.__savepoints:
            self.rollback(savepoint=self.__savepoints[-1])
            
    def rollback(self, savepoint=None):
        """ Rollback the transaction, optionally to a particular savepoint """
        if not self.transactional:
            raise TransactionalError("Transactions are not supported.")
        if self._ConnectionBase__txn is False:
            return
        if savepoint and savepoint not in self.__savepoints:
            raise TransactionalError("No such savepoint, aborting.")
        elif savepoint:
            self.query("ROLLBACK TO SAVEPOINT %s" % savepoint)
            i = self.__savepoints.index(savepoint)
            self.__savepoints = self.__savepoints[:i]
        else:
            ConnectionBase.rollback(self)

    commit = ConnectionBase.commit
    #
    # General purpose utility methods
    #
    def size(self):
        """
        Connection.size() -> Long
        
        Returns the size of the current database on the filesystem if available
        to the Connection.
        """
        res = self.cursor.runquery("SHOW TABLE STATUS")
        res.iterator = dict
        size = 0L
        for data in res:
            size += data['Data_length'] + data['Index_length']
        return size
        
    def descTable(self, table): 
        """
        Connection.descTable(name) -> Tuple
        
        Returns a description of the table in the current database
        """
        return self.cursor.runquery('desc %s'%table)
    
    def getTableIndex(self, table):
        """
        Connection.getTableIndex(table) -> String
        
        Returns the Index column name for the requested table if the table has
        a primary index.
        """
        results = self.cursor.runquery("show index from %s" % table)
        results.iterator = dict
        for row in results:
            if row['Key_name'] == "PRIMARY":
                return row['Column_name']
        return None
    
    def getNewId(self, table, tType='normal'):
        """
        Returns the next available id..
        """
        if tType == 'normal':
            idx = self.getTableIndex(table)
        elif tType == 'tagged':
            idx = 'id'
        else:
            raise ProgrammingError("Unknown table type used.")
        results = self.cursor.runquery("select max(%s) from %s"%(idx,table))
        return results.getValue(0,idx) + 1

    def listTables(self):
        """ Returns a list of tables in the database """
        return [ r[0] for r in self.cursor.runquery("show tables") ]

    def dropTable(self, table):
        """ Remove a table and all its contents """
        return self.cursor.runquery("DROP TABLE %s" % table)

    def optimiseTable(self, table):
        """ Compact and optimise space used by a table """
        return


class Connector(ConnectorBase):
    """ MySQL Connector, creates and manages a pool of Connections """
    type = MYSQL_CONNECTOR_TYPE
    handler_type = "mysql"
    
    __ConnectionClass__ = Connection

    Errors = ConnectorBase.Errors + _Errors


## class Container(ContainerBase):
##     """
##     This is a container class, it converts data objects into MySQL code,
##     the data objects are generic in form.
##     """
##     def _buildTaggedInsert(self,data,table,delayed=0):
##         """
##         If data is a list the first row is the field list, the rest are the
##         values to add, otherwise if data is a dictionary the keys are the
##         field names. 
##         
##         A tagged table must always have the following columns: 
##         
##             id, attribute, value, start_date, end_date
##         
##         The id column must not be an auto_increment as this is the column
##         selected over, the id is generated by this routine prior to insertion.
##         
##         NOTE: you should always use a list since order is maintained.
##         """
##         # Sanitise the data into keys and a list of values
##         if type(data) == types.DictType:
##             keys,vals = data.keys(),[data.values()]
##         elif type(data) in (types.TupleType,types.ListType):
##             if len(data) < 2:
##                 raise self.Error("Invalid data length.")
##             keys = data[0]
##             vals = data[1:]
##         else:
##             raise self.Error("Invalid data type for insert.")
##         now = DateTime.now()
##         id = self.getNewId(table)
##         
##         # build the values by going over each vals record and building an
##         # attr/value pair with the same id. Being sure to increment the id
##         # for each record in vals, and escaping the list at the end.
##         data = []
##         for recSet in vals:
##             for x in range(len(keys)):
##                 data.append( [id, keys[x], recSet[x], now] )
##             id += 1
##         vals = map(lambda x:'('+','.join(map(self.escapeAndQuote,x))+')',data)
## 
##         # Build the insert query
##         query = "INSERT "
##         if delayed:
##             query += "DELAYED "
##         query+= "INTO %s (id,attribute,value,start_date) VALUES "%table
##         query+= ",".join(vals)
##         return query
## 
##     def _buildTaggedWheres(self, wheres, froms=None):
##         """
##         Internal function that builds a wheres string, note that froms is a
##         list of tables, this has been added recently so that any wheres state
##         ment that includes a table is not quoted.
##         
##         A tagged table must always have the following columns: 
##         
##             id, attribute, value, start_date, end_date
##         """
##         # start_date and end_date have special meaning on tagged tables.
##         tmp = ['(end_date > %s OR end_date IS NULL)' % DateTime.now(),]
##         majorJoinType = wheres[0]
##         for item in wheres[1:]:
##             joinType = item[0]
##             ss = []
##             for sets in item[1:]:
##                 condType = sets[0]
##                 # escape the values in the wheres if necessary.
##                 for num in range(2,len(sets)):
##                     i = sets[num]
##                     if type(i) != types.StringType:
##                         sets[num] = self.escapeAndQuote(i)
##                     elif not filter(lambda x,y=i: y.startswith("%s."%x), froms):
##                         sets[num] = self.escapeAndQuote(i)
##                 # build the inner condition
##                 if len(sets) == 1:
##                     pass
##                 elif sets[1] not in ('attribute','start_date','end_date','id'):
##                     inner = "(attribute = %s AND value " % sets[1]
##                 else:
##                     inner = "(%s " % sets[1]
## 
##                 if condType == 'BETWEEN':
##                     inner += "BETWEEN %s AND %s))" % (sets[2],sets[3])
##                 elif condType == 'IN':
##                     inner += "IN (%s))" % ','.join(sets[2:])
##                 elif condType in ('IS','IS NOT') and sets[2] == "'NULL'":
##                     inner += "%s NULL)" % sets[0]
##                 elif len(sets) == 1:
##                     inner = sets[0]
##                 else:
##                     inner += "%s %s)" % (condType,sets[2])
##             if ss:
##                 tmp.append("(%s)" % string.join(ss, " %s " % joinType))
##             tmp.append("(%s)" % string.join(ss, " %s " % joinType))
##         if tmp:
##             return " WHERE %s" % string.join(tmp," %s " % majorJoinType)
##         else:
##             return ""

# If called directly provide a Connector to the user
if __name__ == "__main__":
    from db_pool import Container
    import sys
    
    container = Container('default')
    container.add(
        'mysql',
        host='127.0.0.1',
        username='testsuite',
        password='hg873hS',
        db='testSuite',
    )
    print "A MySQL Container is available as container"
