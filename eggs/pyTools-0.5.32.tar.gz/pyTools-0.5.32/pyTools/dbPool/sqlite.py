"""
This is an SQLITE module for the DataStorage Handler.

$Id: sqlite.py,v 1.12 2008/02/04 02:09:24 seoman Exp $
"""
__revision__ = "$ Revision: $"[11:-2]

# System imports
import os, sys
from pysqlite2 import _sqlite
from types import NoneType

_Errors = (
    _sqlite.IntegrityError,
    _sqlite.InterfaceError,
    _sqlite.InternalError,
    _sqlite.NotSupportedError,
    _sqlite.OperationalError,
    _sqlite.ProgrammingError,
    _sqlite.Warning,
    _sqlite.DatabaseError,
)

# Local imports
from Handler import ConnectorBase,ConnectionBase,CursorBase
from ResultSet import ResultSet as ResultMixin
from Query import *
import converters


class Converter(converters.Converter):

    def literal(self, o):
        return "'%s'" % o.replace("'", "''")


class Transformer(TransformerFactory):
    """
    SQLite is slightly different SQL from MySQL, Delayed inserts are not supp-
    orted.
    """
    
    def NormalInsert(self):
        """ Prepare a normal Insert query ignoring delayed inserts """
        if not self.data:
            return
        values = "%s,"*len(self.fields)
        self.map.append(
            "INSERT INTO %s (%s)" % (self.table,','.join(self.fields))
        )
        self.map.append(" VALUES (%s)" % values[:-1], *self.data)
        return
    NormalInsert = staticmethod(NormalInsert)
    
    def NormalSelect(self):
        """ Generate a standard SQL for selects """
        fields = self.selects or ['*',]
        fields.append('rowid')
        if self.join is not None:
            fields = [ "%s.%s" % (self.table,f) for f in fields ]
        self.map.append("SELECT %s" % ','.join(fields))
        self.map.append(" FROM %s" % self.table)
        # Is there a Join
        if self.join is not None:
            self.map = self.join.do(self.table,'t2')
        # Run the where here
        self.wheres.do()
        # Only group for normal tables
        if self.groupby:
            self.map.append(" GROUP BY %s" % ','.join(self.groupby))
        # Append an orderby command
        if self.orderby:
            self.map.append(" ORDER BY %s" % ','.join(self.orderby))
        # Check the limits
        if self.limit:
            self.map.append(" LIMIT %d,%d" % self.limit)
        return
    NormalSelect = staticmethod(NormalSelect)


class ResultSet(ResultMixin):
    
    def _fetch_row(self, _result, size=1):
        raise NotImplementedError("This is not valid on this backend.")
    
    def _walk_result(self, _result):
        for x in range(_result.rowcount):
            yield _result.row_list[x]
        return
        
    def _result_description(self, _result):
        return _result.col_defs

    def _result_rowcount(self, _result):
        return _result.rowcount

    def _result_fieldcount(self, _result):
        return len(_result.col_defs)


class Cursor(CursorBase):
    """ A SQLite Cursor """

    __ResultSet__ = ResultSet

    Errors = CursorBase.Errors + _Errors

    TransformerFactory = Transformer

    def _get_result(self):
        """ 
        Return a result object from the backend for ResultSet, SQLite always
        returns a result which is not false even if its empty. Very silly don't
        you think? So we can only return a result if its a Select query.
        """
        if isinstance(self.executed_query,(Select,NoneType)): 
            return self._result
        return None
    

class Connection(ConnectionBase):

    __CursorClass__ = Cursor

    Errors = ConnectionBase.Errors + _Errors
    
    BeginStatement   = "BEGIN"
    CommitStatement  = "COMMIT"
    RollbackStatement= "ROLLBACK"

    paramstyle = 'format'
    db = None

    def __init__(self, connector):
        """ Create a new connection to a database """
        ConnectionBase.__init__(self,connector)
        self.db = _sqlite.connect(
            connector.database, 
            0755, 
            detect_types=_sqlite.PARSE_DECLTYPES
        )
        # The base converter
        self.converter = Converter()
        self.converter.encoding = sys.getdefaultencoding()
        # Register our converters so SQLite will use the adapters to transform
        # datatypes into strings and converters to transform field types into
        # python objects
        register = _sqlite.register_converter
        register("str", str)
        register("int", int)
        register("long", long)
        register("float", float)
        register("unicode", self.converter.Unicode2Str)
        #register("binary", _sqlite.decode)
        register("date", self.converter.DateTime_or_None)
        register("time", self.converter.Time_or_None)
        register("timestamp", float)
        register("interval", self.converter.TimeDelta_or_None)
        
        self.db.set_command_logfile(None)
    
    def __deparam(self, query, params):
        """
        This is an internal function used by query to deparametise the query
        since SQLite doesn't handle parametised queries. While we could have
        used paramstyle of None, SQLite doesn't handle comma separated lists of
        values for iterative queries. So here we make up a semi-colon separated
        list of queries to be run en-masse.
        """
        try:
            return query % self.literal(params)
        except TypeError, e:
            if e.args[0] in (
                "not enough arguments for format string",
                "not all arguments converted"):
                raise _sqlite.ProgrammingError(e.args[0])
            raise _sqlite.ProgrammingError(e)
    
    def query(self, query, params=None):
        """
        Connection.query(SQL,[params]) -> None
        
        Runs an SQL safe query on the MySQL server using this Connection, the
        result should be obtained through the Cursor.
        """
        if params:
            if type(params[0]) in (list,tuple):
                query = ';'.join([ self.__deparam(query,p) for p in params ])
            else:
                query = self.__deparam(query,params)
        return self.db.execute(query)
    
    def isTransactional(self):
        """
        Connection.isTransactional() -> True/False
        
        Returns whether this backend implementation support transactions.
        """
        return True

    def _close(self):
        if self.db:
            self.db.close()
        self.db = None
        
    def insert_id(self):
        """
        Connection.insert_id() -> long
        
        Returns the last inserted row id from the connection.
        """
        return self.db.sqlite_last_insert_rowid()
    
    def affected_rows(self):
        """
        Connection.affected_rows() -> long
        
        Returns the number of rows affected by the last query run on this
        Connection.
        """
        return self.db.sqlite_changes()
    #
    # Easy use methods for connection based requests
    #
    def listTables(self):
        """
        Connector.listTables() -> [String, ... ]
        
        Returns a list of table names that currently exist in this database.
        """
        query = Select('sqlite_master','tbl_name')
        query.wheres.add(type='table')
        query.orderby = ('tbl_name',)
        return [ x[0] for x in self.cursor.execute(query) ]
    
    def descTable(self, table):
        """
        Connection.descTable(table) -> [ Tuple, ... ]
        
        Returns an SQL style of column info tuple of id, name, type, null flag,
        default value and whether the column is primary key. eg:

            ('0', 'id', 'integer', '0', None, '1')
        """
        return self.cursor.runquery("PRAGMA table_info('%s')" % table)
    
    def getTableIndex(self, table):
        """ 
        Connection.getTableIndex(table) -> String

        Returns the index column for the selected table. While it is suggested
        that you have an 'id' field in your tables using the primary key syntax
        we use SQLite's builtin ROWID here. This is primarily used by DataStore
        objects in Update operations. rowid is always returned using the Select
        Query syntax.
        """
        desc = self.descTable(table)
        if not desc:
            raise DatabaseError("Table description failure: %s"%table)
        for i,name,t,nf,d,pk in desc:
            if pk == '1':
                return name
        return 'rowid'

    def dropTable(self, table):
        """
        Connection.dropTable(table) -> None
        
        Remove a table from the database, this will delete all data contained
        in the table also.
        """
        return self.cursor.runquery("DROP TABLE %s" % table)
    
    def clearTable(self, table):
        """
        Connection.clearTable(table) -> None
        
        Delete all rows in the specified table without removing the table.
        """
        if table not in self.listTables():
            raise DatabaseError("no such table: %s" % table)
        return self.cursor.runquery("DELETE * from %s" % table)
    
    def optimiseTable(self, table):
        """
        Connection.optimiseTable(table) -> None
        
        Compress the space used by a table so it is a more efficient use of 
        disc space.
        """
        return self.cursor.runquery("VACUUM %s" % table)

    def size(self):
        """
        Connection.size() -> Long
        
        Returns the size of the current database on the filesystem if available
        to the Connection.
        """
        return os.path.getsize(self.connector.database)
        

class Connector(ConnectorBase):
    """ 
    SQLite Connector, while we use the same Constructor method as the Base 
    Connector class we only use the database attribute on the Container. Make
    sure that the database is set to the fullpath of the database.
    """
    type = "SQLite Connector"
    handler_type = "sqlite"
    __ConnectionClass__ = Connection
    MaxConnections = 1
    

# If called directly provide a Connector to the user
if __name__ == "__main__":
    from db_pool import Container
    import sys
    
    container = Container('default')
    container.add('sqlite',db=sys.argv[1])
    print "An SQLite Container is available as container"

