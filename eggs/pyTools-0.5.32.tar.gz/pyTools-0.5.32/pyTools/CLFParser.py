"""
This module contains a parser for Common-Log-Format logfile. It has been 
extracted from pyManager's web_hosting service module for use elsewhere.

The parser is basically a generator over a file type object that returns rec-
ords one at a time as a dictionary.

$Id: CLFParser.py,v 1.7 2006/03/10 09:37:39 seoman Exp $
"""
__revision__ = "$Revision: 1.7 $"[11:-2]
 
import gzip, bz2, re, os, sys
from mx.DateTime import strptime, ISO


class ParserError(Exception):
    field = '<unknown>'
    def __init__(self, msg):
        self.msg = msg
    def __str__(self):
        etype, value, tb = sys.exc_info()
        method = tb.tb_next.tb_next.tb_frame.f_code.co_name
        return "%s on %s: %s" % (method, self.field, self.msg)


class Parser(object):
    """
    This class is used to parse a Common-Log-Formatted file into a Dictionary
    of key -> value pairs. It understands the LogFormat line used by Apache in
    its interpreting of the logfile. In general you should use this class as a
    replacement for openning the file, and iterate over this object to collect
    the data 1 Dictionary at a time. Thus:

        >>> from pyTools.CLFParser import Parser
        >>> parser = Parser('myfile.log')
        >>> for record in parser:
        ...   .
        ...   <save the record somewhere>
        >>> 

    You can, however, pass in a open file object. The parser uses a generator
    to step through the file 1 line at a time to minimise the memory hit.

    You should ensure the LogFormat attribute is set to the same as the Apache
    LogFormat config item.
    """
    _methods = (
        # standard methods
        'GET','POST','PUT','HEAD',    
        # methods used by webdav 
        'PROPFIND','PROPPATCH','COPY','MOVE','LOCK','UNLOCK','DELETE','MKCOL',
        # this is another webdav this to patch an existing doc using diff
        'PATCH',
        # is a MS butchery for searching a resource
        'SEARCH',
        # used for proxy connections
        'CONNECT',
        # diagnostic tool
        'TRACE',
        # returns server and/or resource options
        'OPTIONS',
    )

    _protocols = ('HTTP/1.0','HTTP/1.1')

    LogFormat = '%v %h %l %u %t "%r" %>s %b %{Referer}i %{User-agent}i'
    DateTimeFormat= "%d/%b/%Y:%H:%M:%S"

    __timeRe  = "(?<=%{)[abcABdHIjmMpSUwWxXYZ%-//: ]+(?=}t)"

    MaxErrors = 50
    
    __RecordClass__ = dict
    
    # this is the default mapping, it defines the possible fields in an Apache
    # style CLF logfile
    __format_map = {
        'h' : ('string', 'remote_host'),
        'a' : ('string', 'remote_ip'),
        'B' : ('number', 'bytes_sent'),
        'b' : ('number', 'bytes_sent'),
        'T' : ('number', 'time_taken'),
        'H' : ('string', 'protocol'),
        'm' : ('string', 'method'),
        'U' : ('string', 'url_path'),
        'q' : ('string', 'query_string'),
        'l' : ('string', 'remote_logname'),
        'u' : ('string', 'remote_user'),
        's' : ('string', 'status'),
        't' : ('isodate', 'datetime'),
        'v' : ('string', 'servername'),
        'r' : ('request', 'request'),
        'Referer': ('quoted', 'referer'),
        'User-agent': ('quoted', 'user_agent'),
        'Content-Type': ('quoted', 'content_type'),
    }

    def __init__(self, fileORname, _map=None):
        """ Constructor """
        if type(fileORname) == str:
            if not (os.path.exists(fileORname) and os.path.isfile(fileORname)):
                raise ValueError("Archive file doesn't exist: %s"%fileORname)
            if fileORname.endswith('.gz'):
                self.__fp = gzip.open(fileORname, 'r')
            elif fileORname.endswith('.bz2'):
                self.__fp = bz2.BZ2File(fileORname)
            else:
                self.__fp = open(fileORname, 'r')
        elif hasattr(fileORname,'readline') and \
             hasattr(fileORname.readline,'__call__'):
            self.__fp = fileORname
        else:
            raise TypeError("arg must be file or string object.")
        # Messages
        self.messages = []
        if _map is not None:
            self.setMapping(_map)
            
    def setMapping(self, _map):
        self.__format_map = _map
        # compile a regex from the _format_map
        letters, words = [], []
        for k in self.__format_map.keys():
            if len(k) == 1:
                letters.append(k)
            else:
                words.append(k)
        s = "(?<=[%>])["+''.join(letters)+"]"
        w = "(?<=%{)(?:"+'|'.join(words)+")(?=}[io])"
        self.__formatRe = re.compile("(%s|%s|%s)"%(s, w, self.__timeRe))

    file = property(lambda s:s.__fp)
    
    def getSet(self):
        """
        Returns a set of methods that should be called in the line in order to
        convert all the entries from the line. This is taken from the LogFormat
        and the args we are able to use.
        """
        set = []
        for x in self.__formatRe.findall(self.LogFormat):
            fieldtype, name = self.__format_map.get(x, (None, 'datetime')) 
            # a datetime that has a format will come back as None
            method = self.types[fieldtype]
            if method is None:
                self.TimeFormat = x
                method = self._date
            set.append((method,name))
        return set
    
    def getFields(self):
        """
        Returns the fields that are being parsed as a list.
        """
        fields = []
        for x in self.__formatRe.findall(self.LogFormat):
            method, name = self.__format_map.get(x, (None, 'datetime')) 
            fields.append(name)
        return fields
    
    def __iter__(self):
        """ Returns a generator for walking over the contents of file """
        self.messages = []
        steps = self.getSet()
        pos = self.__fp.tell()
        try:
            self.__fp.seek(0)
        except IOError:
            pass
        for no, line in enumerate(self.__fp):
            if len(line) == 0 or line[0] == '#':
                continue
            self.last_lineno = no
            self.last_line = line
            try:
                yield self.parse(line, steps)
            except ParserError,e:
                self.messages.append((no, str(e), line))
                if len(self.messages) == self.MaxErrors:
                    break
        self.__fp.seek(pos)
        return
    
    def parse(self, line, steps=None, retObj=None):
        """
        Parser.parse(line[, steps[, retObj]]) -> retObj or dict instance
        
        Takes a string of data representing a line in a CLF and converts it to
        a dictionary. The format of the line is fairly configurable, and by 
        default takes the form:

          %v %h %l %u %t "%r" %>s %b %{Referer}i %{User-agent}i

        a more recommended form is:
        
          %v %h %l %u %{[%Y-%m-%d %H:%M:%S]}t %U%q %m %H %>s %B %{Referer}i 
          %{User-agent}i %{Content-Type}o
        
        Which ever format used should be set in the 'LogFormat' attribute on
        this class prior to running.
        """
        # Some segments can have spaces and are quotes, such as referer, for 
        # this reason we can't just split and take the len.
        steps = steps or self.getSet()
        position, length = 0, len(line)
        if retObj is None:
            record = self.__RecordClass__()
        else:
            record = retObj()
        for method, field in steps:
            if position >= length:
                break
            try:
                position, data = method(position, line)
            except ParserError, exc:
                exc.field = field
                raise
            # if a dictionary is returned then multiple items need to be put
            # into the record
            if type(data) == dict:
                record.update(data)
            else:
                record[field] = data
        return record
    
    def __findPart(self, position, line, terminator):
        end = line[position:].find(terminator)
        if end == -1:
            return len(line), line[position:].strip()
        else:
            return end+position+1, line[position:position+end].strip()
    
    __requestRe = re.compile(r'"(?P<request>.*?)"(?: (?!HTTP)|$)')
    def _request(self, position, line):
        """
        Attempt to extract the Request out of the 'line' supplied returning the
        new position in the line and the Request raising an Error. The Request 
        segment is usually quoted and is made up of "method url protocol".
        """
        end,url_segment = self._quoted(position,line)
        # the request is often empty ('-') with status code 408
        if url_segment == '-':
            return end, {}
        parts = url_segment.split()
        if parts[0].upper() not in self._methods:
            raise ParserError("Unknown or unsupported method: %s"%parts[0])
        data = { 'method':parts[0].upper(), }
        if parts[-1] not in self._protocols:
            url = ' '.join(parts[1:])
        else:
            url = ' '.join(parts[1:-1])
            data['protocol'] = parts[-1]
        qry_pos = url.find('?')
        if qry_pos > -1:
            data['url_path'] = url[:qry_pos]
            data['query_string'] = url[qry_pos:]
        else:
            data['url_path'] = url
        return end, data
    
    def _string(self, position, line):
        """ 
        Return the next string after position until a whitespace character is
        encountered.
        """
        return self.__findPart(position,line,' ')

    def _longOrInt(self, position, line):
        end, iStr = self.__findPart(position,line,' ')
        try:
            return end, int(iStr)
        except ValueError:
            return end, 0
    
    __quotedRe = re.compile(r'(?<=(?<!\\)")(?P<str>.*?)(?=(?<!\\)"(?: |$))')
    def _quoted(self, position, line):
        """
        Returns the segment starting at position in line where the segment is a
        quoted string. The character at line[position] must be a ".
        """
        if line[position] not in ('-', '"',):
            raise ParserError("postion %d in line should be quoted."%position)
        if line[position:position+2] == '- ':
            return position+2, ''
        match = self.__quotedRe.search(line,position)
        if match is None:
            raise ParserError("failed to find matching at %d"%position)
        return match.end('str')+2, match.group('str')
    
    __dateTimeRe = re.compile("(?<=\[)(?P<dt>[\w/: \-]+)(?: \+\d{4})?(?=\])")
    __isoDateRe = re.compile(ISO._date + ' .*?')
    __isoTimeRe = re.compile(ISO._time + ' .*?')
    __isoDateTimeRe = re.compile(ISO._date + '(?:[ T]' + ISO._time + ')? .*?')

    def _date(self, position, line):
        """
        Collect a date from the line starting at the given position using ISO
        formatting standards. To use a custom format use the 'datetime' type.
        """
        match = self.__isoDateRe.match
        _is = match(line[position:])
        if _is is None:
            raise ParserError('failed to find ISO formatted Date.')
        return _is.end(), ISO.ParseDate(line[position:], match)
        
    def _time(self, position, line):
        """
        Collect a time from the line using the ISO standard format.
        """
        match = self.__isoTimeRe.match
        _is = match(line[position:])
        if _is is None:
            raise ParserError('failed to find ISO formatted Time.')
        return _is.end(), ISO.ParseTime(line[position:], match)
        
    def _isodate(self, position, line):
        match = self.__isoDateTimeRe.match
        _is = match(line[position:])
        if _is is None:
            raise ParserError('failed to find ISO formatted DateTime.')
        return _is.end(), ISO.ParseDateTime(line[position:], match)
    
    def _datetime(self, position, line):
        match = self.__dateTimeRe.search(line[position:])
        _is = match(line[position:])
        if _is is None:
            raise ParserError('failed to find a formatted DateTime string.')
        return _is.end()+2, strptime(line[position:], self.DateTimeFormat)
        
    def _get_types(self):
        return {
            'string': self._string,
            'number': self._longOrInt,
            'quoted': self._quoted,
            'date': self._date,
            'time': self._time,
            'datetime': self._datetime,
            'isodate': self._isodate,
            'request': self._request,
        }
    types = property(_get_types)


class Formatter(object):
    """
    This is the compliment of the Parser, it can be used to take records and
    format them in Common-Log-Format for placing in a logfile or processing 
    with such tools as ModLogan. Unlike the Parser it does not take a file to
    save the data to or where the records are retrieved from. Use it within 
    code to process each record, for example:
    
      >>> formatter = CLFParser.Formatter()
      >>> cursor = dbPool.run('webstats').getCursor()
      >>> for record in cursor.execute(Select('webstats')).__as_dict__():
      ...     print formatter.parse(record)
      >>>
    
    Like the Parser you can set the format of the output string using the same
    formatting as the CLF attributes by setting LogFormat on the instance. 
    """
    LogFormat  = '%v %h %l %u %t "%r" %>s %b %{Referer}i %{User-agent}i'
    TimeFormat = "%d/%b/%Y:%H:%M:%S +1000"
    __timeRe   = "(?<=%{)[abcABdHIjmMpSUwWxXYZ%-//: ]+(?=}t)"
    
    __formatRe = None
    def __get_format_re(self):
        if self.__formatRe is None:
            self.__formatRe = self.buildRe()
        return self.__formatRe
    formatRe = property(__get_format_re)
    
    def update_map(self, _map):
        """ Update the format map """
        self.__format_map.update(_map)
        self.__formatRe = None
    
    def buildRe(self):
        """ Build the regex from the format_map """
        letters,words = [],[]
        for k in self.__format_map.keys():
            if len(k) == 1:
                letters.append(k)
            else:
                words.append(k)
        s = "(?<=[%>])["+''.join(letters)+"]"
        w = "(?<=%{)(?:"+'|'.join(words)+")(?=}[io])"
        return re.compile("(%s|%s|%s)"%(s,w,self.__timeRe))
    
    def format(self, record):
        """
        Formatter.format(record) -> String
        
        Format a single record using the LogFormat into a CLF formatted string.
        """
        parts = []
        for x in self.formatRe.findall(self.LogFormat):
            bits = self.__format_map.get(x)
            if bits is None:
                self.TimeFormat = x
                bits = self.__format_map['t']
            args = [ record.get(x, '') for x in bits[1:] ]
            if type(bits[0]) == str:
                value = bits[0] % tuple(args)
            else:
                value = bits[0](self, *args)
            parts.append(value)
        return " ".join(parts)
    
    def _format_int(self, item):
        return "%d" % (item or 0)
    
    def _format_str(self, item):
        return "%s" % (item or '-')
    
    def _format_quoted(self, item):
        return '"%s"' % (item or "-")

    def _format_request(self, method, url_path, query_string, protocol):
        return '"%s %s%s %s"' % (method, url_path, query_string, protocol)
    
    def _format_date(self, datetime):
        return "[%s]" % datetime.strftime(self.TimeFormat)
        
    __format_map = {
        'h' : (_format_str,  'remote_host'),
        'a' : (_format_str,  'remote_ip'),
        'B' : (_format_int,  'bytes_sent'),
        'b' : (_format_str,  'bytes_sent'),
        'T' : (_format_int,  'time_taken'),
        'H' : (_format_str,  'protocol'),
        'm' : (_format_str,  'method'),
        'U' : (_format_str,  'url_path'),
        'q' : (_format_str,  'query_string'),
        'l' : (_format_str,  'remote_logname'),
        'u' : (_format_str,  'remote_user'),
        's' : (_format_str,  'status'),
        't' : (_format_date, 'datetime'),
        'v' : (_format_str,  'servername'),
        'r' : (_format_request,'method','url_path','query_string','protocol'),
        'Referer'       : (_format_quoted,'referer'),
        'User-agent'    : (_format_quoted,'user_agent'),
        'Content-Type'  : (_format_quoted,'content_type'),
    }

if __name__ == "__main__":
    from cStringIO import StringIO

