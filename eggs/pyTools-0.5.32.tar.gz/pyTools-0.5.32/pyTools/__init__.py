"""
This is a collection of tools that I have found usefull for a variety of python
based projects (duh!).

$Id: __init__.py,v 1.35 2006/06/29 01:47:49 seoman Exp $
"""
__revision__ = "$Revision: 1.35 $"[11:-2]

__version_info__= ( 0, 5, 32, )
__version__     = "%d.%d.%d" % __version_info__
__package__     = "pyTools"
__description__ = "Python Utility Tools"
__author__      = "Simon Hookway"
__author_email__= "simon@obsidian.com.au"
__url__         = "http://pytools.forge.obsidian.com.au"


class HardError(Exception): 
    """ Hard errors abort the current process run """


class SoftError(Exception): 
    """ Soft errors means that the current process should not abort """


class ErrorMetaClass(type):
    """
    This MetaClass looks for an Errors class attr and sets the Errors on the
    class for general access.
    """
    
    def __init__(cls, *args, **kwargs):
        """ Open-ended constructor """
        errors = getattr(cls, 'Errors', [])
        for err in errors:
            if not issubclass(err, Exception):
                raise Exception(
                    "error in Errors must be Exception subclass, got %s" %
                    err.__name__
                )
            else:
                setattr(cls, err.__name__, err)
        return
    
    
