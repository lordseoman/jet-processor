"""
This module adds property support to objects, this includes validator support.
We include the validator so that we have input/check/output filters. All you
have to do is mixin the PropertyAware class and you should be ready to go.

All properties have a mode, these modes determine how a property can be
manipulated. Mode are single character codes as such:
    
    w - writeable, this property can be updated.
    d - deleteable, this property can be deleted.
    r - required, this property is not allowed to be None/empty.
    h - hidden, this property is not present in displayMap.
    i - initial property value only, ie. only appears when object not setup.
    u - property is only shown when the object is setup.
    p - protected, this property should not be updated usually for backend use.

The mode is a string combination of these characters, eg:    
    
    uwr - property is not set at object creation time but is updatable after
          that and must be set to something.
          
    iwr - property only appears at object creation and must be supplied.

Then there are attributes for the dict in _properties:
    
  * type
    This is the type of this property, it can be either 'string', 'int', 'bool',
    'selection', 'multiple_selection', 'date' and 'date_string'.
    
  * id
    This is the name of the property.
    
  * label
    This is the label used when displaying the property, if it doesn't exist 
    then the id is used.
  
  * comment
    This is a comment displayed on the right of the property when editing this
    property through the metadata screen.
  
  * default
    This is a default value for this property, it will be displayed in the
    value field for the property when creating a new object.
  
  * input_filter
    This filter is used to convert a valid value (as determined by type 
    checking and validation) into a storable data item, for example, you might
    want to lower all strings entered. The input filter is the name of a 
    callable method either on the object or the value, such as lower on a 
    string.
    
        eg. 'input_filter': 'lower'

    If this method is on the object, then the method should be of the form
    _if_<name>, so if 'input_filter' is set to 'isDomain' then the method that
    will be called is _if_isDomain
    
  * validator
    This is a method used to validate a value for a property. The method search
    order is the value and then the object. There is no prefix for this call.
    
  * ouput_filter
    This filter converts the value for a property into a nicer format, usually
    for display purposes on the metadata page. For example, you might want to
    capitalise all strings. Like input_filter and validator, this is the name of
    a callable method either on the object or the value.
    
        eg. 'output_filter': 'capitalize'

    Similarly to input_filter there is a prefix when this is searched for on 
    the object; these methods should being with _of_
    

NOTES:
    
Validation is a checker to ensure that the value a property is being set to is
allowed, the simplest case is a selection type property (such as used to show
a dropdown) where the set is well defined. However, you can set a 'validator'
for a property which is a callable method that return True or False. The classic
validator is the 'valid_property_id' method in the code (this method is called 
by default, so don't actually use it).

An interesting example usage for all filters are dates. Consider you want a date
as a property, you want it changeable by the user. We could do this by using the
output filter to render a set of 3 dropdown's and the input filter to read the
dropdowns and convert them into a DateTime object. The validator could also use
the isFuture method on DateTime to ensure the date is valid.

$Id: PropertyManager.py,v 1.21 2006/04/27 05:16:15 seoman Exp $
"""
__revision__ = "$Revision: 1.21 $"[11:-2]

# System imports
from cgi import escape
from xml.dom import minidom
from mx.DateTime import DateTimeType,DateTimeDeltaType,ISO,DateTimeDeltaFrom
import types

# Local imports
from __init__ import HardError,SoftError


# type objects for property type definitions
class Selection(list):
    """
    This is a Selection property type, this is used when adding properties man-
    ually using the addProperty() method. You can treat this like a list by
    instanciating it with a list of possible values for your Selection property
    such as:

        value = Selection(['abc','bca','cba','cab','acb'])

    or if you want to use an attribute on the object:

        value = Selection('myProperty')

    In which case the object you attach this property to should have an attri-
    bute called "_sv_myProperty" which is a list or tuple. The PropertyAware
    class will also check the container for the attribute, or it might be a
    callable method:

        value = Selection('myProperty','some',5)

    In this instance the args ('some',5) will be passed to the named method 
    _sv_myProperty when it is called to collect the available values for the 
    property.
    """
    name = None

    def __init__(self, selection, *args):
        if type(selection) in (list,tuple):
            list.__init__(self,selection)
        elif type(selection) == str:
            list.__init__(self)
            self.__name = selection
            self.__args = args
        else:
            raise TypeError("first args should be a list or string.")

    def getSelectVariables(self):
        """ Returns the selection dict variables for PropertyAware """
        d = {}
        if len(self):
            return {'select_variable':tuple(self),}
        else:
            return {'select_variable':self.__name,'sv_data':self.__args,}

    def getValue(self):
        return self.__value

    def setValue(self, value):
        if type(value) in (list,tuple):
            raise TypeError("value of selection must be single type.")
        if len(self) and value not in self:
            raise ValidationError("%s is not valid for this property."%value)
        self.__value = value

    value = property(getValue,setValue,doc="Value of the selection.")


_select = Selection([])
SelectionType = type(_select)
del _select


class MultipleSelection(Selection):
    
    def setValue(self, value):
        if type(value) not in (list,tuple):
            raise TypeError("value of selection must be list/tuple type.")
        if len(self):
            notin = [ v for v in value if v not in self ]
            if notin:
                raise ValidationError(
                    "%s are not valid selections" % ','.join(notin)
                )
        self.__value = value
    
    value = property(Selection.getValue,setValue,doc="Value of the selection.")

_multiselect = MultipleSelection([])
MultiSelectType = type(_multiselect)
del _multiselect


# Converters are similar to dbPool converters, then attempt to 
class TypeChecker(dict):
    """
    This class is used by PropertyAware to convert incoming data values into
    the correct storable type. Web interfaces will often try to store values as
    strings (although Zope has type casting in its form submission).
    """
    encoding = None
    
    def __init__(self, *a, **kw):
        self.update({
            SelectionType     : self.Selection,
            MultiSelectType   : self.MultiSelect,
            DateTimeType      : self.DateTime,
            DateTimeDeltaType : self.DateTimeDelta,
            int               : self.Int,
            long              : self.Long,
            float             : self.Float,
            str               : self.Str,
            object            : self.Object,
            'datetime'        : self.DateTime,
            'timedelta'       : self.DateTimeDelta,
            'string'          : self.Str,
            'selection'       : self.Selection,
            'multi_select'    : self.MultiSelect,
            'float'           : self.Float,
            'long'            : self.Long,
            'int'             : self.Int,
            'lines'           : self.Str,
        })
        dict.__init__(self, *a, **kw)
    
    def _orNone(self, method, s):
        try:
            return method(s)
        except:
            return None
    
    def Date(self, value, p):
        if type(value) == DateTimeType:
            return value
        return self._orNone(ISO.ParseDate,value)
    
    def DateTime(self, value, p):
        if type(value) in (types.NoneType,DateTimeType):
            return value
        return self._orNone(ISO.ParseDateTime,value)

    def DateTimeDelta(self, value, p):
        if type(value) in (types.NoneType,DateTimeDeltaType):
            return value
        return self._orNone(DateTimeDeltaFrom,value)
    
    def Int(self, value, p):
        """ Convert something to an Int """
        try:
            return int(value)
        except ValueError:
            raise ValidationError("'%s' is not an Int or cannot be converter."%
                p.get('label','id')
            )
    
    def Long(self, value, p):
        try:
            return long(value)
        except ValueError:
            raise ValidationError("'%s' is not a Long or cannot be converter."%
                p.get('label','id')
            )
    
    def Float(self, value, p):
        try:
            return float(value)
        except ValueError:
            raise ValidationError("'%s' is not a float or cannot be converter."%
                p.get('label','id')
            )
    
    def Str(self, value, p):
        if type(value) != types.NoneType:
            value = str(value)
        return value
    
    def Object(self, value, p):
        return value
    
    def Selection(self, value, p):
        """ Is value in my list of available values """
        s = p['select_variable']
        if value in s:
            return value
        raise ValidationError("'%s' is not valid for '%s' selection." %
            (value,p.get('label','id'))
        )
    
    def MultiSelect(self, value, p):
        """ Is values in my list of available values """
        s = p['select_variable']
        if type(value) not in (list,tuple):
            value = (value,)
        notin = [ v for v in value if v not in s ]
        if notin:
            raise ValidationError("'%s' are not valid selections for '%s'." %
                ("','".join(notin),p.get('label','id'))
            )
        return value
        
 
class PropertyError(HardError):
    pass

class InvalidProperty(PropertyError): 
    pass

class NoSuchProperty(AttributeError,SoftError):  
    pass
    
class PropertyExists(AttributeError,SoftError):  
    pass
    
class MissingProperty(AttributeError,HardError):
    pass

class PropertyNotSet(AttributeError,HardError):
    pass
    
class NotAllowed(AttributeError,SoftError):
    pass
    
class BadPropertyType(TypeError,SoftError):
    pass

class BadProperty(PropertyError):
    pass
    
class ValidationError(SoftError):
    pass


class XMLPropertyMetaClass(type):
    """
    This metaclass is used to auto load properties from an XML config file into
    the class being loaded. Because it is a metaclass this is called when the
    class is being defined.

    Be sure to define __XML_FileName__ on the class.
    """
    def __init__(cls, *args):
        """
        Called when 'cls' is imported or loaded, we grab the config file from
        the class where it should be defined and load it. We populate the
        _properties attribute on 'cls' from the defined XML file.
        """
        if not hasattr(cls,'__XML_FileName__'):
            raise PropertyError("__XML_FileName__ is missing from class.")
        p = "%s.%s" % (cls.__module__,cls.__name__)
        xml = minidom.parse(cls.__XML_FileName__)
        for node in xml.documentElement.getElementsByTagName('class'):
            path = node.getAttribute('path')
            if path == p:
                a = ()
                for prop in node.getElementsByTagName('property'):
                    a+=(dict([(k,str(v)) for k,v in prop.attributes.items()]),)
                cls._properties += a 


class _PropertyAware:
    """ Base for Dict and Object based PropertyAware types """
    
    Errors = (
        ValidationError,
        BadProperty,
        NoSuchProperty,
        PropertyExists,
        InvalidProperty,
        PropertyError,
        BadPropertyType,
        MissingProperty,
        NotAllowed,
        PropertyNotSet,
    )
    
    _properties = ()
    
    converters = TypeChecker()
    
    # This flags whether this object is setup, after setup 'i' mode properties
    # cannot be edited.
    __isSetup = False
    #
    # Use this method to set the object as setup, this is often called in an
    # afterAdd method.
    #
    def _pm_beforeUpdate(self):
        """ check this object is valid """
        try:
            self.is_valid()
        except PropertyNotSet,e:
            raise ValidationError("object is invalid or incomplete: %s." % e)
        
    def _pm_afterAdd(self, parent):
        """ sets this object as setup, means 'i' mode props cannot be edited """
        if self.__isSetup is False:
            self.__isSetup = True
    
    def valid_property_id(self, _id):
        """ Returns True for a valid property id """
        if not _id or _id.startswith('_') or (' ' in _id) or \
            escape(_id) != _id or _id.startswith('aq_') or hasattr(self, _id):
            return False
        return True

    def is_valid(self):
        """
        O.is_valid() -> True/False
        
        Determines whether this object is valid property-wise. If required
        properties are missing values then False is returned. Doesn't check the
        actual values for the properties as this was done when they were set.
        """
        for _id in self.getRequiredProperties():
            try:
                self._pm_getPropValue(_id)
            except PropertyNotSet:
                p = self._pm_propertyDict(_id)
                if 'default' in p:
                    self._setProperty(_id, p['default'])
                else:
                    raise
        return True
    #
    # Internal hooks to the filters
    #
    def __findMethod(self, prefix, methodName, value):
        """
        Internal method to find a method/attribute on value, self or container
        in that order. We return the method/attribute without calling it.
        """
        if not methodName:
            return 
        method = getattr(value, methodName, None)
        if method is None:
            method = getattr(self, prefix+methodName, None)
        if method is None:
            method = getattr(self, methodName, None)
        if method is None:
            raise PropertyError("%s method defined but not found." % methodName)
        return method
    
    def _pm_getInputFilter(self, _id, value, p=None):
        """ Returns the input filter for a property """
        p = p or self._pm_propertyDict(_id)
        return self.__findMethod('_if_',p.get('input_filter'), value)
    
    def _pm_getOutputFilter(self, _id, value, p=None):
        """ Return the output filter for a property """
        p = p or self._pm_propertyDict(_id)
        return self.__findMethod('_of_', p.get('output_filter'), value)

    def _pm_checkFilter(self, _id, value, p=None):
        """ Run the property value through the checker/validation filter """
        p = p or self._pm_propertyDict(_id)
        methodName = p.get('validator')
        if methodName:
            if methodName.startswith('not:'):
                method = lambda x,y=value: not x(y)
                methodName = methodName[4:]
            else:
                method = lambda x,y=value: x(y)
            return method(self.__findMethod('_cf_', methodName, value))
        return True
    
    def _pm_expandSelection(self, p):
        """ 
        This method updates p (so pass it a copy) expanding the attribute
        'select_variable' in p to be a tuple of valid selections for this
        property.
        
        The 'select_variable' can be a list, tuple, Selection or Multiple-
        Selection (in which case it is returned as is) or a string that is the
        name of a callable method on container (or this object) called to 
        return a list or tuple of values. 'select_variable' can also be an att-
        ribute on container or self also.

        Finally, the 'sv_data' is an object passed to the 'select_variable'
        method when called.
        """
        sv = p.get('select_variable')
        if sv:
            if type(sv) == str:
                method = self.__findMethod('_sv_', sv, None)
                if hasattr(method, '__call__'):
                    sv = method(p.get('sv_data'))
                else:
                    sv = method
            if type(sv) not in (SelectionType,MultiSelectType,list,tuple):
                raise BadPropertyType("select_variable on %s is incorrect." %
                    p['id']
                )
            p['select_variable'] = sv
        return p
    #
    # Internal methods, should not be called outside of this object
    #
    def _pm_propertyMap(self):
        """ Internal method to return the properties """
        return self._properties

    def _pm_propertyDict(self, _id):
        """ Return a raw dictionary copy for a given property """
        for p in self._pm_propertyMap():
            if p['id'] == _id:
                return p.copy()
        return None

    def _pm_getPropValue(self, _id):
        """ Actually get the property value """
        raise NotImplementedError("This method has not been defined.")
    
    def _pm_setPropValue(self, _id, value):
        """ Actually set/add the prop _id """
        raise NotImplementedError("This method has not been defined.")
    
    def _pm_delPropValue(self, _id):
        """ Actually delete the property """
        raise NotImplementedError("This method has not been defined.")
    
    def _pm_addProperty(self, _id, value, mode='h', label=''):
        """ 
        This is the underlying addProperty method, all checking should be done
        by the addProperty() accessor method.
        """
        p = {'id': _id, 'type': type(value), 'mode': mode}
        if label: 
            p['label'] = label
        if type(value) in (SelectionType, MultiSelectType):
            p.update(value.getSelectVariables())
            value = value.getValue()
        self._properties = self._properties + (p,)
        self._pm_setPropValue(_id, value)
        return

    def _pm_delProperty(self, _id):
        """
        Delete a property from being managed. This might be dangerous 
        depending on the backend your using to hold property/object values.
        """
        self._pm_delPropValue(_id)
        retVal = {}
        s = ()
        for p in self._properties:
            if p['id'] != _id:
                s += (p,)
            else:
                retVal = p
        self._properties = s
        return retVal

    def _pm_setPropertyMode(self, _id, mode):
        s = ()
        for p in self._properties:
            if p['id'] == _id:
                p = p.copy()
                p['mode'] = mode
            s += (p,)
        self._properties = s

    def _pm_setProperty(self, _id, value):
        """ 
        Update / Set a properties value. We run the value through the input 
        filter iff this property has an input filter. The value is run through
        the type converters prior to calling _pm_setPropValue.
        """
        # then through the input filter
        inputFilter = self._pm_getInputFilter(_id,value)
        if inputFilter is not None:
            value = inputFilter(value)
        # now call the deep-end set method
        self._pm_setPropValue(_id, value)
        return

    def _pm_checkProperty(self, _id, value, p=None):
        """
        Check a property value is correct, this is the guts. Since we are here
        then this property must exist. We return the value as presented by the
        type converter.
        """
        p = p or self._pm_expandSelection(self._pm_propertyDict(_id))
        value = self.converters[p.get('type') or str](value,p)
        # Do validator checking
        if not self._pm_checkFilter(_id, value, p):
            raise ValidationError(
                "'%s' is not a valid value for '%s'"%(value,p.get('label','id'))
            )
        return value
    #
    # Public methods
    #
    def propertyMap(self):
        """ 
        Returns a copy of the property map on this object. We need to do some
        tinkering to expand the 'select_variable' options if needed.
        """
        ret = []
        for p in self._pm_propertyMap():
            ret.append(self._pm_expandSelection(p.copy()))
        return ret
        
    def propertyNames(self):
        """ Returns a list of the names for all managed properties """
        return map(lambda p: p['id'], self._pm_propertyMap())
        
    def propertyValues(self):
        """ Returns a list of the (name,value) for all managed properties """
        return [ (n, self.getProperty(n)) for n in self.propertyNames() ]

    def getPropertyDict(self, _id):
        """ Returns a copy of the property dict for a single property """
        for p in self.propertyMap():
            if p['id'] == _id:
                return p
        raise NoSuchProperty("No such property (%s)" % _id)

    def getPropertyType(self, _id):
        """ Returns the type of this property """
        return self.getPropertyDict(_id).get('type','string')

    def setPropertyMode(self, _id, mode):
        """ Overrides the mode completely with the supplied mode """
        if not self.hasProperty(_id):
            raise NoSuchProperty("No such property: %s" % _id)
        self._pm_setPropertyMode(_id, mode)
    
    def setPropertyReadonly(self, _id):
        """ Set this property to readonly """
        mode = self.getPropertyMode(_id).replace('w','')
        self._pm_setPropertyMode(_id, mode)
        
    def setPropertyWriteable(self, _id):
        """ Set this property to writeable """
        mode = self.getPropertyMode(_id)
        if 'w' not in mode:
            mode += 'w'
        self._pm_setPropertyMode(_id, mode)
    
    def getPropertyMode(self, _id):
        """ Returns the mode string for a given property """
        return self.getPropertyDict(_id).get('mode','')

    def getPropertyLabel(self, _id):
        """ Returns the label for this property or the id if no label """
        return self.getPropertyDict(_id).get('label',_id)
        
    def hasProperty(self, _id):
        """ 
        Returns True iff this object has a property of this id, this does not
        mean that this property is not an attribute on this object, but that
        it isn't a managed property.
        """
        return _id in self.propertyNames()

    def getProperty(self, _id, *d):
        """ 
        Returns the value for this property, will return the 'default' is 
        supplied or raises an attribute error
        """
        if self.hasProperty(_id):
            try:
                return self._pm_getPropValue(_id)
            except PropertyNotSet:
                return self.getPropertyDict(_id).get('default')
        if len(d):
            return d[0]
        raise NoSuchProperty("No such property (%s)" % _id)

    def getRequiredProperties(self):
        """ Returns a list of required property names """
        ret = []
        for p in self._pm_propertyMap():
            if 'r' in p.get('mode',''):
                if self.__isSetup is True and 'i' in p.get('mode',''):
                    continue
                if self.__isSetup is False and 'u' in p.get('mode',''):
                    continue
                ret.append(p['id'])
        return ret

    def _setProperty(self, _id, value):
        """
        Internal version of the updateProperty method, this version should be
        used where checks are not wanted. We do raise NoSuchProperty if the 
        property doesn't exist however.
        """
        if not self.hasProperty(_id):
            raise NoSuchProperty("No such property: %s" % _id)
        # run the value through the converter first
        p = self._pm_expandSelection(self._pm_propertyDict(_id))
        value = self.converters[p.get('type') or str](value,p)
        return self._pm_setProperty(_id,value)

    def setProperty(self, _id, value):
        """ 
        Update a managed property, runs a checkProperty first, this is an
        example of what updateProperty should do and is expected to be over-
        riden for normal use. Note that checkProperty does a exists type check
        so we don't need to do a hasProperty check first.
        """
        if not self.hasProperty(_id):
            raise NoSuchProperty("No such property: %s" % _id)
        p = self._pm_expandSelection(self._pm_propertyDict(_id))
        if 'w' not in p.get('mode',''):
            raise NotAllowed("'%s' is not a writeable property." % _id)
        if self.__isSetup is True  and 'i' in p.get('mode', ''):
            raise NotAllowed("'%s' is only writeable at initial creation."%_id)
        if self.__isSetup is False and 'u' in p.get('mode', ''):
            raise NotAllowed("'%s' can only be edited after initial setup."%_id)
        value = self._pm_checkProperty(_id, value, p)
        return self._pm_setProperty(_id, value)
        
    def updateProperties(self, **props):
        """ 
        This is an ease of use method to allow passing of multiple properties
        updating all of them in one go. Its a little more than just a wrapper
        around update property as we simply skip invalid properties by catching
        the errors. This includes skipping items in the dict that are not props
        on this object.
        
        Also, if __isSetup is False then we set properties not in props using
        the defaults. Normally, the defaults are used for displaying values for
        properties on object in a creation page/screen. In these cases the 
        default value if left unchanged will be in props anyway.
        """
        errors = []
        for p in self.propertyMap():
            if p['id'] in props:
                try:
                    self.setProperty(p['id'],props[p['id']])
                except SoftError,details:
                    errors.append(details)
            elif self.__isSetup is False:
                self.setProperty(p['id'],p.get('default'))
        return errors

    def checkProperty(self, _id, value):
        """ 
        Checks a property value is valid for this property without setting it.
        This is done prior to set by the updateProperty() method, but can be 
        called individually too.
        """
        if not self.hasProperty(_id):
            raise NoSuchProperty("No such property: %s" % _id)
        return self._pm_checkProperty(_id,value)

    def checkProperties(self, **kwargs):
        """ 
        Validate a dictionary of arguements for this object, each key is the 
        name for property to be verified. Unlike checkProperty (which checks
        single properties) we also make sure that missing but required 
        properties exist in the kwargs, producing a HardError if a required 
        property is missing.
        """
        errors = []
        for p in self.propertyMap():
            if 'r' in p['mode'] and p['id'] not in kwargs:
                raise MissingProperty("Required property '%s' doesn't exist."%
                    pName
                )
            if p['id'] not in kwargs:
                continue
            try:
                self._pm_checkProperty(p['id'],kwargs[p['id']])
            except SoftError, details:
                errors.append(details)
        return errors

    def addProperty(self, _id, value, mode='h', label=''):
        """ 
        Add a property to this object as a managed property, we do checks on the
        id for the property and to ensure it doesn't already exist. 
        """
        if self.hasProperty(_id):
            raise PropertyExists("'%s' exists, use updateProperty instead"%_id)
        if not self.valid_property_id(_id):
            raise InvalidProperty('Invalid or duplicate property id "%s"'%_id)
        if type(value) not in self.converters.keys():
            raise BadPropertyType("%s is not a valid property type."%type(value))
        return self._pm_addProperty(_id,value,mode,label)
        
    def _delProperty(self, _id):
        """
        Internal manager method to delete a property whether the management 
        rules allow it or not. This is the business end of the delProperty
        method minus the checks.
        """
        if not self.hasProperty(_id):
            raise NoSuchProperty("No such property: %s" % _id)
        return self._pm_delProperty(_id)
        
    def delProperty(self, _id):
        """ Delete a property, returns the propMap for this prop """
        p = self.getPropertyDict(_id)
        if 'd' not in p.get('mode',''):
            raise NotAllowed("'%s' is not a deletable property." % _id)
        return self._pm_delProperty(_id)
    #
    # Display property method (ie. non-hidden properties)
    #
    def displayPropertyNames(self):
        """ Returns a list of non-hidden property names """
        retList = []
        for p in self._pm_propertyMap():
            if 'h' in p.get('mode',''):
                continue
            # skip properties only shown in the creation metadata
            if self.__isSetup is True  and 'i' in p.get('mode',''):
                continue
            # skip properties only shown on setup objects
            if self.__isSetup is False and 'u' in p.get('mode',''):
                continue
            # add rest
            retList.append(p['id'])
        return retList
        
    def displayPropertyMap(self):
        """
        Returns a list of displayable properties (such as title), this is used
        for non-manage interface use and is controlled by the 'h' character in
        the mode.
        """
        ret = ()
        for p in self._pm_propertyMap():
            if 'h' not in p.get('mode',''):
                data = self._pm_expandSelection(p.copy())
                if p.has_key('default') and self.converters.has_key(p['type']):
                    data['default'] = self.converters[p['type']](p['default'])
                data['value'] = self.getProperty(p['id'],p.get('default'))
                of = self._pm_getOutputFilter(p['id'], data['value'], p)
                if of and 'select_variable' in data:
                    data['select_variable'] = of(data['select_variable'])
                elif of:
                    data['value'] = of(data['value'])
                ret += (data,)
        return ret
        
    def canEditProperty(self, _id):
        """ Returns True iff property is not readonly """
        p = self.getPropertyDict(_id)
        if 'w' not in p.get('mode','') or 'h' in p.get('mode',''):
            return False
        return True
    

class PropertyAware(_PropertyAware,object):
    """
    Make an object PropertyAware so that checks are done whenever setting the
    property and input/output filters can be used whenever collecting a
    property.
    
    This Mixin is for Object like Property Management.
    """
    def _pm_getPropValue(self, _id):
        """ Returns the value of this property """
        try:
            return object.__getattribute__(self, _id)
        except AttributeError:
            raise PropertyNotSet("%s is not set" % _id)
    
    def _pm_setPropValue(self, _id, value):
        """ 
        Sets the actual property value, just a setattr wrapper. This is useful
        if you want to override where properties are stored. For example to 
        have the properties update a backend datasource on the fly then you
        can override this method.
        """
        return object.__setattr__(self, _id, value)
    
    def _pm_delPropValue(self, _id):
        """
        Removes a properties value, which again is just a wrapper around 
        delattr. You can however override this to provide availability for
        removing properties to a backend datasource.
        """
        return object.__delattr__(self, _id)
    #
    # Getattr will work by default, however we override setattr and delattr
    # so that setting and deleting follow property rules.
    #
    def __setattr__(self, name, value):
        """ Allow setattr to set properties """
        if self.hasProperty(name):
            self.setProperty(name,value)
        else:
            object.__setattr__(self,name,value)
    
    def __delattr__(self, name):
        if self.hasProperty(name):
            self.delProperty(name)
        else:
            object.__delattr__(self,name)    

        
class PropertyDictAware(_PropertyAware,dict):
    """
    Make an object PropertyAware so that checks are done whenever setting the
    property and input/output filters can be used whenever collecting a
    property.
    
    This Mixin is for dictionary like Property Management.
    """
    def _pm_getPropValue(self, _id):
        """ Returns the value of this property """
        try:
            return dict.__getitem__(self, _id)
        except KeyError:
            raise PropertyNotSet("%s is not set" % _id)

    def _pm_setPropValue(self, _id, value):
        """ Sets the value of the property in the dict """
        return dict.__setitem__(self, _id, value)

    def _pm_delPropValue(self, _id):
        """ Remove the property from the dict """
        return dict.__delitem__(self,_id)
    #
    # Override the dict accessor methods, which will (in this instance) fall
    # back to using setPropValue and delPropValue, which in turn just do the
    # standard dict methods. But it allows extension just by overriding the
    # aformentioned methods. This is important since it means x['fred'] = 4
    # will actuall use setProperty() which means normal checking is done.
    #
    def __getitem__(self, name):
        """ p[name] -> getProperty """
        return self.getProperty(name)
    
    def __setitem__(self, name, value):
        """ set/add a property using dict method """
        return self.setProperty(name,value)
        
    def __delitem__(self, name):
        """ delete a property using dict method """
        return self.delProperty(name)
        

__all__ = [
    'Selection','SelectionType','MultipleSelection','MultiSelectType',
    'PropertyAware','PropertyDictAware','XMLPropertyMetaClass',
]

if __name__ == '__main__':
    import sys
    class A(PropertyDictAware):
        __metaclass__ = XMLPropertyMetaClass
        __XML_FileName__ = sys.argv[1]

    
