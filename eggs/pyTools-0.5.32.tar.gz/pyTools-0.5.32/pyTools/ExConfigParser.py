"""
This is an Extension Class for the ConfigParser module.

Invoke this instead of the ConfigParser module and use as you would the
configparser.

$Id: ExConfigParser.py,v 1.7 2005/11/13 03:06:11 seoman Exp $
"""

__revision__ = '$Revision: 1.7 $'[11:-2]

from ConfigParser import ConfigParser
import StringIO,types

class ExConfigParser(ConfigParser):
    """
    Holds the Navigation Configuration attributes
    """
    __variables = {}

    def __init__(self, files=None, ro=False, defaults=None, vars=None):
        """
        Send a list of files to be read during a load.
        """
        ConfigParser.__init__(self, defaults)
        if type(vars) == dict:
            self.__variables = vars
        if files and type(files) == types.StringType:
            self.files = [files]
        elif type(files) in (types.ListType, types.TupleType):
            self.files = files
        else:
            self.files = None
        self.readonly = False
        if ro:
            self.readonly = True

    def load(self):
        """
        Returns the navigation configuration directives, after reading the, 
        from the config file. If you want to access the last read config file 
        then use navConfig instead.
        """
        for file in self.files:
            self.read(file)
       
    def save(self):
        """
        Writes the navigation configuration to file.
        """
        if not self.readonly and self.files:
            fp = open(self.files[-1], 'w')
            self.write(fp)
            fp.close()
        return
      
    def loads(self,strText):
        """
        Loads config from a string.
        """
        if type(strText) not in types.StringTypes:
            return
        fp = StringIO.StringIO(strText)
        self.readfp(fp)
        return
      
    def options(self, section, all=0):
        """
        Returns a list of the option names in this section, or a dict of option
        name and option value if all=1, or an empty list if there is no such
        section.
        """
        if not self.has_section(section):
            retVal = []
        elif not all:
            retVal = ConfigParser.options(self, section)
        else:
            data = {}
            for option in ConfigParser.options(self, section):
                data[option] = self.get(section, option)
            retVal = data
        return retVal
        
    def items(self, section, raw, *vars):
        """ Wrap the original items to use our options """
        if not self.has_option(section):
            return []
        elif raw:
            return ConfigParser.items(self,section,raw,*vars)
        else:
            return self.options(section,1).items()
     
    def set(self, section, name, value, setType=True):
        """
        Sets a option in a section, creating the section if it doesn't exit
        and setting the appropriate type.
        """
        if not self.has_section(section):
            self.add_section(section)
        if setType:
            if type(value) == types.ListType:
                value = "list:%s" % ','.join(value)
            elif type(value) == types.TupleType:
                value = "tuple:%s" % ','.join(value)
            elif type(value) == types.IntType:
                value = "int:%d" % value
            elif type(value) == types.LongType:
                value = "long:%ld" % value
            elif type(value) == types.FloatType:
                value = "float:%f" % value
            elif type(value) == bool:
                value = "boolean:%s" % (value and "Yes" or "No")
        ConfigParser.set(self, section, name, value)
        return
    
    def get(self,section,name,default=None,refresh=False,raw=False,vars=None):
        """
        Returns a simple config.get except that if refresh is set the the config
        file is re-read first. Also note that default is returned if the option
        doesn't exist instead of raising errors.

        'raw' can be used to return the un-interpolated value of the _name_
        option. 'vars' is a dict of mappings used for interpolation along with
        the defaults pass in at construction.
        """
        value = None
        if refresh:
            self.load()
        if name in ConfigParser.options(self, section):
            optType = None
            if vars and type(vars) == dict:
                vars.update(self.__variables.copy())
            else:
                vars = self.__variables
            value = ConfigParser.get(self, section, name, raw, vars)
            position = value.find(':')
            if position > -1:
                optType = value[:position]
                value   = value[position+1:]
                
            if not optType:
                pass
            elif optType == 'int':
                value = int(value)
            elif optType == 'long':
                value = long(value)
            elif optType == 'float':
                value = float(value)
            elif optType == 'boolean':
                if value.lower() in ('yes','1','true','on'):
                    value = True
                else:
                    value = False
            elif optType in ('list','tuple'):
                value = value.split(',')
                if value and value[0] == '':
                    value = value[1:]
                if optType == 'tuple':
                    value = tuple(value)
            else:
                value = "%s:%s" % (optType,value)
            
            if value is not None:
                return value
        
        return default

    def dump(self):
        """
        Returns a string representation of the current config that can be
        printed.
        """
        output = StringIO.StringIO()
        self.write(output)
        return output.getvalue()
        
