#!/usr/bin/python
"""
This is a new setuptools style distutils installation file.

It is no longer used to install (usually) but to create eggs and rpm
distribution files and from dpkg-buildpackage to make a .deb file.

$Id$
"""

def download_ez_setup(url=None):
    """
    Get the ez_setup script from the Peak site.
    """
    url = url or ez_setup_url
    print "Downloading ez_setup.py from %s" % url
    import urllib2
    data = urllib2.urlopen(url + 'ez_setup.py')
    ofd = open('ez_setup.py', 'wb')
    ofd.write(data.read())
    ofd.close()

#try:
#    from setuptools import setup
#except ImportError:
#    download_ez_setup()
#    from ez_setup import use_setuptools
#    use_setuptools()
#    from setuptools import setup
from setuptools import setup

requirements = [req.strip()
    for req in open('eggs/pip_req.txt', 'r').readlines()]
requirements.remove('Jet')

if __name__ == '__main__':
    setup(
        name='Jet', 
        version=open('version.txt', 'r').read().strip(),
        description='Jet Billing System',
        author='Obsidian Consulting Group',
        author_email='support@obsidian.com.au',
        url='http://jet.obsidian.com.au/', 
        packages=('Jet',),
        package_dir={'Jet': 'site',},
        package_data={ 'Jet': ['../etc/jet.cfg',], },
        scripts=['bin/jetctl.py',],
        install_requires=requirements,
        zip_safe=False,
    )
