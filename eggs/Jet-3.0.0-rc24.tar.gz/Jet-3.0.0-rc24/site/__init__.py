"""
This is the Jet base installer package.

$Id$
"""
__revision__ = "$Revision: $"[11:-2]

from ConfigParser import ConfigParser, NoSectionError, NoOptionError
import os
import pwd
import locale
try:
    # This is a monkey patch to replace decimal with cdecimal.
    # We should probably ban "from decimal import" if we're going to
    # move forward with this...
    import cdecimal
    from cdecimal import Decimal
    import sys
    sys.modules['decimal'] = cdecimal
    if 'Decimal' in globals():
        globals()['Decimal'] = cdecimal.Decimal
    if 'InvalidOperation' in globals():
        globals()['InvalidOperation'] = cdecimal.InvalidOperation
except ImportError:
    from decimal import Decimal

import license


# Some constants used for currency rounding so we are not constantly 
# creating decimals used to quantize values.
zero2dp = Decimal('0.00')
zero3dp = Decimal('0.000')
zero4dp = Decimal('0.0000')
zero5dp = Decimal('0.00000')
zero6dp = Decimal('0.000000')


def getControllerConfig():
    """
    This is a helper to collect the config from this Egg.
    
    :Returns:
        - a ConfigParser instance loaded with the installation cfg.
    """
    from pkg_resources import resource_filename, Requirement
    filename = resource_filename(Requirement.parse('Jet'), 'etc/jet.cfg')
    cfg = ConfigParser()
    cfg.read(filename)
    return cfg

def getJetCfg():
    """
    Get the .jetrc file.
    
    This file contains the config for each Jet checkout, which will be used by
    the jetctl add-checkout, jetctl make-default and so on for managing Jet
    checkouts and realms.
    """
    homedir = pwd.getpwnam('jet').pw_dir
    cfg = ConfigParser()
    rcfilename = os.path.join(homedir, '.jetrc')
    # if the file exists use it
    if os.path.exists(rcfilename):
        cfg.read(rcfilename)
    # but fall back to pointing to ~jet/Jet
    else:
        cfg.add_section('main')
        cfg.set('main', 'current_jet', os.path.join(homedir, 'Jet'))
        cfg.set('main', 'homedir', homedir)
    # tack this on the object to all better saving
    cfg._filename = rcfilename
    return cfg
    
def addCheckout(client, branch):
    """
    Add the checkout location.
    """
    cfg = getJetCfg()
    section = client + '_' + branch
    checkout_dir = os.path.join(cfg.get('main', 'homedir'), section)
    if not os.path.exists(checkout_dir):
        raise ValueError("checkout doesn't exist.")
    if cfg.has_section(section):
        print "checkout exists, replacing."
        cfg.remove_section(section)
    cfg.add_section(section)
    cfg.set(section, 'checkout_dir', checkout_dir)
    ofp = open(cfg._filename, 'w')
    cfg.write(ofp)
    ofp.close()

def getVersion():
    """
    Get the version of Jet installed.
    """
    import pkg_resources
    return pkg_resources.get_distribution('jet').version

__version__ = getVersion()

def isInstalled():
    """
    Is Jet installed? This requires at least 1 checkout.
    """
    base = getJetCfg().get('main', 'current_jet')
    return os.path.exists(os.path.join(base, '.bzr'))

def iter_modules():
    """
    Return each module provided by this install, modules are license controlled
    and the license will be accessed through the Jet egg.
    """
    base = getInstallLocation()
    if not os.path.exists(base):
        raise IOError('Jet has not finished being installed yet.')
    for modname in modules():
        try:
            module = __import__('modules.%s' % modname, {}, {}, [''])
        except ImportError:
            continue
        yield module
        
def getModule(name):
    """
    Collect a specific module, this is license controlled.
    """
    if name in modules():
        try:
            return __import__('modules.%s' % name, {}, {}, [''])
        except ImportError:
            pass
    raise AttributeError('no such module available: %s' % name)

def modules():
    """
    Return a list of available module names.
    """
    base = getInstallLocation()
    if not os.path.exists(base):
        raise IOError('Jet has not finished being installed yet.')
    import config
    lic = license.License()
    retList = []
    for modname in lic.options('modules'):
        try:
            if config.getboolean(modname, 'enabled'):
                retList.append(modname)
        except (NoSectionError, NoOptionError), exc:
            continue
    return retList

def getInstallLocation():
    """
    Return the home directory of the bzr checkout.
    """
    return getJetCfg().get('main', 'current_jet').strip()

def getServiceNames():
    """
    Return a list of modules defined as runnable services.
    """
    services = []
    # get the list of modules first, this will raise on error
    try:
        modnames = modules()
        import config
        for modname in modnames:
            try:
                sername = config.get(modname, 'runable_service').strip()
                enabled = config.getboolean(modname, 'enabled')   
                if sername and enabled:
                    services.append(sername)
            except (NoSectionError, NoOptionError), exc:
                continue
    except IOError:
        pass
    return services

def setupLocale(lang, country_code):
    import config
    from bin import jetExceptions
    loc = '%s_%s' % (lang, country_code.upper())
    try:
        locale.setlocale(locale.LC_ALL, loc)
    except locale.Error, exc:
        raise jetExceptions.ConfigurationError(
            'Invalid language and/or country code: lang=%s, cc=%s' %
            (lang, country_code)
        )


import sys
install_dir = getInstallLocation()
if install_dir not in sys.path:
    sys.path.append(install_dir)

