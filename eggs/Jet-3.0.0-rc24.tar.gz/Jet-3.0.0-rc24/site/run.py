#!/usr/bin/env python

import sys
import builtins, command

def run_command(argv):
    """
    Execute a command.
    
    :Parameters:
        - `argv` these are the command-line arguments including the command to
          be run if needed.
    """
    if not argv or argv[0] == '--help':
        cmd = command.get_cmd_object('help')
        cmd([])
        return 0
    if argv[0] == '--version':
        cmd = command.get_cmd_object('version')
        cmd([])
        return 0
    try:
        user_encoding = command.get_encoding()
        argv = [ a.decode(user_encoding) for a in argv ]
    except UnicodeDecodeError:
        raise ValueError(
            "Parameter '%r' is unsupported by the current encoding." % a
        )
    cmd = argv.pop(0)
    cmd_obj = command.get_cmd_object(cmd)
    result = cmd_obj(argv)
    return result or 0
    

if __name__ == '__main__':
    sys.exit(run_command(sys.argv[1:]))
