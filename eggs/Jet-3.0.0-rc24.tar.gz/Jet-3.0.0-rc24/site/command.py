#!/usr/bin/python
"""
This is the backup script which dumps the database to a file.

This script should be used with caution as the backup process locks tables
by default and this will cause intermittent outages within Jet. If table locks
are not used then inconsistent data may result.

As a result this script is designed to be used on a secondary where the table
locks will not cause a problem and the slave will catch up. If a redundancy 
module was not purchased then a backup service can be purchased instead that
will mirror the database to Obsidian's servers, however this will not include
the usage data and will also cost for bandwidth.
"""

import sys
import codecs
from warnings import warn

import Jet
import option


def _squish_command_name(cmd):
    return 'cmd_' + cmd.replace('-', '_')

def _unsquish_command_name(cmd):
    if cmd.startswith('cmd_'):
        return cmd[4:].replace('_','-')
    else:
        return ''


class CommandRegistra(type):
    """
    Metaclass for registering commands.
    """
    def __init__(cls, *args):
        """
        Register the Command
        """
        name = cls._get_name()
        if not name:
            pass
        elif name in cls.__Commands__:
            raise ValueError('Command already exists; %s' % cls.name)
        else:
            cls.__Commands__[name] = cls
                

class Command(object):
    """
    This is the base Command class for Jet controller commands.
    """
    __metaclass__ = CommandRegistra
    __Commands__ = {}
    __Aliases__ = {}
    
    _command_base = 'jetctl'
    
    # these are configurable per command
    takes_args = []
    takes_options = []
    encoding_type = 'strict'
    
    hidden = False
    
    def __init__(self):
        """ Constructor; create an instance of a command """
        if self.__doc__ == Command.__doc__:
            warn("No help message set for %r" % self)
        
    @classmethod
    def _get_name(cls):
        """ Return the name of this command """
        return _unsquish_command_name(cls.__name__)
        
    name = property(_get_name)
        
    def _usage(self):
        """ Return a single-line grammar for this command """
        s = '%s %s ' % (self._command_base, self.name)
        for aname in self.takes_args:
            aname = aname.upper()
            if aname[-1] in ['$', '+']:
                aname = aname[:-1] + '...'
            # optional argument
            elif aname[-1] == '?':
                aname = '[' + aname[:-1] + ']'
            elif aname[-1] == '*':
                aname = '[' + aname[:-1] + '...]'
            s += aname + ' '
        s = s[:-1]      # remove last space
        return s
        
    def _setup_outf(self):
        """
        Setup a file descriptor to stdout (outf), which has proper encoding.
        """
        if self.encoding_type == 'exact':
            # force sys.stdout to be binary stream on win32
            if sys.platform == 'win32':
                fileno = getattr(sys.stdout, 'fileno', None)
                if fileno:
                    import msvcrt
                    msvcrt.setmode(fileno(), os.O_BINARY)
            self.outf = sys.stdout
        else:
            output_encoding = osutils.get_terminal_encoding()
            self.outf = codecs.getwriter(output_encoding)(
                sys.stdout, errors=self.encoding_type
            )
            # For whatever reason codecs.getwriter() does not advertise its 
            # encoding it just returns the encoding of the wrapped file, which 
            # is completely bogus. So set the attribute, so we can find the 
            # correct encoding later.
            self.outf.encoding = output_encoding
        
    def setup_parser(self):
        """
        Get the parser configured with this Commands options.
        """
        self.parser = option.OptionParser()
        # we handle the help option ourselves.
        self.parser.remove_option('--help')
        # compile a list of options for this command.
        my_options = option.Option.STD_OPTIONS.copy()
        for opt in self.takes_options:
            if type(opt) is str:
                opt = option.Option.OPTIONS[opt]
            my_options[opt.name] = opt
        # now go through and add our options
        for an_option in my_options.itervalues():
            an_option.add_option(self.parser, an_option.short_name())
        
    def parse_args(self, args=None):
        """
        Parse the arguments.
        """
        self.setup_parser()
        self.options, args = self.parser.parse_args(args)
        return args

    def get_argform(self, args):
        argdict = {}
        # step through args and takes_args, allowing appropriate 0-many matches
        for ap in self.takes_args:
            # '?' okay to not exist
            argname = ap[:-1]
            if ap[-1] == '?':
                if args:
                    argdict[argname] = args.pop(0)
            # all remaining arguments
            elif ap[-1] == '*': 
                if args:
                    argdict[argname + '_list'] = args[:]
                    args = []
                else:
                    argdict[argname + '_list'] = None
            elif ap[-1] == '+':
                if not args:
                    raise ValueError(
                        "command %r needs one or more %s" % (cmd, argname.upper())
                    )
                else:
                    argdict[argname + '_list'] = args[:]
                    args = []
            # all but one
            elif ap[-1] == '$': 
                if len(args) < 2:
                    raise ValueError(
                        "command %r needs one or more %s" % (cmd, argname.upper())
                    )
                argdict[argname + '_list'] = args[:-1]
                args[:-1] = []
            else:
                # just a plain arg
                argname = ap
                if not args:
                    raise ValueError(
                        "command %r requires argument %s" % (cmd, argname.upper())
                    )
                else:
                    argdict[argname] = args.pop(0)
        if args:
            raise ValueError("extra argument to command %s: %s" % (cmd, args[0]))
        return argdict        

    def help(self):
        """ Return the help message for this command """
        from inspect import getdoc
        if self.__doc__ is Command.__doc__:
            return None
        else:
            return getdoc(self)
    
    def run(self):
        """
        Actually run this command.
        
        This is invoked with the options and arguments bound to keyword params.
        
        Returns 0 or None if successful, or a non-zero shell error code if not.
        """
        raise NotImplementedError('no implementation of command %r' % self.name)
        
    def __call__(self, argv):
        """
        Run this Command parsing all arguments.
        """
        args = self.parse_args(argv)
        print "X:",self.parser.values
        if self.options.help:
            sys.stdout.write(self.get_help_text())
            return 0
        if self.options.usage:
            sys.options.write(self.get_help_text(verbose=False))
            return 0
        cmd_args = self.get_argform(args)
        self._setup_outf()
        return self.run(**cmd_args)


def get_cmd_object(name):
    """
    Get a Command class and return the Command object.
    """
    print Command.__Commands__
    if name not in Command.__Commands__:
        raise ValueError('%s is not a valid command.' % name)
    return Command.__Commands__[name]()


def get_encoding():
    """ Get the system encoding """
    import locale
    try:
        user_encoding = locale.getpreferredencoding()
    except locale.Error, exc:
        sys.stderr.write('dunno what the encoding is.')
        user_encoding = 'ascii'
    # For python scripts run under vim, we get '', so also treat that as ASCII
    if user_encoding in (None, 'cp0', ''):
        user_encoding = 'ascii'
    else:
        # check encoding
        try:
            codecs.lookup(user_encoding)
        except LookupError:
            sys.stderr.write('failed to find encoding %s' % user_encoding)
    return user_encoding


def display_command(func):
    """
    Decorator that suppresses pipe/interrupt errors.
    """
    def ignore_pipe(*args, **kwargs):
        try:
            result = func(*args, **kwargs)
            sys.stdout.flush()
            return result
        except IOError, e:
            if getattr(e, 'errno', None) is None:
                raise
            if e.errno != errno.EPIPE:
                # Win32 raises IOError with errno=0 on a broken pipe
                if sys.platform != 'win32' or (e.errno not in (0, errno.EINVAL)):
                    raise
            pass
        except KeyboardInterrupt:
            pass
    return ignore_pipe

