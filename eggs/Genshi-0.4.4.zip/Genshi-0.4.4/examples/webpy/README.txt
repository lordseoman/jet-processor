Sample application that demonstrates the use of Genshi templates in web.py
(http://webpy.org/).

Try introducing errors (not just XML well-formedness errors, those are boring)
in the template, and you'll see a nice error screen with pretty good
information about the exact error.
