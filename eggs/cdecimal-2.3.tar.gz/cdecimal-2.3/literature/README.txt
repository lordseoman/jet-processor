

This document contains links to the literature used in the process of
creating the library. The list is probably not complete.


Mike Cowlishaw: General Decimal Arithmetic Specification
http://speleotrove.com/decimal/decarith.html


Jean-Michel Muller: On the definition of ulp (x)
lara.inist.fr/bitstream/2332/518/1/LIP-RR2005-09.pdf


T. E. Hull, A. Abrham: Properly rounded variable precision square root
http://portal.acm.org/citation.cfm?id=214413


T. E. Hull, A. Abrham: Variable precision exponential function
http://portal.acm.org/citation.cfm?id=6498


Roman E. Maeder: Storage allocation for the Karatsuba integer multiplication
algorithm.  http://www.springerlink.com/content/w15058mj6v59t565/


Stefan Krah: A lower bound for the size of the result array in a Karatsuba
algorithm by R. E. Maeder.  http://www.bytereef.org/papers.html


David H. Bailey: FFTs in External or Hierarchical Memory
http://crd.lbl.gov/~dhbailey/dhbpapers/


Mikko Tommila: Apfloat documentation
http://www.apfloat.org/apfloat/2.41/apfloat.pdf


Joerg Arndt: "Matters Computational"
http://www.jjj.de/fxt/


Karl Hasselstrom: Fast Division of Large Integers
www.treskal.com/kalle/exjobb/original-report.pdf





