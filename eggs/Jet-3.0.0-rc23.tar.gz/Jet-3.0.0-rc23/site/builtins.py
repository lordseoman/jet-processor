"""
This file contains the commands used by jetctl.
"""

from command import Command, display_command
from option import Option


class cmd_help(Command):
    """
    Show help on a command or other topic.
    """
    takes_options = []
    takes_args = []

    @display_command
    def run(self):
        self.outf.write(
            "The Jet Billing System Command Console.\n"
            "http://jet.obsidian.com.au/\n\n"
            "Commands:\n"
        )


class cmd_version(Command):
    """
    """