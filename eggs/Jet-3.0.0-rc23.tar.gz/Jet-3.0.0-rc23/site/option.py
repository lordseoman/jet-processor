"""
This is the Option file used by Command to manage options.

This has been ripped off of Bazaar.
"""

import optparse


class Option(object):
    """
    Description of a command line option
    
    :ivar _short_name: If this option has a single-letter name, this is it.
    Otherwise None.
    """

    # The dictionary of standard options. These are always legal.
    STD_OPTIONS = {}

    # The dictionary of commonly used options. these are only legal
    # if a command explicitly references them by name in the list
    # of supported options.
    OPTIONS = {}
    
    def __init__(
        self, name, help='', type=None, argname=None, short_name=None, 
        param_name=None, custom_callback=None
        ):
        """
        Make a new command option.

        :Parameters:
            - `name` regular name of the command, used in the double-dash
              form and also as the parameter to the command's run() method
              (unless param_name is specified).

        :Keywords: 
            - `help` help message displayed in command help
            - `type` function called to parse the option argument, or None
              (default) if this option doesn't take an argument
            - `name` of option argument, if any
            - `short_name` short option code for use with a single -, e.g.
              short_name="v" to enable parsing of -v.
            - `param_name` name of the parameter which will be passed to the
              command's run() method.
            - `custom_callback` a callback routine to be called after normal
              processing. The signature of the callback routine is
              (option, name, new_value, parser).
        """
        self.name = name
        self.help = help
        self.type = type
        self._short_name = short_name
        if type is None:
            if argname:
                raise ValueError('argname not valid for booleans')
        elif argname is None:
            argname = 'ARG'
        self.argname = argname
        if param_name is None:
            self._param_name = self.name.replace('-', '_')
        else:
            self._param_name = param_name
        self.custom_callback = custom_callback
        self.default_value = OptionParser.DEFAULT_VALUE
        
    def short_name(self):
        if self._short_name:
            return self._short_name

    def set_short_name(self, short_name):
        self._short_name = short_name
        
    def __repr__(self):
        return "<%s called %s>" % (self.__class__.__name__, self.name)

    def get_negation_name(self):
        """
        Collect an opposite/negative option for boolean flag type args.
        """
        if self.name.startswith('no-'):
            return self.name[3:]
        else:
            return 'no-' + self.name

    def add_option(self, parser, short_name):
        """
        Add this option to an Optparse parser
        """
        option_strings = [ '--%s' % self.name, ]
        if short_name is not None:
            option_strings.append('-%s' % short_name)
        # if type is not set then treat as a flag
        optargfn = self.type
        if optargfn is None:
            parser.add_option(
                action='callback',
                callback=self._optparse_bool_callback,
                callback_args=(True,),
                help=self.help,
                *option_strings
            )
            negation_strings = ['--%s' % self.get_negation_name()]
            parser.add_option(
                action='callback',
                callback=self._optparse_bool_callback,
                callback_args=(False,),
                help=optparse.SUPPRESS_HELP, 
                *negation_strings
            )
        else:
            parser.add_option(
                action='callback',
                callback=self._optparse_callback,
                type='string', 
                metavar=self.argname.upper(),
                help=self.help,
                default=self.default_value,
                *option_strings
            )
                              
    def _optparse_bool_callback(self, option, opt_str, value, parser, bool_v):
        """
        Boolean type options are flags.
        """
        setattr(parser.values, self._param_name, bool_v)
        if self.custom_callback is not None:
            self.custom_callback(option, self._param_name, bool_v, parser)

    def _optparse_callback(self, option, opt, value, parser):
        v = self.type(value)
        setattr(parser.values, self._param_name, v)
        if self.custom_callback is not None:
            self.custom_callback(option, self.name, v, parser)

    def iter_switches(self):
        """
        Iterate through the list of switches provided by this option.
        
        :Returns: 
            - an iterator of (name, short_name, argname, help)
        """
        argname =  self.argname
        if argname is not None:
            argname = argname.upper()
        yield self.name, self.short_name(), argname, self.help

    def is_hidden(self, name):
        return False
        
        
class ListOption(Option):
    """
    Option used to provide a list of values.

    On the command line, arguments are specified by a repeated use of the
    option. '-' is a special argument that resets the list. For example,
      --foo=a --foo=b
    sets the value of the 'foo' option to ['a', 'b'], and
      --foo=a --foo=b --foo=- --foo=c
    sets the value of the 'foo' option to ['c'].
    """

    def add_option(self, parser, short_name):
        """
        Add this option to an Optparse parser.
        """
        option_strings = [ '--%s' % self.name, ]
        if short_name is not None:
            option_strings.append('-%s' % short_name)
        parser.add_option(
            action='callback',
            callback=self._optparse_callback,
            type='string', 
            metavar=self.argname.upper(),
            help=self.help, 
            default=[],
            *option_strings
        )

    def _optparse_callback(self, option, opt, value, parser):
        values = getattr(parser.values, self._param_name)
        if value == '-':
            del values[:]
        else:
            values.append(self.type(value))
        if self.custom_callback is not None:
            self.custom_callback(option, self._param_name, values, parser)


class RegistryOption(Option):
    """
    Option based on a registry.

    The values for the options correspond to entries in the registry.  Input
    must be a registry key.  After validation, it is converted into an object
    using Registry.get or a caller-provided converter.
    """

    def validate_value(self, value):
        """Validate a value name"""
        if value not in self.registry:
            raise errors.BadOptionValue(self.name, value)

    def convert(self, value):
        """Convert a value name into an output type"""
        self.validate_value(value)
        if self.converter is None:
            return self.registry.get(value)
        else:
            return self.converter(value)

    def __init__(self, name, help, registry=None, converter=None,
        value_switches=False, title=None, enum_switch=True,
        lazy_registry=None):
        """
        Constructor.

        :param name: The option name.
        :param help: Help for the option.
        :param registry: A Registry containing the values
        :param converter: Callable to invoke with the value name to produce
            the value.  If not supplied, self.registry.get is used.
        :param value_switches: If true, each possible value is assigned its
            own switch.  For example, instead of '--format knit',
            '--knit' can be used interchangeably.
        :param enum_switch: If true, a switch is provided with the option name,
            which takes a value.
        :param lazy_registry: A tuple of (module name, attribute name) for a
            registry to be lazily loaded.
        """
        Option.__init__(self, name, help, type=self.convert)
        self._registry = registry
        if registry is None:
            if lazy_registry is None:
                raise AssertionError(
                    'One of registry or lazy_registry must be given.')
            self._lazy_registry = _mod_registry._LazyObjectGetter(
                *lazy_registry)
        if registry is not None and lazy_registry is not None:
            raise AssertionError(
                'registry and lazy_registry are mutually exclusive')
        self.name = name
        self.converter = converter
        self.value_switches = value_switches
        self.enum_switch = enum_switch
        self.title = title
        if self.title is None:
            self.title = name

    @property
    def registry(self):
        if self._registry is None:
            self._registry = self._lazy_registry.get_obj()
        return self._registry
        
    @staticmethod
    def from_kwargs(name_, help=None, title=None, value_switches=False,
                    enum_switch=True, **kwargs):
        """Convenience method to generate string-map registry options

        name, help, value_switches and enum_switch are passed to the
        RegistryOption constructor.  Any other keyword arguments are treated
        as values for the option, and they value is treated as the help.
        """
        reg = _mod_registry.Registry()
        for name, switch_help in kwargs.iteritems():
            name = name.replace('_', '-')
            reg.register(name, name, help=switch_help)
            if not value_switches:
                help = help + '  "' + name + '": ' + switch_help
                if not help.endswith("."):
                    help = help + "."
        return RegistryOption(name_, help, reg, title=title,
            value_switches=value_switches, enum_switch=enum_switch)

    def add_option(self, parser, short_name):
        """Add this option to an Optparse parser"""
        print "adding:",short_name
        if self.value_switches:
            parser = parser.add_option_group(self.title)
        if self.enum_switch:
            Option.add_option(self, parser, short_name)
        if self.value_switches:
            for key in self.registry.keys():
                option_strings = ['--%s' % key]
                if self.is_hidden(key):
                    help = optparse.SUPPRESS_HELP
                else:
                    help = self.registry.get_help(key)
                parser.add_option(
                    action='callback',
                    callback=self._optparse_value_callback(key),
                    help=help,
                    *option_strings
                )

    def _optparse_value_callback(self, cb_value):
        def cb(option, opt, value, parser):
            v = self.type(cb_value)
            setattr(parser.values, self._param_name, v)
            if self.custom_callback is not None:
                self.custom_callback(option, self._param_name, v, parser)
        return cb

    def iter_switches(self):
        """
        Iterate through the list of switches provided by the option.

        :Return: 
            - an iterator of (name, short_name, argname, help)
        """
        for value in Option.iter_switches(self):
            yield value
        if self.value_switches:
            for key in sorted(self.registry.keys()):
                yield key, None, None, self.registry.get_help(key)

    def is_hidden(self, name):
        if name == self.name:
            return Option.is_hidden(self, name)
        return getattr(self.registry.get_info(name), 'hidden', False)


class OptionParser(optparse.OptionParser):
    """
    OptionParser that raises exceptions instead of exiting
    """
    DEFAULT_VALUE = object()

    def error(self, message):
        raise ValueError(message)


def custom_help(name, help):
    """
    Clone a common option overriding the help.
    """
    import copy
    o = copy.copy(Option.OPTIONS[name])
    o.help = help
    return o


def _standard_option(name, **kwargs):
    """
    Register a standard Option.
    
    A Standard option is available to all Commands, such as --help and --stdout
    and --debug.
    """
    Option.STD_OPTIONS[name] = Option(name, **kwargs)
    Option.OPTIONS[name] = Option.STD_OPTIONS[name]


def _global_option(name, **kwargs):
    """
    Register a global option.
    
    A Global option is registered as an option and can be included by Commands
    using the takes_args variable. They are not used by default like Standard
    options are.
    """
    Option.OPTIONS[name] = Option(name, **kwargs)


# Some standard options for all commands
_standard_option('version')
_standard_option(
    'help', short_name='h', help="Show this help message."
)
_standard_option(
    'stdout', short_name='s', 
    help="Output should use the console logger, implies foreground."
)
_standard_option(
    'debug', short_name='d', 
    help="Verbose output should use the console logger, implies foreground."
)

# Some common options
_global_option(
    'realm', short_name='D', 
    help="The realm that should be operated on."
)
_global_option(
    'client', short_name='C',
    help="This is the name of the client stream."
)
