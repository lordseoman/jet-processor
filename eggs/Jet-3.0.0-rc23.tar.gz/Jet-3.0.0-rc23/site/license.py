#!/usr/bin/env python
#
# This file implements the licence checks.  If you have no modules (eg.
# if you're using the Open Source version of this code), then this will either
# have no effect, not be called, or not exist.
#
# I'm starting with the least intrusive thing here - this module knows how
# to decode the licence key each user gets, and runs some checks to ensure
# that the licence key is correct (ie. properly cpuid or whatever else we
# have available).  Theoretically, this should hold crucial code without
# which nothing works - but I'm not sure I really want to go that far
# quite yet.
#
# Note, this means we have to have the appropriate version of python available.
""" Licence code """

import os
from Crypto.Cipher import ARC4
from StringIO import StringIO
from mx import DateTime
import ConfigParser

import Jet

key1 = 'f&'
key2 = '*g'
key3 = '#e'
key4 = 'K0'

key = key4 + key2 + key3 + key1

class LicenceError(Exception): 
    pass

class License:
    """
    Provides a config-like interface, but the config variables all come from
    an encrypted file.
    """
    def __init__(self, load=1, ds=None):
        self.install_dir = Jet.getInstallLocation()
        self.licenceFilename = os.path.join(self.install_dir,'etc','licence.key')
        self.config = ConfigParser.ConfigParser()
        if load:
            self.getLicence()
            # If we've got a licence, we test it
            if self.config.has_section('licence'):
                self.checkLicence(ds=ds)

    def violation(self, text):
        """ Record a violation """
#        try:
#            util.mailTo(mailFrom=self.config.get('main', 'default_realm'), 
#                reallyTo='contact@obsidian.com.au', subject="Licence Check", 
#                body=text)
#        except:
#            pass
        raise LicenceError, text

    def checkLicence(self, ds=None):
        """ Check licence restrictions """
        # Short-cut for ourselves
        # Note, windows doesn't support uname
        machine_name = ''
        machine_name = os.uname()[1]
        get = self.config.get
        has = self.config.has_option
        # Make sure the uname is right
        if has('licence', 'uname'):
            if get('licence', 'uname') != machine_name:
                self.violation("Invalid uname")
        # Make sure the ifconfig is right
        if has('licence', 'macaddress'):
            macaddr = os.popen('/sbin/ifconfig eth0 | grep HWaddr').read()
            macaddr = macaddr.strip()
            macaddr = macaddr.split(' ')[-1]
            if get('licence', 'macaddress') != macaddr:
                self.violation("Invalid Ethernet Address")
        # Check the date, if we have a max_date
        if has('licence', 'max_date'):
            now = DateTime.now()
            maxDate = DateTime.DateTimeFrom(get('licence', 'max_date'))
            if now > maxDate:
                self.violation("Past use-by date '%s'"%maxDate)
        # The next few checks require a datastore
        closeCursor = 0
        if not ds:
            closeCursor = 1
            from bin.datastore import datastore
            ds = datastore()
        try:
            realms = ds.listRealms()
            # Check maximums - realms and users
            if has('licence', 'maxrealms'):
                if len(realms) > int(get('licence', 'maxrealms')):
                    self.violation("Too many realms")
            if has('licence', 'maxusers'):
                users = 0
                for realm in realms:
                    miniClose = False
                    if ds.getRealm() != realm:
                        from bin.datastore import datastore
                        old_ds = ds
                        ds = datastore(realm)
                        miniClose = True
                    try:
                        # try..except to stop breakage for unknown databases.
                        users = users + len(ds.getAllUserCids())
                    except:
                        pass
                    if users > get('licence', 'maxusers'):
                        self.violation("Too many users")
                    if miniClose:
                        ds.close()
                        ds = old_ds
        finally:
            if closeCursor:
                ds.close()

    def __getattr__(self, name):
        """ map through to the config object for unknown attributes """
        return getattr(self.config, name)

    def getLicence(self):
        """
        Grab the licence, decode it, and store it in self.
        """
        if os.path.exists(self.licenceFilename):
            cryptedText = open(self.licenceFilename).read()
            obj = ARC4.new(key)
            self.config.readfp(StringIO(obj.decrypt(cryptedText)))
        else:
            raise IOError('license key is missing.')

    def storeLicence(self):
        """
        Takes config data, writes to the licence file.
        Config data comes in as cleartext "x = y" lines.
        """
        myFP = StringIO()
        self.config.write(myFP)
        myFP.seek(0)
        cleartext = myFP.read()
        obj = ARC4.new(key)
        encryptedtext = obj.encrypt(cleartext)
        open(self.licenceFilename, 'w').write(encryptedtext)

    def displayLicence(self):
        """ Returns the licence details as cleartext config file """
        myFP = StringIO()
        self.config.write(myFP)
        myFP.seek(0)
        return myFP.read()
        
    def addRealm(self, realm, billed=True, dstore=None):
        """
        Add a new realm - this writes out a config file for the new realm
        """
        realmCfg = os.path.join(self.install_dir, 'etc', 'realm.cfg')
        cfg = ConfigParser.ConfigParser()
        cfg.read(realmCfg)
        if cfg.has_section(realm):
            raise KeyError, realm
        cfg.add_section(realm)
        cfg.set(realm, 'billed', billed)
        cfg.write(open(realmCfg, 'w'))
        self.checkLicence(ds=dstore)
        
    def delRealm(self, realm):
        """
        Remove a realm
        """
        realmCfg = os.path.join(self.install_dir, 'etc', 'realm.cfg')
        cfg = ConfigParser.ConfigParser()
        cfg.read(realmCfg)
        if cfg.has_section(realm):
            cfg.remove_section(realm)
            if not cfg.sections():
                # No more realms - remove the file to dodge a bug with empty
                # config files
                os.unlink(realmCfg)
            else:
                cfg.write(open(realmCfg, 'w'))
        self.checkLicence()

