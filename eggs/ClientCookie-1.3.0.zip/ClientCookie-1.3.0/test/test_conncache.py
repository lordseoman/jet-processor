"""Tests for ClientCookie._ConnCache module."""

import unittest, sys

class ConnCacheTests(unittest.TestCase):

    def test_ConnectionCache(self):
        from ClientCookie import ConnectionCache
        ConnectionCache()


if __name__ == "__main__":
    #unittest.main()
    pass
